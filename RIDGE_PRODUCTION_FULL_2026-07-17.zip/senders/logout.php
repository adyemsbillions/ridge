<?php
require_once '../includes/bootstrap.php';
unset($_SESSION['sender_id'],$_SESSION['sender_name'],$_SESSION['sender_phone'],$_SESSION['sender_email']);
session_regenerate_id(true);
ridge_redirect('index.php');
