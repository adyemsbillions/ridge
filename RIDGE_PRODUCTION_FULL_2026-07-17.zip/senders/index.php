<?php
require_once '../includes/bootstrap.php';

if (isset($_SESSION['sender_id'])) {
    ridge_redirect('dashboard.php');
}

$loginError = '';
$signupErrors = [];
$success = '';
$activeTab = isset($_POST['signup']) ? 'signup' : 'login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ridge_require_csrf();

    if (isset($_POST['login'])) {
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $password = (string) ($_POST['password'] ?? '');
        $stmt = $conn->prepare("SELECT id, full_name, phone, email, password, status FROM senders WHERE email = ? LIMIT 1");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $sender = $stmt->get_result()->fetch_assoc();

        if (!$sender || !password_verify($password, $sender['password'])) {
            $loginError = 'The email address or password is incorrect.';
        } elseif ($sender['status'] !== 'active') {
            $loginError = 'This sender account is currently inactive.';
        } else {
            session_regenerate_id(true);
            $_SESSION['sender_id'] = (int) $sender['id'];
            $_SESSION['sender_name'] = $sender['full_name'];
            $_SESSION['sender_phone'] = $sender['phone'];
            $_SESSION['sender_email'] = $sender['email'];
            ridge_redirect('dashboard.php');
        }
    }

    if (isset($_POST['signup'])) {
        $name = trim((string) ($_POST['full_name'] ?? ''));
        $phone = ridge_normalize_phone((string) ($_POST['phone'] ?? ''));
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $address = trim((string) ($_POST['address'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $confirm = (string) ($_POST['confirm_password'] ?? '');

        if (mb_strlen($name) < 2) $signupErrors[] = 'Enter your full name.';
        if (strlen($phone) < 10) $signupErrors[] = 'Enter a valid phone number.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $signupErrors[] = 'Enter a valid email address.';
        if (strlen($password) < 8) $signupErrors[] = 'Password must contain at least 8 characters.';
        if ($password !== $confirm) $signupErrors[] = 'The passwords do not match.';

        $check = $conn->prepare('SELECT id FROM senders WHERE email = ? OR phone = ? LIMIT 1');
        $check->bind_param('ss', $email, $phone);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $signupErrors[] = 'An account already exists with this email address or phone number.';
        }

        if (!$signupErrors) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare('INSERT INTO senders (full_name, phone, email, address, password) VALUES (?, ?, ?, ?, ?)');
            $stmt->bind_param('sssss', $name, $phone, $email, $address, $hash);
            if ($stmt->execute()) {
                $success = 'Your sender account is ready. Sign in to create and track deliveries.';
                $activeTab = 'login';
            } else {
                $signupErrors[] = 'Account creation failed. Please try again.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sender Portal - RIDGE</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/portal.css">
</head>
<body>
<div class="auth-wrap">
  <section class="auth-art">
    <div class="eyebrow">RIDGE Sender Portal</div>
    <h1>SEND.<br><em>TRACK.</em><br>RELAX.</h1>
    <p>Create delivery requests, choose a verified dispatch partner and follow every movement from pickup to proof of delivery.</p>
  </section>
  <main class="auth-panel">
    <div class="auth-card">
      <a class="brand" href="../index.php">RIDGE<span>.</span></a>
      <?php if ($success): ?><div class="alert alert-success"><?= h($success) ?></div><?php endif; ?>
      <div class="tabs">
        <button type="button" data-tab="login" class="<?= $activeTab === 'login' ? 'active' : '' ?>">Sign in</button>
        <button type="button" data-tab="signup" class="<?= $activeTab === 'signup' ? 'active' : '' ?>">Create account</button>
      </div>

      <form method="post" id="login" class="auth-form <?= $activeTab === 'login' ? 'active' : '' ?>">
        <?= ridge_csrf_field() ?>
        <?php if ($loginError): ?><div class="alert alert-error"><?= h($loginError) ?></div><?php endif; ?>
        <div class="form-grid">
          <div class="field full"><label>Email address</label><input type="email" name="email" required autocomplete="email"></div>
          <div class="field full"><label>Password</label><input type="password" name="password" required autocomplete="current-password"></div>
        </div>
        <div class="form-actions"><button class="btn btn-primary" name="login" value="1">Sign in to portal</button><a class="btn btn-ghost" href="../track.php">Track without signing in</a></div>
      </form>

      <form method="post" id="signup" class="auth-form <?= $activeTab === 'signup' ? 'active' : '' ?>">
        <?= ridge_csrf_field() ?>
        <?php if ($signupErrors): ?><div class="alert alert-error"><?= implode('<br>', array_map('h', $signupErrors)) ?></div><?php endif; ?>
        <div class="form-grid">
          <div class="field full"><label>Full name</label><input type="text" name="full_name" required value="<?= h($_POST['full_name'] ?? '') ?>"></div>
          <div class="field"><label>Phone number</label><input type="tel" name="phone" required value="<?= h($_POST['phone'] ?? '') ?>"></div>
          <div class="field"><label>Email address</label><input type="email" name="email" required value="<?= h($_POST['email'] ?? '') ?>"></div>
          <div class="field full"><label>Default pickup address</label><textarea name="address" rows="2" placeholder="Optional"><?= h($_POST['address'] ?? '') ?></textarea></div>
          <div class="field"><label>Password</label><input type="password" name="password" minlength="8" required></div>
          <div class="field"><label>Confirm password</label><input type="password" name="confirm_password" minlength="8" required></div>
        </div>
        <div class="form-actions"><button class="btn btn-primary" name="signup" value="1">Create sender account</button></div>
      </form>
    </div>
  </main>
</div>
<script>
for (const button of document.querySelectorAll('[data-tab]')) {
  button.addEventListener('click', () => {
    document.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('active', b === button));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.toggle('active', f.id === button.dataset.tab));
  });
}
</script>
</body></html>
