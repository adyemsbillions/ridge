<?php
require_once '../includes/bootstrap.php';
require_once '../includes/notifications.php';
if (!isset($_SESSION['sender_id'])) ridge_redirect('index.php');

$senderId = (int) $_SESSION['sender_id'];
$profileStmt = $conn->prepare('SELECT full_name,phone,email,address FROM senders WHERE id=? LIMIT 1');
$profileStmt->bind_param('i',$senderId);$profileStmt->execute();$sender=$profileStmt->get_result()->fetch_assoc();
if (!$sender) ridge_redirect('logout.php');

$partners = $conn->query("SELECT id,company_name,company_address FROM partners WHERE status='active' ORDER BY company_name");
$errors=[];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    ridge_require_csrf();
    $partnerId=(int)($_POST['partner_id']??0);
    $senderAddress=trim((string)($_POST['sender_address']??''));
    $recipientName=trim((string)($_POST['recipient_name']??''));
    $recipientPhone=ridge_normalize_phone((string)($_POST['recipient_phone']??''));
    $recipientAddress=trim((string)($_POST['recipient_address']??''));
    $description=trim((string)($_POST['package_description']??''));
    $deliveryDate=(string)($_POST['delivery_date']??'');
    $lat=($_POST['recipient_lat']??'')!==''?(float)$_POST['recipient_lat']:null;
    $lng=($_POST['recipient_lng']??'')!==''?(float)$_POST['recipient_lng']:null;
    if ($partnerId<1) $errors[]='Choose a delivery partner.';
    if ($senderAddress==='') $errors[]='Enter the pickup address.';
    if ($recipientName==='') $errors[]='Enter the recipient name.';
    if (strlen($recipientPhone)<10) $errors[]='Enter a valid recipient phone number.';
    if ($recipientAddress==='') $errors[]='Enter the delivery address.';
    if ($description==='') $errors[]='Describe the package.';
    if (!$deliveryDate || strtotime($deliveryDate)<strtotime(date('Y-m-d'))) $errors[]='Choose today or a future delivery date.';

    if (!$errors) {
        $tracking=ridge_tracking_id();$token=ridge_public_token();
        $stmt=$conn->prepare("INSERT INTO deliveries (partner_id,sender_id,tracking_id,public_token,sender_name,sender_phone,sender_address,recipient_name,recipient_phone,recipient_address,package_description,delivery_date,status,recipient_lat,recipient_lng) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'pending',?,?)");
        $stmt->bind_param('iissssssssssdd',$partnerId,$senderId,$tracking,$token,$sender['full_name'],$sender['phone'],$senderAddress,$recipientName,$recipientPhone,$recipientAddress,$description,$deliveryDate,$lat,$lng);
        if ($stmt->execute()) {
            $deliveryId=$stmt->insert_id;
            ridge_record_event($conn,$deliveryId,'pending','Delivery request created','The sender submitted a new request.','sender',$senderId);
            $delivery=['id'=>$deliveryId,'tracking_id'=>$tracking,'public_token'=>$token,'recipient_name'=>$recipientName,'recipient_phone'=>$recipientPhone,'sender_name'=>$sender['full_name'],'sender_phone'=>$sender['phone']];
            ridge_notify_delivery_status($conn,$delivery,'pending');
            ridge_redirect('delivery.php?id='.$deliveryId.'&created=1');
        }
        $errors[]='The delivery could not be created. Please try again.';
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>New Delivery - RIDGE</title><link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/portal.css"></head><body>
<header class="topbar"><a class="brand" href="dashboard.php">RIDGE<span>.</span></a><nav class="topnav"><a href="dashboard.php">Dashboard</a><a class="active" href="new_delivery.php">New delivery</a><a class="keep" href="logout.php">Logout</a></nav></header>
<main class="page"><div class="eyebrow">Create request</div><h1>New delivery</h1><p class="lead">Add the pickup and recipient details. The chosen partner will assign a rider and keep both parties updated.</p>
<?php if($errors):?><div class="alert alert-error"><?=implode('<br>',array_map('h',$errors))?></div><?php endif;?>
<section class="card"><div class="card-head"><h2>Delivery information</h2></div><div class="card-body"><form method="post" id="delivery-form"><?=ridge_csrf_field()?>
<div class="form-grid">
<div class="field full"><label>Delivery partner</label><select name="partner_id" required><option value="">Choose an active partner</option><?php while($p=$partners->fetch_assoc()):?><option value="<?= (int)$p['id'] ?>" <?= ((int)($_POST['partner_id']??0)===(int)$p['id'])?'selected':'' ?>><?=h($p['company_name'])?> — <?=h($p['company_address'])?></option><?php endwhile;?></select></div>
<div class="field full"><label>Pickup address</label><textarea name="sender_address" rows="2" required><?=h($_POST['sender_address']??$sender['address']??'')?></textarea></div>
<div class="field"><label>Recipient name</label><input name="recipient_name" required value="<?=h($_POST['recipient_name']??'')?>"></div>
<div class="field"><label>Recipient phone</label><input type="tel" name="recipient_phone" required value="<?=h($_POST['recipient_phone']??'')?>"></div>
<div class="field full"><label>Delivery address</label><input id="recipient_address" name="recipient_address" required autocomplete="off" value="<?=h($_POST['recipient_address']??'')?>"><small id="address-help" style="color:var(--muted)">Start typing, then choose a suggested address to save map coordinates.</small><div id="suggestions"></div></div>
<input type="hidden" name="recipient_lat" id="recipient_lat"><input type="hidden" name="recipient_lng" id="recipient_lng">
<div class="field full"><label>Package description</label><textarea name="package_description" rows="3" required placeholder="Example: sealed document envelope, fragile electronics"><?=h($_POST['package_description']??'')?></textarea></div>
<div class="field"><label>Preferred delivery date</label><input type="date" name="delivery_date" min="<?=date('Y-m-d')?>" value="<?=h($_POST['delivery_date']??date('Y-m-d',strtotime('+1 day')))?>" required></div>
</div><div class="form-actions"><button class="btn btn-primary">Create delivery</button><a class="btn btn-ghost" href="dashboard.php">Cancel</a></div></form></div></section></main>
<script>
const input=document.getElementById('recipient_address'),box=document.getElementById('suggestions');let timer;
box.style.cssText='display:none;background:#171717;border:1px solid rgba(245,242,235,.1);border-radius:9px;margin-top:.35rem;overflow:hidden';
input.addEventListener('input',()=>{clearTimeout(timer);document.getElementById('recipient_lat').value='';document.getElementById('recipient_lng').value='';if(input.value.trim().length<4){box.style.display='none';return;}timer=setTimeout(async()=>{try{const r=await fetch('https://photon.komoot.io/api/?q='+encodeURIComponent(input.value+', Nigeria')+'&limit=5');const d=await r.json();box.innerHTML='';for(const f of (d.features||[])){const label=[f.properties.name,f.properties.street,f.properties.city,f.properties.state].filter(Boolean).join(', ');const b=document.createElement('button');b.type='button';b.textContent=label;b.style.cssText='display:block;width:100%;text-align:left;padding:.7rem .85rem;border:0;border-bottom:1px solid rgba(245,242,235,.06);background:transparent;color:#f5f2eb;cursor:pointer';b.onclick=()=>{input.value=label;document.getElementById('recipient_lng').value=f.geometry.coordinates[0];document.getElementById('recipient_lat').value=f.geometry.coordinates[1];box.style.display='none';document.getElementById('address-help').textContent='Map coordinates saved.';};box.appendChild(b);}box.style.display=box.children.length?'block':'none';}catch(e){box.style.display='none';}},350);});
</script></body></html>
