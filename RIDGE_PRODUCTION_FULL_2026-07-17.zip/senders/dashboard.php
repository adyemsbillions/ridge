<?php
require_once '../includes/bootstrap.php';
if (!isset($_SESSION['sender_id'])) ridge_redirect('index.php');

$senderId = (int) $_SESSION['sender_id'];
$senderPhone = (string) ($_SESSION['sender_phone'] ?? '');

$stmt = $conn->prepare("SELECT
 COUNT(*) total,
 SUM(status='pending') pending,
 SUM(status IN ('assigned','enroute')) active,
 SUM(status='returned') returned,
 SUM(status='delivered') delivered
 FROM deliveries WHERE sender_id = ? OR sender_phone = ?");
$stmt->bind_param('is', $senderId, $senderPhone);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc() ?: [];

$list = $conn->prepare("SELECT d.id,d.tracking_id,d.recipient_name,d.recipient_address,d.delivery_date,d.status,d.created_at,d.public_token,p.company_name,r.rider_name
 FROM deliveries d LEFT JOIN partners p ON p.id=d.partner_id LEFT JOIN riders r ON r.id=d.rider_id
 WHERE d.sender_id = ? OR d.sender_phone = ? ORDER BY d.created_at DESC LIMIT 100");
$list->bind_param('is', $senderId, $senderPhone);
$list->execute();
$deliveries = $list->get_result();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sender Dashboard - RIDGE</title><link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/portal.css"></head><body>
<div class="shell">
<header class="topbar"><a class="brand" href="dashboard.php">RIDGE<span>.</span></a><nav class="topnav"><a class="active" href="dashboard.php">Dashboard</a><a href="new_delivery.php">New delivery</a><a class="keep" href="logout.php">Logout</a></nav></header>
<main class="page">
<div class="eyebrow">Sender workspace</div><h1>Welcome, <?= h($_SESSION['sender_name'] ?? 'Sender') ?></h1><p class="lead">Create delivery requests and see every active, completed and upcoming order in one place.</p>
<div class="grid stats">
<div class="stat"><small>All deliveries</small><strong><?= (int)($stats['total'] ?? 0) ?></strong></div>
<div class="stat"><small>Awaiting rider</small><strong><?= (int)($stats['pending'] ?? 0) ?></strong></div>
<div class="stat"><small>In progress</small><strong><?= (int)($stats['active'] ?? 0) ?></strong></div>
<div class="stat"><small>Returned to last mile</small><strong style="color:#ff9d9d"><?= (int)($stats['returned'] ?? 0) ?></strong></div>
<div class="stat"><small>Delivered</small><strong><?= (int)($stats['delivered'] ?? 0) ?></strong></div>
</div>
<section class="card"><div class="card-head"><h2>My deliveries</h2><a class="btn btn-primary btn-sm" href="new_delivery.php">+ New delivery</a></div>
<?php if ($deliveries->num_rows): ?><div class="table-wrap"><table><thead><tr><th>Tracking</th><th>Recipient</th><th>Partner</th><th>Delivery date</th><th>Status</th><th></th></tr></thead><tbody>
<?php while ($row=$deliveries->fetch_assoc()): ?><tr><td><strong><?= h($row['tracking_id']) ?></strong></td><td><?= h($row['recipient_name']) ?></td><td><?= h($row['company_name'] ?: 'Pending selection') ?></td><td><?= h(date('d M Y', strtotime($row['delivery_date']))) ?></td><td><span class="pill <?= h($row['status']) ?>"><?= h(ridge_delivery_status_label($row['status'])) ?></span></td><td><a class="btn btn-ghost btn-sm" href="delivery.php?id=<?= (int)$row['id'] ?>">View</a></td></tr><?php endwhile; ?>
</tbody></table></div><?php else: ?><div class="empty"><p>No deliveries yet.</p><a class="btn btn-primary" href="new_delivery.php">Create your first delivery</a></div><?php endif; ?>
</section>
</main></div></body></html>
