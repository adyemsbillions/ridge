<?php
require_once '../includes/bootstrap.php';
require_once '../includes/notifications.php';

if (!isset($_SESSION['admin_id'])) { ridge_redirect('admin_login.php'); }

$admin_name = $_SESSION['admin_name'];

// ── Logout ─────────────────────────────────────────────────────
if (isset($_GET['logout'])) {
    session_destroy();
    ridge_redirect('admin_login.php');
}

$success = $error = null;

// ── Create Partner ─────────────────────────────────────────────
if (isset($_POST['create_partner'])) {
    $company     = trim($_POST['company_name']);
    $address     = trim($_POST['company_address']);
    $dispatchers = (int)$_POST['num_dispatchers'];
    $phone       = trim($_POST['phone']);
    $email       = trim($_POST['email']);
    $contact     = trim($_POST['contact_person']);
    $pass        = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $chk = $conn->prepare("SELECT id FROM partners WHERE email = ?");
    $chk->bind_param("s", $email); $chk->execute();
    if ($chk->get_result()->num_rows > 0) {
        $error = "A partner with that email already exists.";
    } else {
        $s = $conn->prepare("INSERT INTO partners (company_name,company_address,num_dispatchers,phone,email,contact_person,password,status) VALUES (?,?,?,?,?,?,?,'active')");
        $s->bind_param("ssissss", $company, $address, $dispatchers, $phone, $email, $contact, $pass);
        $s->execute() ? $success = "Partner '{$company}' created." : $error = "Failed to create partner.";
    }
}

// ── Update Partner Status ──────────────────────────────────────
if (isset($_POST['update_partner_status'])) {
    $pid    = (int)$_POST['partner_id'];
    $status = $_POST['status'] === 'active' ? 'active' : 'pending';
    $stmt = $conn->prepare("UPDATE partners SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $pid);
    $stmt->execute();
    $success = "Partner status updated.";
}

// ── Delete Partner ─────────────────────────────────────────────
if (isset($_POST['delete_partner'])) {
    $pid = (int)$_POST['partner_id'];
    $stmt = $conn->prepare("DELETE FROM partners WHERE id=?");
    $stmt->bind_param("i", $pid);
    $stmt->execute();
    $success = "Partner deleted.";
}

// ── Update Rider Status ────────────────────────────────────────
if (isset($_POST['update_rider_status'])) {
    $rid    = (int)$_POST['rider_id'];
    $status = in_array($_POST['status'], ['active','inactive','on_trip']) ? $_POST['status'] : 'active';
    $stmt = $conn->prepare("UPDATE riders SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $rid);
    $stmt->execute();
    $success = "Rider status updated.";
}

// ── Delete Rider ───────────────────────────────────────────────
if (isset($_POST['delete_rider'])) {
    $rid = (int)$_POST['rider_id'];
    $stmt = $conn->prepare("DELETE FROM riders WHERE id=?");
    $stmt->bind_param("i", $rid);
    $stmt->execute();
    $success = "Rider removed.";
}

// ── Update Delivery Status ─────────────────────────────────────
if (isset($_POST['update_delivery_status'])) {
    $did = (int) $_POST['delivery_id'];
    $status = in_array($_POST['status'], ['pending','assigned','enroute','returned','delivered','cancelled'], true) ? $_POST['status'] : 'pending';
    if (ridge_set_delivery_status($conn, $did, $status, 'admin', (int) $_SESSION['admin_id'], 'Status updated by an administrator.')) {
        $dstmt = $conn->prepare("SELECT d.*,r.rider_name FROM deliveries d LEFT JOIN riders r ON r.id=d.rider_id WHERE d.id=? LIMIT 1");
        $dstmt->bind_param('i', $did); $dstmt->execute();
        if ($drow = $dstmt->get_result()->fetch_assoc()) {
            ridge_notify_delivery_status($conn, $drow, $status, (string) ($drow['rider_name'] ?? ''));
        }
        $success = "Delivery status updated.";
    } else {
        $error = "Delivery status could not be updated.";
    }
}

// ── Create Admin ───────────────────────────────────────────────
if (isset($_POST['create_admin'])) {
    $aname = trim($_POST['admin_name']);
    $aemail= trim($_POST['admin_email']);
    $apass = password_hash($_POST['admin_password'], PASSWORD_DEFAULT);

    $chk = $conn->prepare("SELECT id FROM admins WHERE email=?");
    $chk->bind_param("s", $aemail); $chk->execute();
    if ($chk->get_result()->num_rows > 0) {
        $error = "Admin with that email already exists.";
    } else {
        $s = $conn->prepare("INSERT INTO admins (name,email,password) VALUES (?,?,?)");
        $s->bind_param("sss", $aname, $aemail, $apass);
        $s->execute() ? $success = "Admin '{$aname}' created." : $error = "Failed to create admin.";
    }
}

// ── Assign or Reassign Rider to Delivery ─────────────────────
if (isset($_POST['assign_rider'])) {
    $did = (int) ($_POST['delivery_id'] ?? 0);
    $rid = (int) ($_POST['rider_id'] ?? 0);

    $lookup = $conn->prepare("SELECT d.status,d.partner_id,r.rider_name,r.partner_id rider_partner FROM deliveries d JOIN riders r ON r.id=? WHERE d.id=? LIMIT 1");
    $lookup->bind_param('ii', $rid, $did);
    $lookup->execute();
    $assignment = $lookup->get_result()->fetch_assoc();

    if (!$assignment || (int) $assignment['partner_id'] !== (int) $assignment['rider_partner']) {
        $error = 'The rider must belong to the delivery partner.';
    } else {
        $wasReturned = $assignment['status'] === 'returned';
        $assign = $conn->prepare("UPDATE deliveries SET rider_id=?,status='assigned',accepted_at=NOW(),enroute_at=NULL,delivered_at=NULL,cancelled_at=NULL,delivery_otp=NULL,otp_expires_at=NULL,assignment_count=COALESCE(assignment_count,0)+1,last_reassigned_at=CASE WHEN return_count>0 THEN NOW() ELSE last_reassigned_at END WHERE id=?");
        $assign->bind_param('ii', $rid, $did);
        if ($assign->execute()) {
            $title = $wasReturned ? 'Returned item reassigned' : 'Rider assigned';
            $description = ($wasReturned ? 'A returned item was reassigned to ' : 'A rider was assigned by an administrator: ') . $assignment['rider_name'] . '.';
            ridge_record_event($conn, $did, 'assigned', $title, $description, 'admin', (int) $_SESSION['admin_id']);

            $dstmt = $conn->prepare("SELECT d.*,r.rider_name FROM deliveries d LEFT JOIN riders r ON r.id=d.rider_id WHERE d.id=? LIMIT 1");
            $dstmt->bind_param('i', $did); $dstmt->execute();
            if ($drow = $dstmt->get_result()->fetch_assoc()) {
                ridge_notify_delivery_status($conn, $drow, 'assigned', (string) ($drow['rider_name'] ?? ''));
            }
            $success = $wasReturned ? 'Returned item reassigned.' : 'Rider assigned.';
        } else {
            $error = 'Rider could not be assigned.';
        }
    }
}

// ── Stats ──────────────────────────────────────────────────────
$stats = [];
$stats['partners']  = $conn->query("SELECT COUNT(*) c FROM partners")->fetch_assoc()['c'];
$stats['riders']    = $conn->query("SELECT COUNT(*) c FROM riders")->fetch_assoc()['c'];
$stats['deliveries']= $conn->query("SELECT COUNT(*) c FROM deliveries")->fetch_assoc()['c'];
$stats['delivered'] = $conn->query("SELECT COUNT(*) c FROM deliveries WHERE status='delivered'")->fetch_assoc()['c'];
$stats['enroute']   = $conn->query("SELECT COUNT(*) c FROM deliveries WHERE status='enroute'")->fetch_assoc()['c'];
$stats['pending']   = $conn->query("SELECT COUNT(*) c FROM deliveries WHERE status='pending'")->fetch_assoc()['c'];
$stats['returned']  = $conn->query("SELECT COUNT(*) c FROM deliveries WHERE status='returned'")->fetch_assoc()['c'];

// ── Fetch data ─────────────────────────────────────────────────
$partners  = $conn->query("SELECT * FROM partners ORDER BY created_at DESC");
$riders    = $conn->query("SELECT r.*, p.company_name FROM riders r LEFT JOIN partners p ON p.id=r.partner_id ORDER BY r.created_at DESC");
$deliveries= $conn->query("SELECT d.*, p.company_name, r.rider_name FROM deliveries d LEFT JOIN partners p ON p.id=d.partner_id LEFT JOIN riders r ON r.id=d.rider_id ORDER BY d.created_at DESC LIMIT 200");
$admins    = $conn->query("SELECT id, name, email, created_at FROM admins ORDER BY created_at DESC");

// Riders list for assign dropdown
$riders_list = $conn->query("SELECT id, rider_name, partner_id FROM riders WHERE status='active' ORDER BY rider_name");
$riders_arr = [];
while ($rr = $riders_list->fetch_assoc()) $riders_arr[] = $rr;

$active_tab = $_GET['tab'] ?? 'overview';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin — RIDGE</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
:root{
    --black:#0A0A0A;--mid:#141414;--card:#111111;--card2:#161616;
    --border:rgba(245,242,235,0.09);--off:#F5F2EB;--muted:#6B6860;
    --accent:#E8500A;--accent-dim:rgba(232,80,10,0.13);
    --green:#1D9E75;--green-dim:rgba(29,158,117,0.13);
    --amber:#D9860A;--amber-dim:rgba(217,134,10,0.13);
    --red:#C0392B;--red-dim:rgba(192,57,43,0.13);
    --mono:'JetBrains Mono',monospace;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--black);color:var(--off);min-height:100vh;display:flex;}

/* ── Sidebar ── */
.sidebar{width:230px;background:var(--mid);border-right:1px solid var(--border);padding:1.5rem 1.1rem;position:fixed;top:0;left:0;height:100vh;display:flex;flex-direction:column;gap:1.5rem;z-index:100;overflow-y:auto;}
.logo{font-family:'Bebas Neue',sans-serif;font-size:1.85rem;letter-spacing:0.08em;}
.logo span{color:var(--accent);}
.logo-sub{font-family:var(--mono);font-size:0.6rem;color:var(--muted);letter-spacing:0.1em;text-transform:uppercase;margin-top:-0.5rem;}
nav{display:flex;flex-direction:column;gap:0.15rem;}
nav a{display:flex;align-items:center;gap:0.7rem;padding:0.65rem 0.85rem;border-radius:8px;color:var(--muted);text-decoration:none;font-size:0.87rem;font-weight:500;transition:all 0.12s;}
nav a:hover{background:rgba(245,242,235,0.05);color:var(--off);}
nav a.active{background:var(--accent-dim);color:var(--accent);}
nav .section-label{font-family:var(--mono);font-size:0.6rem;color:var(--muted);text-transform:uppercase;letter-spacing:0.1em;padding:0.5rem 0.85rem 0.2rem;}
.admin-badge{margin-top:auto;background:rgba(245,242,235,0.04);border:1px solid var(--border);border-radius:10px;padding:0.8rem;font-size:0.75rem;color:var(--muted);}
.admin-badge strong{display:block;color:var(--off);font-size:0.85rem;margin-bottom:0.15rem;}
.admin-badge a{color:var(--muted);text-decoration:none;font-size:0.72rem;}
.admin-badge a:hover{color:var(--accent);}

/* ── Main ── */
.main{margin-left:230px;flex:1;padding:2rem;min-height:100vh;}
.page-title{font-family:'Bebas Neue',sans-serif;font-size:2rem;letter-spacing:0.04em;margin-bottom:1.5rem;}

/* ── Alerts ── */
.alert{padding:0.8rem 1rem;border-radius:8px;font-size:0.85rem;margin-bottom:1.25rem;display:flex;align-items:center;gap:0.5rem;}
.alert-success{background:var(--green-dim);border:1px solid rgba(29,158,117,0.25);color:var(--green);}
.alert-error{background:var(--accent-dim);border:1px solid rgba(232,80,10,0.25);color:var(--accent);}

/* ── Stat cards ── */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:1rem;margin-bottom:2rem;}
.stat-card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:1.1rem 1.25rem;}
.stat-label{font-family:var(--mono);font-size:0.65rem;color:var(--muted);text-transform:uppercase;letter-spacing:0.07em;margin-bottom:0.4rem;}
.stat-num{font-family:'Bebas Neue',sans-serif;font-size:2.2rem;letter-spacing:0.02em;line-height:1;}
.stat-num.green{color:var(--green);}
.stat-num.accent{color:var(--accent);}
.stat-num.amber{color:var(--amber);}

/* ── Section card ── */
.section{background:var(--card);border:1px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:2rem;}
.section-head{padding:1.1rem 1.4rem;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:0.75rem;}
.section-head h2{font-family:'Bebas Neue',sans-serif;font-size:1.3rem;letter-spacing:0.04em;}
.section-body{padding:1.4rem;}

/* ── Forms ── */
.form-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:1rem;}
.field label{display:block;font-size:0.68rem;font-family:var(--mono);color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:0.35rem;}
.field input,.field select,.field textarea{
    width:100%;background:rgba(245,242,235,0.05);border:1px solid var(--border);
    color:var(--off);border-radius:8px;padding:0.7rem 0.9rem;
    font-family:'DM Sans',sans-serif;font-size:0.88rem;outline:none;transition:border-color 0.15s;
}
.field input:focus,.field select:focus,.field textarea:focus{border-color:rgba(232,80,10,0.4);}
.field select option{background:var(--mid);}
.form-footer{margin-top:1.25rem;display:flex;gap:0.75rem;flex-wrap:wrap;}
.btn{padding:0.65rem 1.2rem;border-radius:8px;border:none;font-family:'DM Sans',sans-serif;font-size:0.85rem;font-weight:600;cursor:pointer;transition:opacity 0.15s;text-decoration:none;display:inline-flex;align-items:center;gap:0.4rem;}
.btn:hover{opacity:0.85;}
.btn-accent{background:var(--accent);color:white;}
.btn-green{background:var(--green);color:white;}
.btn-ghost{background:transparent;border:1px solid var(--border);color:var(--muted);}
.btn-ghost:hover{color:var(--off);}
.btn-red{background:var(--red-dim);border:1px solid rgba(192,57,43,0.3);color:#e07070;}
.btn-sm{padding:0.35rem 0.75rem;font-size:0.75rem;}

/* ── Table ── */
.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;font-size:0.85rem;}
th{text-align:left;padding:0.65rem 1rem;font-family:var(--mono);font-size:0.62rem;color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;border-bottom:1px solid var(--border);white-space:nowrap;}
td{padding:0.8rem 1rem;border-bottom:1px solid rgba(245,242,235,0.04);vertical-align:middle;}
tr:last-child td{border-bottom:none;}
tr:hover td{background:rgba(245,242,235,0.02);}

/* ── Pills ── */
.pill{display:inline-block;font-family:var(--mono);font-size:0.62rem;font-weight:600;letter-spacing:0.05em;padding:0.2rem 0.55rem;border-radius:999px;}
.pill-green{background:var(--green-dim);color:var(--green);}
.pill-amber{background:var(--amber-dim);color:var(--amber);}
.pill-accent{background:var(--accent-dim);color:var(--accent);}
.pill-red{background:var(--red-dim);color:#e07070;}
.pill-muted{background:rgba(107,104,96,0.15);color:var(--muted);}

/* inline form in table */
.inline-form{display:flex;align-items:center;gap:0.4rem;flex-wrap:wrap;}
.inline-form select{background:rgba(245,242,235,0.05);border:1px solid var(--border);color:var(--off);border-radius:6px;padding:0.3rem 0.5rem;font-size:0.78rem;font-family:'DM Sans',sans-serif;outline:none;}
.inline-form select option{background:var(--mid);}

/* ── Collapsible partner rows ── */
.partner-row td{vertical-align:top;}
.expand-btn{background:none;border:none;color:var(--muted);cursor:pointer;font-size:0.8rem;padding:0.2rem 0.4rem;border-radius:4px;transition:color 0.1s;}
.expand-btn:hover{color:var(--off);}
.sub-table{display:none;background:rgba(245,242,235,0.02);border-radius:8px;margin-top:0.5rem;overflow:hidden;}
.sub-table.open{display:block;}
.sub-table table th{font-size:0.58rem;}
.sub-table table td{font-size:0.8rem;padding:0.6rem 0.85rem;}

/* ── Responsive ── */
@media(max-width:768px){
    .sidebar{display:none;}
    .main{margin-left:0;padding:1rem;}
    .stats-grid{grid-template-columns:repeat(2,1fr);}
    .form-grid{grid-template-columns:1fr;}
}
</style>
<link rel="stylesheet" href="../assets/fontawesome.css">
</head>
<body>

<!-- SIDEBAR -->
<aside class="sidebar">
    <div>
        <div class="logo">RIDGE<span>.</span></div>
        <div class="logo-sub">Admin Panel</div>
    </div>
    <nav>
        <div class="section-label">Main</div>
        <a href="?tab=overview"   class="<?= $active_tab==='overview'   ?'active':'' ?>">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
            Overview
        </a>
        <a href="?tab=partners"   class="<?= $active_tab==='partners'   ?'active':'' ?>">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            Partners
        </a>
        <a href="?tab=riders"     class="<?= $active_tab==='riders'     ?'active':'' ?>">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="5"/><path d="M3 21v-2a7 7 0 0 1 14 0v2"/></svg>
            Riders
        </a>
        <a href="?tab=deliveries" class="<?= $active_tab==='deliveries' ?'active':'' ?>">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16.5 9.4l-9-5.19M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
            Deliveries
        </a>
        <div class="section-label">Admin</div>
        <a href="?tab=admins"     class="<?= $active_tab==='admins'     ?'active':'' ?>">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            Admins
        </a>
    </nav>
    <div class="admin-badge">
        <strong><?= htmlspecialchars($admin_name) ?></strong>
        Super Admin
        <br><a href="?logout=1"><i class="fas fa-arrow-left"></i> Logout</a>
    </div>
</aside>

<!-- MAIN -->
<main class="main">

<?php if ($success): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-error"><i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<!-- ══════════════════ OVERVIEW ══════════════════ -->
<?php if ($active_tab === 'overview'): ?>
<div class="page-title">Overview</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-label">Partners</div>
        <div class="stat-num"><?= $stats['partners'] ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Riders</div>
        <div class="stat-num"><?= $stats['riders'] ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Total Deliveries</div>
        <div class="stat-num"><?= $stats['deliveries'] ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Delivered</div>
        <div class="stat-num green"><?= $stats['delivered'] ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">En Route</div>
        <div class="stat-num accent"><?= $stats['enroute'] ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Pending</div>
        <div class="stat-num amber"><?= $stats['pending'] ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Returned to Last Mile</div>
        <div class="stat-num" style="color:#ff9d9d"><?= $stats['returned'] ?></div>
    </div>
</div>

<!-- Recent deliveries on overview -->
<div class="section">
    <div class="section-head">
        <h2>Recent Deliveries</h2>
        <a href="?tab=deliveries" class="btn btn-ghost btn-sm">View All</a>
    </div>
    <div class="table-wrap">
    <table>
        <thead><tr>
            <th>Tracking</th><th>Recipient</th><th>Partner</th><th>Rider</th><th>Status</th><th>Date</th>
        </tr></thead>
        <tbody>
        <?php
        $recent = $conn->query("SELECT d.tracking_id, d.recipient_name, d.status, d.created_at, p.company_name, r.rider_name FROM deliveries d LEFT JOIN partners p ON p.id=d.partner_id LEFT JOIN riders r ON r.id=d.rider_id ORDER BY d.created_at DESC LIMIT 10");
        while ($r = $recent->fetch_assoc()):
            $pill = match($r['status']) {
                'delivered'=>'pill-green','enroute'=>'pill-accent',
                'pending'=>'pill-amber','returned'=>'pill-red','cancelled'=>'pill-red',default=>'pill-muted'
            };
        ?>
        <tr>
            <td><span style="font-family:var(--mono);font-size:0.78rem;"><?= htmlspecialchars($r['tracking_id']) ?></span></td>
            <td><?= htmlspecialchars($r['recipient_name']) ?></td>
            <td style="color:var(--muted);font-size:0.82rem;"><?= htmlspecialchars($r['company_name'] ?? '—') ?></td>
            <td style="color:var(--muted);font-size:0.82rem;"><?= htmlspecialchars($r['rider_name'] ?? 'Unassigned') ?></td>
            <td><span class="pill <?= $pill ?>"><?= h(ridge_delivery_status_label((string)$r['status'])) ?></span></td>
            <td style="font-family:var(--mono);font-size:0.75rem;color:var(--muted);"><?= date('d M Y', strtotime($r['created_at'])) ?></td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- ══════════════════ PARTNERS ══════════════════ -->
<?php elseif ($active_tab === 'partners'): ?>
<div class="page-title">Partners</div>

<!-- Create partner form -->
<div class="section">
    <div class="section-head"><h2>Create New Partner</h2></div>
    <div class="section-body">
    <form method="POST">
        <div class="form-grid">
            <div class="field"><label>Company Name</label><input type="text" name="company_name" required></div>
            <div class="field"><label>Contact Person</label><input type="text" name="contact_person" required></div>
            <div class="field"><label>Email (login)</label><input type="email" name="email" required></div>
            <div class="field"><label>Phone</label><input type="tel" name="phone" required></div>
            <div class="field"><label>Password</label><input type="password" name="password" required placeholder="Set login password"></div>
            <div class="field"><label>No. of Dispatchers</label><input type="number" name="num_dispatchers" value="1" min="1"></div>
            <div class="field" style="grid-column:1/-1"><label>Company Address</label><textarea name="company_address" rows="2" required></textarea></div>
        </div>
        <div class="form-footer">
            <button type="submit" name="create_partner" class="btn btn-accent">Create Partner</button>
        </div>
    </form>
    </div>
</div>

<!-- Partners table with collapsible riders -->
<div class="section">
    <div class="section-head"><h2>All Partners</h2><span style="font-family:var(--mono);font-size:0.72rem;color:var(--muted);"><?= $stats['partners'] ?> total</span></div>
    <div class="table-wrap">
    <table>
        <thead><tr>
            <th></th><th>Company</th><th>Contact</th><th>Email</th><th>Phone</th><th>Riders</th><th>Deliveries</th><th>Status</th><th>Actions</th>
        </tr></thead>
        <tbody>
        <?php
        $partners->data_seek(0);
        while ($p = $partners->fetch_assoc()):
            $p_riders   = $conn->prepare("SELECT * FROM riders WHERE partner_id=?"); $p_riders->bind_param("i",$p['id']); $p_riders->execute(); $p_riders_res = $p_riders->get_result();
            $p_del      = $conn->prepare("SELECT COUNT(*) c FROM deliveries WHERE partner_id=?"); $p_del->bind_param("i",$p['id']); $p_del->execute(); $p_del_cnt = $p_del->get_result()->fetch_assoc()['c'];
            $status_pill = $p['status']==='active' ? 'pill-green' : 'pill-amber';
        ?>
        <tr id="partner-row-<?= $p['id'] ?>">
            <td>
                <button class="expand-btn" onclick="toggleRiders(<?= $p['id'] ?>)" title="Show riders">▸</button>
            </td>
            <td><strong><?= htmlspecialchars($p['company_name']) ?></strong></td>
            <td style="color:var(--muted);font-size:0.83rem;"><?= htmlspecialchars($p['contact_person']) ?></td>
            <td style="font-family:var(--mono);font-size:0.75rem;color:var(--muted);"><?= htmlspecialchars($p['email']) ?></td>
            <td style="font-family:var(--mono);font-size:0.78rem;"><?= htmlspecialchars($p['phone']) ?></td>
            <td style="text-align:center;"><?= $p_riders_res->num_rows ?></td>
            <td style="text-align:center;"><?= $p_del_cnt ?></td>
            <td><span class="pill <?= $status_pill ?>"><?= ucfirst($p['status']) ?></span></td>
            <td>
                <div class="inline-form">
                    <form method="POST" style="display:flex;gap:0.35rem;align-items:center;">
                        <input type="hidden" name="partner_id" value="<?= $p['id'] ?>">
                        <select name="status">
                            <option value="active"  <?= $p['status']==='active'  ?'selected':'' ?>>Active</option>
                            <option value="pending" <?= $p['status']==='pending' ?'selected':'' ?>>Pending</option>
                        </select>
                        <button type="submit" name="update_partner_status" class="btn btn-ghost btn-sm">Save</button>
                    </form>
                    <form method="POST" onsubmit="return confirm('Delete partner and all their data?')">
                        <input type="hidden" name="partner_id" value="<?= $p['id'] ?>">
                        <button type="submit" name="delete_partner" class="btn btn-red btn-sm">Delete</button>
                    </form>
                </div>
                <!-- Collapsible riders -->
                <div class="sub-table" id="riders-<?= $p['id'] ?>">
                    <?php $p_riders_res->data_seek(0); if ($p_riders_res->num_rows): ?>
                    <table>
                        <thead><tr><th>Name</th><th>Phone</th><th>Plate</th><th>Status</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php while ($rr = $p_riders_res->fetch_assoc()):
                            $rs_pill = match($rr['status']){'active'=>'pill-green','on_trip'=>'pill-accent',default=>'pill-muted'};
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($rr['rider_name']) ?></td>
                            <td style="font-family:var(--mono);font-size:0.75rem;"><?= htmlspecialchars($rr['phone']) ?></td>
                            <td style="font-family:var(--mono);font-size:0.75rem;"><?= htmlspecialchars($rr['bike_plate']) ?></td>
                            <td><span class="pill <?= $rs_pill ?>"><?= $rr['status'] ?></span></td>
                            <td>
                                <form method="POST" style="display:flex;gap:0.3rem;" onsubmit="return confirm('Remove this rider?')">
                                    <input type="hidden" name="rider_id" value="<?= $rr['id'] ?>">
                                    <button type="submit" name="delete_rider" class="btn btn-red btn-sm">Remove</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div style="padding:0.75rem 1rem;font-size:0.8rem;color:var(--muted);">No riders yet for this partner.</div>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- ══════════════════ RIDERS ══════════════════ -->
<?php elseif ($active_tab === 'riders'): ?>
<div class="page-title">Riders</div>

<div class="section">
    <div class="section-head">
        <h2>All Riders</h2>
        <span style="font-family:var(--mono);font-size:0.72rem;color:var(--muted);"><?= $stats['riders'] ?> total · Admin cannot create riders (partners do)</span>
    </div>
    <div class="table-wrap">
    <table>
        <thead><tr>
            <th>Name</th><th>Partner</th><th>Email</th><th>Phone</th><th>Plate</th><th>Status</th><th>Joined</th><th>Actions</th>
        </tr></thead>
        <tbody>
        <?php $riders->data_seek(0); while ($r = $riders->fetch_assoc()):
            $rs_pill = match($r['status']){'active'=>'pill-green','on_trip'=>'pill-accent',default=>'pill-muted'};
        ?>
        <tr>
            <td><strong><?= htmlspecialchars($r['rider_name']) ?></strong></td>
            <td style="color:var(--muted);font-size:0.82rem;"><?= htmlspecialchars($r['company_name'] ?? '—') ?></td>
            <td style="font-family:var(--mono);font-size:0.75rem;color:var(--muted);"><?= htmlspecialchars($r['email'] ?? '—') ?></td>
            <td style="font-family:var(--mono);font-size:0.78rem;"><?= htmlspecialchars($r['phone']) ?></td>
            <td style="font-family:var(--mono);font-size:0.78rem;"><?= htmlspecialchars($r['bike_plate']) ?></td>
            <td>
                <form method="POST" class="inline-form">
                    <input type="hidden" name="rider_id" value="<?= $r['id'] ?>">
                    <select name="status">
                        <option value="active"   <?= $r['status']==='active'   ?'selected':'' ?>>Active</option>
                        <option value="inactive" <?= $r['status']==='inactive' ?'selected':'' ?>>Inactive</option>
                        <option value="on_trip"  <?= $r['status']==='on_trip'  ?'selected':'' ?>>On Trip</option>
                    </select>
                    <button type="submit" name="update_rider_status" class="btn btn-ghost btn-sm">Save</button>
                </form>
            </td>
            <td style="font-family:var(--mono);font-size:0.72rem;color:var(--muted);"><?= date('d M Y', strtotime($r['created_at'])) ?></td>
            <td>
                <form method="POST" onsubmit="return confirm('Remove rider <?= htmlspecialchars(addslashes($r['rider_name'])) ?>?')">
                    <input type="hidden" name="rider_id" value="<?= $r['id'] ?>">
                    <button type="submit" name="delete_rider" class="btn btn-red btn-sm">Remove</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- ══════════════════ DELIVERIES ══════════════════ -->
<?php elseif ($active_tab === 'deliveries'): ?>
<div class="page-title">Deliveries</div>

<div class="section">
    <div class="section-head">
        <h2>All Deliveries</h2>
        <span style="font-family:var(--mono);font-size:0.72rem;color:var(--muted);"><?= $stats['deliveries'] ?> total (showing last 200)</span>
    </div>
    <div class="table-wrap">
    <table>
        <thead><tr>
            <th>Tracking</th><th>Recipient</th><th>Address</th><th>Partner</th><th>Rider</th><th>Status</th><th>Assign Rider</th><th>Date</th>
        </tr></thead>
        <tbody>
        <?php $deliveries->data_seek(0); while ($d = $deliveries->fetch_assoc()):
            $dp = match($d['status']){'delivered'=>'pill-green','enroute'=>'pill-accent','pending'=>'pill-amber','returned'=>'pill-red','cancelled'=>'pill-red',default=>'pill-muted'};
        ?>
        <tr>
            <td><span style="font-family:var(--mono);font-size:0.75rem;"><?= htmlspecialchars($d['tracking_id']) ?></span></td>
            <td>
                <div style="font-weight:600;font-size:0.87rem;"><?= htmlspecialchars($d['recipient_name']) ?></div>
                <div style="font-size:0.75rem;color:var(--muted);"><?= htmlspecialchars($d['recipient_phone']) ?></div>
            </td>
            <td style="font-size:0.78rem;color:var(--muted);max-width:160px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($d['recipient_address']) ?></td>
            <td style="font-size:0.82rem;color:var(--muted);"><?= htmlspecialchars($d['company_name'] ?? '—') ?></td>
            <td style="font-size:0.82rem;"><?= htmlspecialchars($d['rider_name'] ?? '<span style="color:var(--muted)">Unassigned</span>') ?></td>
            <td>
                <form method="POST" class="inline-form">
                    <input type="hidden" name="delivery_id" value="<?= $d['id'] ?>">
                    <select name="status">
                        <?php foreach(['pending','assigned','enroute','returned','delivered','cancelled'] as $st): ?>
                        <option value="<?= $st ?>" <?= $d['status']===$st?'selected':'' ?>><?= h(ridge_delivery_status_label($st)) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" name="update_delivery_status" class="btn btn-ghost btn-sm">Save</button>
                </form>
            </td>
            <td>
                <form method="POST" class="inline-form">
                    <input type="hidden" name="delivery_id" value="<?= $d['id'] ?>">
                    <select name="rider_id">
                        <option value="">— pick rider —</option>
                        <?php foreach ($riders_arr as $ra): ?>
                        <option value="<?= $ra['id'] ?>" <?= $d['rider_id']==$ra['id']?'selected':'' ?>><?= htmlspecialchars($ra['rider_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" name="assign_rider" class="btn btn-green btn-sm">Assign</button>
                </form>
            </td>
            <td style="font-family:var(--mono);font-size:0.72rem;color:var(--muted);white-space:nowrap;"><?= date('d M Y', strtotime($d['created_at'])) ?></td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- ══════════════════ ADMINS ══════════════════ -->
<?php elseif ($active_tab === 'admins'): ?>
<div class="page-title">Admins</div>

<div class="section">
    <div class="section-head"><h2>Create New Admin</h2></div>
    <div class="section-body">
    <form method="POST">
        <div class="form-grid">
            <div class="field"><label>Full Name</label><input type="text" name="admin_name" required></div>
            <div class="field"><label>Email</label><input type="email" name="admin_email" required></div>
            <div class="field"><label>Password</label><input type="password" name="admin_password" required placeholder="Set a strong password"></div>
        </div>
        <div class="form-footer">
            <button type="submit" name="create_admin" class="btn btn-accent">Create Admin</button>
        </div>
    </form>
    </div>
</div>

<div class="section">
    <div class="section-head"><h2>All Admins</h2></div>
    <div class="table-wrap">
    <table>
        <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Created</th></tr></thead>
        <tbody>
        <?php while ($a = $admins->fetch_assoc()): ?>
        <tr>
            <td style="font-family:var(--mono);font-size:0.75rem;color:var(--muted);"><?= $a['id'] ?></td>
            <td><strong><?= htmlspecialchars($a['name']) ?></strong> <?= $a['id']==$_SESSION['admin_id'] ? '<span class="pill pill-green" style="font-size:0.58rem;">You</span>' : '' ?></td>
            <td style="font-family:var(--mono);font-size:0.78rem;color:var(--muted);"><?= htmlspecialchars($a['email']) ?></td>
            <td style="font-family:var(--mono);font-size:0.72rem;color:var(--muted);"><?= date('d M Y', strtotime($a['created_at'])) ?></td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    </div>
</div>

<?php endif; ?>
</main>

<script>
function toggleRiders(pid) {
    const el  = document.getElementById('riders-' + pid);
    const btn = el.closest('td').querySelector('.expand-btn');
    const open = el.classList.toggle('open');
    btn.textContent = open ? '▾' : '▸';
}
</script>
</body>
</html>