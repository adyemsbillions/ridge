<?php
/**
 * Emergency admin recovery utility.
 * Production-safe default: disabled.
 *
 * To use it:
 * 1. Change $enabled to true.
 * 2. Set a temporary email and strong password below.
 * 3. Upload/open this file once.
 * 4. Change $enabled back to false or delete the file immediately.
 */
$enabled = false;
$name = 'Super Admin';
$email = 'admin@ridge.ng';
$password = 'CHANGE-THIS-BEFORE-USE';

if (!$enabled) {
    http_response_code(403);
    exit('Admin recovery is disabled. Edit me/make_admin.php from cPanel and enable it temporarily, then disable or delete it immediately after use.');
}
if ($password === 'CHANGE-THIS-BEFORE-USE' || strlen($password) < 12) {
    http_response_code(400);
    exit('Set a unique temporary password of at least 12 characters before enabling this utility.');
}

require_once '../db.php';
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO admins (name,email,password) VALUES (?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),password=VALUES(password)");
if (!$stmt) { http_response_code(500); exit('Unable to prepare the admin recovery request.'); }
$stmt->bind_param('sss',$name,$email,$hash);
if (!$stmt->execute()) { http_response_code(500); exit('Admin recovery failed. Check ridge-errors.log.'); }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RIDGE Admin Recovery</title></head><body style="font-family:system-ui;background:#0a0a0a;color:#f5f2eb;padding:2rem"><main style="max-width:620px;margin:auto;background:#141414;border:1px solid #333;border-radius:14px;padding:1.5rem"><h1>Admin account updated</h1><p>Email: <strong><?=htmlspecialchars($email,ENT_QUOTES,'UTF-8')?></strong></p><p style="color:#ff9d9d"><strong>Disable or delete this file immediately, then sign in and change the temporary password.</strong></p><a style="color:#ff7b3d" href="admin_login.php">Go to admin login</a></main></body></html>
