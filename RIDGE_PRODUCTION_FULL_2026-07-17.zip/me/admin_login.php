<?php
require_once '../includes/bootstrap.php';

if (isset($_SESSION['admin_id'])) {
    ridge_redirect('admin.php');
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ridge_require_csrf();
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT id, name, password FROM admins WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $admin = $stmt->get_result()->fetch_assoc();

    if ($admin && password_verify($password, $admin['password'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = (int) $admin['id'];
        $_SESSION['admin_name'] = (string) $admin['name'];
        ridge_redirect('admin.php');
    } else {
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login — RIDGE</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
:root {
    --black:#0A0A0A; --mid:#141414; --card:#111111;
    --border:rgba(245,242,235,0.10); --off:#F5F2EB;
    --muted:#6B6860; --accent:#E8500A; --accent-dim:rgba(232,80,10,0.15);
    --green:#1D9E75; --mono:'JetBrains Mono',monospace;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{background:var(--black);color:var(--off);font-family:'DM Sans',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1.5rem;}

.login-box{width:100%;max-width:400px;}
.logo{font-family:'Bebas Neue',sans-serif;font-size:2.8rem;letter-spacing:0.08em;text-align:center;margin-bottom:0.2rem;}
.logo span{color:var(--accent);}
.sub{text-align:center;font-family:var(--mono);font-size:0.72rem;color:var(--muted);margin-bottom:2.5rem;letter-spacing:0.08em;text-transform:uppercase;}

.card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:2rem;}
label{display:block;font-size:0.75rem;font-family:var(--mono);color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:0.4rem;}
input{
    width:100%;background:rgba(245,242,235,0.05);border:1px solid var(--border);
    color:var(--off);border-radius:8px;padding:0.8rem 1rem;
    font-family:'DM Sans',sans-serif;font-size:0.92rem;outline:none;
    transition:border-color 0.15s;margin-bottom:1.25rem;
}
input:focus{border-color:rgba(232,80,10,0.5);}
.btn{width:100%;padding:0.95rem;background:var(--accent);color:white;border:none;border-radius:8px;font-family:'DM Sans',sans-serif;font-size:0.95rem;font-weight:600;cursor:pointer;transition:opacity 0.15s;}
.btn:hover{opacity:0.88;}
.error{background:var(--accent-dim);border:1px solid rgba(232,80,10,0.3);color:var(--accent);padding:0.75rem 1rem;border-radius:8px;font-size:0.85rem;margin-bottom:1.25rem;}
</style>
<link rel="stylesheet" href="../assets/fontawesome.css">
</head>
<body>
<div class="login-box">
    <div class="logo">RIDGE<span>.</span></div>
    <div class="sub">Admin Panel</div>
    <div class="card">
        <?php if ($error): ?>
        <div class="error"><i class="fas fa-exclamation-triangle"></i> <?= h($error) ?></div>
        <?php endif; ?>
        <form method="POST">
            <?= ridge_csrf_field() ?>
            <label>Email</label>
            <input type="email" name="email" placeholder="admin@ridge.ng" required autofocus value="<?= h($_POST['email'] ?? '') ?>">
            <label>Password</label>
            <input type="password" name="password" placeholder="••••••••" required>
            <button type="submit" class="btn">Sign In</button>
        </form>
    </div>
</div>
</body>
</html>