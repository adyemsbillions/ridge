<?php
require_once '../includes/bootstrap.php';
ridge_redirect(isset($_SESSION['rider_id']) ? 'rider_dashboard.php' : 'rider_login.php');
