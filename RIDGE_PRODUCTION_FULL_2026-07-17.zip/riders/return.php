<?php
require_once '../includes/bootstrap.php';
require_once '../includes/notifications.php';

ridge_csrf_token();

if (!isset($_SESSION['rider_id']) || !isset($_GET['id'])) {
    ridge_redirect('rider_login.php');
}

$deliveryId = (int) $_GET['id'];
$riderId = (int) $_SESSION['rider_id'];
$stmt = $conn->prepare("SELECT d.*, r.rider_name FROM deliveries d JOIN riders r ON r.id=d.rider_id WHERE d.id=? AND d.rider_id=? LIMIT 1");
$stmt->bind_param('ii', $deliveryId, $riderId);
$stmt->execute();
$delivery = $stmt->get_result()->fetch_assoc();

if (!$delivery) {
    http_response_code(404);
    exit('Delivery not found or no longer assigned to you.');
}

if (!in_array((string) $delivery['status'], ['assigned', 'enroute'], true)) {
    ridge_redirect('my_deliveries.php');
}

$feedback = null;
$completed = false;
$reasonOptions = ridge_return_reason_options();
$selectedReason = (string) ($_POST['return_reason'] ?? '');
$notes = trim((string) ($_POST['return_notes'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!ridge_verify_csrf()) {
        $feedback = ['type' => 'error', 'text' => 'Your session expired. Refresh the page and try again.'];
    } elseif (!isset($reasonOptions[$selectedReason])) {
        $feedback = ['type' => 'error', 'text' => 'Select a valid reason for the return.'];
    } elseif ($selectedReason === 'other' && $notes === '') {
        $feedback = ['type' => 'error', 'text' => 'Add a short explanation when you select “Other reason”.'];
    } elseif (ridge_mark_delivery_returned($conn, $deliveryId, $riderId, $selectedReason, $notes)) {
        $fresh = $conn->prepare('SELECT * FROM deliveries WHERE id=? LIMIT 1');
        $fresh->bind_param('i', $deliveryId);
        $fresh->execute();
        if ($returnedDelivery = $fresh->get_result()->fetch_assoc()) {
            ridge_notify_delivery_status($conn, $returnedDelivery, 'returned', (string) $delivery['rider_name']);
        }
        $completed = true;
        $feedback = [
            'type' => 'success',
            'text' => 'The item has been returned to the last-mile queue. The sender notification has been processed and the partner can now reassign it.',
        ];
    } else {
        $feedback = ['type' => 'error', 'text' => 'The item could not be returned. It may already have been updated or reassigned.'];
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#E8500A">
<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
<title>Return Item — RIDGE</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/fontawesome.css">
<style>
:root{--black:#0A0A0A;--mid:#141414;--card:#111;--border:rgba(245,242,235,.1);--off:#F5F2EB;--muted:#77736b;--accent:#E8500A;--accent-soft:rgba(232,80,10,.14);--green:#1D9E75;--green-soft:rgba(29,158,117,.14);--red:#d45555;--red-soft:rgba(212,85,85,.13);--mono:'JetBrains Mono',monospace}
*{box-sizing:border-box}body{margin:0;background:var(--black);color:var(--off);font-family:'DM Sans',sans-serif;min-height:100vh}.topbar{display:flex;align-items:center;justify-content:space-between;padding:.95rem 1.2rem;background:var(--mid);border-bottom:1px solid var(--border)}.brand{font-family:'Bebas Neue';font-size:1.55rem;letter-spacing:.07em}.brand span{color:var(--accent)}.tracking{font:500 .68rem var(--mono);color:var(--muted)}main{width:min(100%,540px);margin:auto;padding:1.3rem}.eyebrow{font:600 .65rem var(--mono);letter-spacing:.09em;text-transform:uppercase;color:var(--accent)}h1{font-family:'Bebas Neue';font-size:2.45rem;font-weight:400;letter-spacing:.03em;margin:.45rem 0}.lead{color:var(--muted);line-height:1.6;margin:0 0 1rem}.card{background:var(--card);border:1px solid var(--border);border-radius:15px;padding:1.15rem;margin-bottom:1rem}.summary{display:grid;grid-template-columns:1fr 1fr;gap:.7rem}.detail{background:rgba(245,242,235,.035);border:1px solid var(--border);border-radius:10px;padding:.8rem}.detail.full{grid-column:1/-1}.detail small,label{display:block;font:500 .62rem var(--mono);letter-spacing:.06em;text-transform:uppercase;color:var(--muted);margin-bottom:.35rem}.detail strong{font-size:.9rem;line-height:1.4}.field{margin-bottom:1rem}.field select,.field textarea{width:100%;background:rgba(245,242,235,.05);border:1px solid var(--border);border-radius:10px;color:var(--off);padding:.85rem;font:inherit;outline:none}.field select:focus,.field textarea:focus{border-color:rgba(232,80,10,.6)}.field select option{background:var(--mid)}.help{font-size:.76rem;color:var(--muted);line-height:1.5;margin-top:.4rem}.alert{padding:.85rem 1rem;border-radius:10px;margin-bottom:1rem;font-size:.86rem;line-height:1.5}.alert-success{background:var(--green-soft);border:1px solid rgba(29,158,117,.3);color:#69d3ad}.alert-error{background:var(--red-soft);border:1px solid rgba(212,85,85,.3);color:#ff9d9d}.warning{background:var(--accent-soft);border:1px solid rgba(232,80,10,.28);border-radius:10px;padding:.85rem;font-size:.8rem;line-height:1.55;color:#f6a27a;margin-bottom:1rem}.actions{display:flex;flex-direction:column;gap:.6rem}.btn{display:flex;align-items:center;justify-content:center;gap:.5rem;width:100%;border:0;border-radius:10px;padding:.9rem;font:700 .92rem 'DM Sans';text-decoration:none;cursor:pointer}.btn-return{background:var(--red);color:#fff}.btn-ghost{background:transparent;border:1px solid var(--border);color:var(--muted)}@media(max-width:480px){.summary{grid-template-columns:1fr}.detail.full{grid-column:auto}}
</style>
</head>
<body>
<header class="topbar"><div class="brand">RIDGE<span>.</span></div><div class="tracking"><?=h($delivery['tracking_id'])?></div></header>
<main>
<div class="eyebrow">Last-mile return</div>
<h1><?= $completed ? 'Return Recorded' : 'Return Item' ?></h1>
<p class="lead"><?= $completed ? 'The package is now with the partner’s last-mile return queue.' : 'Use this only when the delivery cannot be completed. A reason is required and will be shared with the sender.' ?></p>

<?php if($feedback):?><div class="alert alert-<?=h($feedback['type'])?>"><?=h($feedback['text'])?></div><?php endif;?>

<section class="card"><div class="summary">
<div class="detail"><small>Recipient</small><strong><?=h($delivery['recipient_name'])?></strong></div>
<div class="detail"><small>Phone</small><strong><?=h($delivery['recipient_phone'])?></strong></div>
<div class="detail full"><small>Address</small><strong><?=h($delivery['recipient_address'])?></strong></div>
<div class="detail full"><small>Package</small><strong><?=h($delivery['package_description'])?></strong></div>
</div></section>

<?php if(!$completed):?>
<section class="card">
<div class="warning">Submitting this form removes the item from your active deliveries and sends it to the partner’s returned-item queue for review and reassignment.</div>
<form method="post">
<?=ridge_csrf_field()?>
<div class="field"><label for="return_reason">Reason for return</label><select id="return_reason" name="return_reason" required><option value="">Select reason…</option><?php foreach($reasonOptions as $code=>$label):?><option value="<?=h($code)?>" <?=$selectedReason===$code?'selected':''?>><?=h($label)?></option><?php endforeach;?></select></div>
<div class="field"><label for="return_notes">Additional details</label><textarea id="return_notes" name="return_notes" rows="4" maxlength="1000" placeholder="Add helpful details for the partner and sender."><?=h($notes)?></textarea><div class="help">Details are optional except when “Other reason” is selected. Do not include sensitive information.</div></div>
<div class="actions"><button class="btn btn-return" type="submit"><i class="fas fa-warehouse"></i> Confirm return to last mile</button><a class="btn btn-ghost" href="deliver.php?id=<?=$deliveryId?>"><i class="fas fa-arrow-left"></i> Cancel and go back</a></div>
</form>
</section>
<?php else:?><div class="actions"><a class="btn btn-ghost" href="my_deliveries.php"><i class="fas fa-box"></i> Back to my deliveries</a></div><?php endif;?>
</main>
<script src="pwa.js"></script>
</body>
</html>
