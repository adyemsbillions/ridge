<?php
require_once '../includes/bootstrap.php';
require_once '../includes/notifications.php';
ridge_csrf_token();
if (!isset($_SESSION['rider_id']) || !isset($_GET['id'])) ridge_redirect('rider_login.php');
$deliveryId=(int)$_GET['id'];$riderId=(int)$_SESSION['rider_id'];
$stmt=$conn->prepare("SELECT d.*,r.rider_name FROM deliveries d JOIN riders r ON r.id=d.rider_id WHERE d.id=? AND d.rider_id=? LIMIT 1");
$stmt->bind_param('ii',$deliveryId,$riderId);$stmt->execute();$delivery=$stmt->get_result()->fetch_assoc();
if(!$delivery){http_response_code(404);exit('Delivery not found.');}
if($delivery['status']==='delivered') ridge_redirect('my_deliveries.php');
$feedback=null;$step='send';$cooldownKey='otp_last_sent_'.$deliveryId;$attemptKey='otp_attempts_'.$deliveryId;
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!ridge_verify_csrf()){$feedback=['type'=>'error','text'=>'Your session expired. Refresh and try again.'];}
  elseif(isset($_POST['send_otp'])){
    $last=(int)($_SESSION[$cooldownKey]??0);
    if(time()-$last<30){$feedback=['type'=>'error','text'=>'Please wait 30 seconds before requesting another code.'];}
    else{
      $otp=str_pad((string)random_int(0,999999),6,'0',STR_PAD_LEFT);$expires=date('Y-m-d H:i:s',time()+600);
      $save=$conn->prepare('UPDATE deliveries SET delivery_otp=?,otp_expires_at=? WHERE id=? AND rider_id=?');$save->bind_param('ssii',$otp,$expires,$deliveryId,$riderId);
      if($save->execute()){
        $message="Your RIDGE delivery code is {$otp}. Give it only to the rider at delivery. It expires in 10 minutes.";
        $result=ridge_notify_once($conn,$deliveryId,'delivery_otp_'.$otp,(string)$delivery['recipient_phone'],$message);
        if($result['ok']){$_SESSION[$cooldownKey]=time();$_SESSION[$attemptKey]=0;$step='verify';$feedback=['type'=>'success','text'=>'Code sent to '.ridge_mask_phone((string)$delivery['recipient_phone']).'.'];}
        else{$clear=$conn->prepare('UPDATE deliveries SET delivery_otp=NULL,otp_expires_at=NULL WHERE id=?');$clear->bind_param('i',$deliveryId);$clear->execute();$feedback=['type'=>'error','text'=>'The SMS could not be sent. Check the number or SMS configuration and retry.'];}
      }else{$feedback=['type'=>'error','text'=>'The code could not be created. Please retry.'];}
    }
  }elseif(isset($_POST['verify_otp'])){
    $entered=preg_replace('/\D+/','',(string)($_POST['otp_code']??''))??'';
    $check=$conn->prepare('SELECT delivery_otp,otp_expires_at,status FROM deliveries WHERE id=? AND rider_id=? LIMIT 1');$check->bind_param('ii',$deliveryId,$riderId);$check->execute();$row=$check->get_result()->fetch_assoc();
    $stored=(string)($row['delivery_otp']??'');$expires=(string)($row['otp_expires_at']??'');$attempts=(int)($_SESSION[$attemptKey]??0);
    if($attempts>=5){$feedback=['type'=>'error','text'=>'Too many incorrect attempts. Request a new code.'];$step='send';}
    elseif($stored===''){$feedback=['type'=>'error','text'=>'No active code was found. Request a new code.'];}
    elseif($expires===''||strtotime($expires)<time()){$clear=$conn->prepare('UPDATE deliveries SET delivery_otp=NULL,otp_expires_at=NULL WHERE id=?');$clear->bind_param('i',$deliveryId);$clear->execute();$feedback=['type'=>'error','text'=>'The code expired. Request a new code.'];}
    elseif(strlen($entered)!==6||!hash_equals($stored,$entered)){$_SESSION[$attemptKey]=$attempts+1;$remaining=max(0,5-$_SESSION[$attemptKey]);$feedback=['type'=>'error','text'=>'Incorrect code. '.$remaining.' attempt'.($remaining===1?'':'s').' remaining.'];$step='verify';}
    else{
      $clear=$conn->prepare('UPDATE deliveries SET delivery_otp=NULL,otp_expires_at=NULL WHERE id=?');$clear->bind_param('i',$deliveryId);$clear->execute();
      ridge_set_delivery_status($conn,$deliveryId,'delivered','rider',$riderId,'Recipient supplied the correct delivery OTP.');
      $delivery['status']='delivered';$delivery['delivered_at']=date('Y-m-d H:i:s');ridge_notify_delivery_status($conn,$delivery,'delivered',(string)$delivery['rider_name']);
      unset($_SESSION[$attemptKey],$_SESSION[$cooldownKey]);$step='done';$feedback=['type'=>'success','text'=>'Delivery confirmed. Sender and recipient notifications were processed.'];
    }
  }
}
$fresh=$conn->prepare('SELECT delivery_otp,otp_expires_at,status FROM deliveries WHERE id=? LIMIT 1');$fresh->bind_param('i',$deliveryId);$fresh->execute();$freshRow=$fresh->get_result()->fetch_assoc();
if(($freshRow['status']??'')==='delivered')$step='done';elseif(!empty($freshRow['delivery_otp'])&&!empty($freshRow['otp_expires_at'])&&strtotime($freshRow['otp_expires_at'])>time())$step='verify';
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#E8500A"><link rel="manifest" href="manifest.webmanifest"><link rel="apple-touch-icon" href="icons/apple-touch-icon.png"><title>Confirm Delivery — RIDGE</title><link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/fontawesome.css"><link rel="stylesheet" href="../assets/portal.css"><style>
body{min-height:100vh;background:radial-gradient(circle at 50% 0,rgba(232,80,10,.14),transparent 38%),var(--black)}.otp-top{height:66px;display:flex;align-items:center;justify-content:space-between;padding:0 1.1rem;background:rgba(18,18,18,.92);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:20}.otp-page{width:min(100%,560px);margin:auto;padding:1.25rem 1rem 3rem}.otp-progress{display:grid;grid-template-columns:1fr 28px 1fr 28px 1fr;align-items:center;margin:0 0 1rem}.otp-step{text-align:center;color:var(--muted);font:600 .62rem var(--mono);text-transform:uppercase}.otp-step i{width:34px;height:34px;border-radius:50%;border:1px solid var(--border);display:grid;place-items:center;margin:0 auto .35rem}.otp-step.active{color:var(--off)}.otp-step.active i{background:var(--accent);border-color:var(--accent);color:#fff}.otp-step.done i{background:var(--green);border-color:var(--green);color:#fff}.otp-line{height:1px;background:var(--border);margin-top:-18px}.delivery-summary{display:grid;gap:.65rem}.summary-row{display:grid;grid-template-columns:38px 1fr;gap:.75rem;align-items:start;padding:.75rem;border:1px solid var(--border);background:rgba(245,242,235,.025);border-radius:10px}.summary-row i{width:36px;height:36px;border-radius:9px;background:var(--accent-soft);display:grid;place-items:center;color:var(--accent)}.summary-row small{display:block;color:var(--muted);font:500 .61rem var(--mono);text-transform:uppercase;letter-spacing:.06em;margin-bottom:.2rem}.summary-row strong{font-size:.9rem;line-height:1.45}.otp-panel{text-align:center;padding:1.4rem}.otp-hero-icon{width:62px;height:62px;border-radius:18px;background:var(--accent-soft);display:grid;place-items:center;color:var(--accent);font-size:1.5rem;margin:0 auto 1rem}.otp-panel h1{font-family:'Bebas Neue';font-size:2rem;font-weight:400;letter-spacing:.03em;margin:.2rem 0}.otp-panel p{color:var(--muted);line-height:1.6;font-size:.88rem;margin:.35rem auto 1.1rem;max-width:390px}.otp-input{width:100%;background:#0d0d0d;border:2px solid var(--border);color:var(--off);border-radius:12px;padding:1rem .65rem;font:600 clamp(1.7rem,8vw,2.25rem) var(--mono);letter-spacing:.25em;text-align:center;outline:none}.otp-input:focus{border-color:var(--accent);box-shadow:0 0 0 4px rgba(232,80,10,.12)}.button-stack{display:grid;gap:.65rem;margin-top:1rem}.done-icon{background:var(--green-soft);color:var(--green)}.tracking{font:600 .67rem var(--mono);color:var(--muted)}
</style></head><body><header class="otp-top"><a class="brand" href="rider_dashboard.php">RIDGE<span>.</span></a><span class="tracking"><?=h($delivery['tracking_id'])?></span></header><main class="otp-page">
<div class="otp-progress"><div class="otp-step <?=$step==='send'?'active':'done'?>"><i class="fas <?=$step==='send'?'fa-paper-plane':'fa-check'?>"></i>Send</div><div class="otp-line"></div><div class="otp-step <?=$step==='verify'?'active':($step==='done'?'done':'')?>"><i class="fas <?=$step==='done'?'fa-check':'fa-lock'?>"></i>Verify</div><div class="otp-line"></div><div class="otp-step <?=$step==='done'?'done':''?>"><i class="fas fa-clipboard-check"></i>Complete</div></div>
<?php if($feedback):?><div class="alert alert-<?=h($feedback['type'])?>"><i class="fas <?=$feedback['type']==='success'?'fa-check-circle':'fa-exclamation-triangle'?> icon-gap"></i><?=h($feedback['text'])?></div><?php endif;?>
<section class="card"><div class="card-head"><h2>Delivery details</h2></div><div class="card-body delivery-summary"><div class="summary-row"><i class="fas fa-user"></i><div><small>Recipient</small><strong><?=h($delivery['recipient_name'])?></strong></div></div><div class="summary-row"><i class="fas fa-phone"></i><div><small>Phone</small><strong><?=h(ridge_mask_phone((string)$delivery['recipient_phone']))?></strong></div></div><div class="summary-row"><i class="fas fa-map-marker-alt"></i><div><small>Destination</small><strong><?=h($delivery['recipient_address'])?></strong></div></div></div></section>
<section class="card otp-panel">
<?php if($step==='done'):?><div class="otp-hero-icon done-icon"><i class="fas fa-check"></i></div><h1>Delivery complete</h1><p>The recipient code was verified and the delivery has been recorded successfully.</p><a class="btn btn-green" href="my_deliveries.php"><i class="fas fa-box"></i>Back to deliveries</a>
<?php elseif($step==='verify'):?><div class="otp-hero-icon"><i class="fas fa-key"></i></div><h1>Enter the 6-digit code</h1><p>Ask <?=h($delivery['recipient_name'])?> to read the code sent to <?=h(ridge_mask_phone((string)$delivery['recipient_phone']))?>. It expires after 10 minutes.</p><form method="post"><?=ridge_csrf_field()?><input class="otp-input" name="otp_code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]{6}" placeholder="000000" required autofocus><div class="button-stack"><button class="btn btn-green" name="verify_otp" type="submit"><i class="fas fa-clipboard-check"></i>Confirm delivery</button></div></form><form method="post" class="button-stack"><?=ridge_csrf_field()?><button class="btn btn-ghost" name="send_otp" type="submit"><i class="fas fa-redo"></i>Send a new code</button></form>
<?php else:?><div class="otp-hero-icon"><i class="fas fa-paper-plane"></i></div><h1>Send delivery code</h1><p>RIDGE will send a secure one-time code to the recipient. The package should only be handed over after the correct code is entered here.</p><form method="post"><?=ridge_csrf_field()?><div class="button-stack"><button class="btn btn-primary" name="send_otp" type="submit"><i class="fas fa-paper-plane"></i>Send code to recipient</button><a class="btn btn-ghost" href="map.php?id=<?=$deliveryId?>"><i class="fas fa-chevron-left"></i>Back to navigation</a></div></form><?php endif;?></section>
</main><script src="pwa.js"></script></body></html>
