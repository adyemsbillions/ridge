<?php
require_once '../includes/bootstrap.php';
require_once '../includes/notifications.php';
ridge_csrf_token();

if (!isset($_SESSION['rider_id']) || !isset($_GET['id'])) {
    ridge_redirect('rider_login.php');
}

$deliveryId = (int) $_GET['id'];
$riderId = (int) $_SESSION['rider_id'];
$stmt = $conn->prepare("SELECT d.*,p.fuel_price_per_litre,p.fuel_efficiency_km_per_litre
    FROM deliveries d JOIN partners p ON p.id=d.partner_id
    WHERE d.id=? AND d.rider_id=? LIMIT 1");
$stmt->bind_param('ii', $deliveryId, $riderId);
$stmt->execute();
$delivery = $stmt->get_result()->fetch_assoc();
if (!$delivery) {
    http_response_code(404);
    exit('Delivery not found.');
}

if ($delivery['status'] === 'assigned') {
    if (ridge_set_delivery_status($conn, $deliveryId, 'enroute', 'rider', $riderId, 'The rider opened RIDGE navigation and started the trip.')) {
        $delivery['status'] = 'enroute';
        $delivery['enroute_at'] = date('Y-m-d H:i:s');
        ridge_notify_delivery_status($conn, $delivery, 'enroute', (string) ($_SESSION['rider_name'] ?? ''));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    if (!ridge_verify_csrf()) {
        http_response_code(419);
        echo json_encode(['ok' => false, 'error' => 'Session expired']);
        exit;
    }
    if (($_POST['action'] ?? '') !== 'route_metrics') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Unknown action']);
        exit;
    }

    $routeKm = (float) ($_POST['route_km'] ?? 0);
    $baselineKm = (float) ($_POST['baseline_km'] ?? 0);
    $durationMin = (float) ($_POST['duration_min'] ?? 0);
    $baselineDurationMin = (float) ($_POST['baseline_duration_min'] ?? 0);
    if ($routeKm <= 0 || $routeKm > 2000 || $baselineKm < $routeKm || $baselineKm > 3000 || $durationMin <= 0 || $durationMin > 10000) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => 'Invalid route metrics']);
        exit;
    }
    if ($baselineDurationMin < $durationMin) {
        $baselineDurationMin = $durationMin;
    }

    $update = $conn->prepare("UPDATE deliveries SET
        route_distance_km=COALESCE(route_distance_km,?),
        route_baseline_km=COALESCE(route_baseline_km,?),
        route_duration_min=COALESCE(route_duration_min,?),
        route_baseline_duration_min=COALESCE(route_baseline_duration_min,?),
        route_updated_at=NOW()
        WHERE id=? AND rider_id=?");
    $update->bind_param('ddddii', $routeKm, $baselineKm, $durationMin, $baselineDurationMin, $deliveryId, $riderId);
    $ok = $update->execute();
    echo json_encode(['ok' => $ok]);
    exit;
}

$destLat = $delivery['recipient_lat'] ?? null;
$destLng = $delivery['recipient_lng'] ?? null;
if ((!$destLat || !$destLng) && !empty($delivery['recipient_address'])) {
    $addr = urlencode((string) $delivery['recipient_address']);
    $ctx = stream_context_create(['http' => ['header' => "User-Agent: RIDGE-Delivery/2.0\r\n", 'timeout' => 5]]);
    $raw = @file_get_contents("https://photon.komoot.io/api/?q={$addr}&limit=1", false, $ctx);
    $geo = $raw ? json_decode($raw, true) : null;
    if (!empty($geo['features'][0]['geometry']['coordinates'])) {
        $destLng = (float) $geo['features'][0]['geometry']['coordinates'][0];
        $destLat = (float) $geo['features'][0]['geometry']['coordinates'][1];
        $save = $conn->prepare('UPDATE deliveries SET recipient_lat=?,recipient_lng=? WHERE id=?');
        $save->bind_param('ddi', $destLat, $destLng, $deliveryId);
        $save->execute();
    }
}
$hasCoords = is_numeric($destLat) && is_numeric($destLng) && (float)$destLat !== 0.0 && (float)$destLng !== 0.0;
$fuelPrice = max(0, (float) ($delivery['fuel_price_per_litre'] ?? 0));
$fuelEfficiency = max(1, (float) ($delivery['fuel_efficiency_km_per_litre'] ?? ridge_config('fuel_efficiency_km_per_litre', 35)));
$baselineMultiplier = max(1.0, (float) ridge_config('route_baseline_multiplier', 1.15));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#E8500A">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
<title><?=h($delivery['tracking_id'])?> — RIDGE Navigation</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/fontawesome.css">
<link rel="stylesheet" href="../assets/portal.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
body{padding-bottom:max(18px,env(safe-area-inset-bottom));background:#090909}.nav-top{position:sticky;top:0;z-index:900;display:flex;align-items:center;justify-content:space-between;gap:.8rem;padding:.8rem 1rem;background:rgba(12,12,12,.93);backdrop-filter:blur(18px);border-bottom:1px solid var(--border)}.nav-top .brand{font-size:1.55rem}.tracking-meta{text-align:right}.tracking-meta strong{display:block;font:600 .67rem var(--mono);color:var(--off)}.tracking-meta small{font-size:.63rem;color:var(--muted)}.nav-shell{max-width:900px;margin:0 auto}.location-panel{display:grid;grid-template-columns:44px 1fr auto;gap:.8rem;align-items:center;padding:.9rem 1rem;background:linear-gradient(135deg,rgba(232,80,10,.14),rgba(29,158,117,.06));border-bottom:1px solid var(--border)}.location-icon{width:42px;height:42px;border-radius:13px;display:grid;place-items:center;background:var(--accent);color:#fff;box-shadow:0 10px 24px rgba(232,80,10,.25)}.location-copy{min-width:0}.location-copy small{display:block;font:600 .58rem var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin-bottom:.2rem}.location-name{font-size:1.16rem;font-weight:700;line-height:1.25;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.location-detail{font-size:.78rem;color:var(--muted);margin-top:.2rem}.gps-pill{font:600 .58rem var(--mono);padding:.28rem .5rem;border-radius:999px;color:var(--amber);background:rgba(217,134,10,.12);white-space:nowrap}.gps-pill.live{color:#69d3ad;background:rgba(29,158,117,.13)}
.map-wrap{position:relative;height:58vh;min-height:390px;background:#0d1117}.map-wrap #map{position:absolute;inset:0}.map-loader{position:absolute;inset:0;z-index:700;display:grid;place-items:center;background:rgba(9,9,9,.82);transition:opacity .3s}.map-loader.hidden{opacity:0;pointer-events:none}.loader-box{text-align:center}.loader-ring{width:42px;height:42px;border:3px solid rgba(245,242,235,.1);border-top-color:var(--accent);border-radius:50%;animation:spin .9s linear infinite;margin:0 auto .8rem}@keyframes spin{to{transform:rotate(360deg)}}.loader-box p{font:600 .68rem var(--mono);color:var(--muted)}.map-tools{position:absolute;right:10px;top:10px;z-index:750;display:flex;flex-direction:column;gap:.45rem}.map-tool{width:42px;height:42px;border:1px solid rgba(245,242,235,.16);border-radius:12px;background:rgba(17,17,17,.92);color:var(--off);display:grid;place-items:center;cursor:pointer;box-shadow:0 10px 28px rgba(0,0,0,.3)}.map-tool.active{background:var(--accent);border-color:var(--accent)}.map-tool:disabled{opacity:.45}.nav-instruction{display:grid;grid-template-columns:48px 1fr;gap:.85rem;align-items:center;padding:1rem;background:var(--panel);border-bottom:1px solid var(--border)}.maneuver-icon{width:46px;height:46px;border-radius:14px;display:grid;place-items:center;background:var(--accent-soft);color:var(--accent);font-size:1.15rem}.instruction-main{font-size:1rem;font-weight:700;line-height:1.3}.instruction-sub{color:var(--muted);font-size:.73rem;margin-top:.25rem}.route-metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:.55rem;padding:.8rem}.route-metric{background:var(--panel);border:1px solid var(--border);border-radius:12px;padding:.75rem}.route-metric small{display:block;font:600 .53rem var(--mono);text-transform:uppercase;letter-spacing:.07em;color:var(--muted)}.route-metric strong{display:block;font-size:.96rem;margin-top:.3rem}.route-metric.saved strong{color:#69d3ad}.delivery-card{margin:0 .8rem .8rem;background:var(--panel);border:1px solid var(--border);border-radius:14px;overflow:hidden}.delivery-row{display:grid;grid-template-columns:30px 1fr;gap:.65rem;padding:.78rem .9rem;border-bottom:1px solid var(--border)}.delivery-row:last-child{border-bottom:0}.delivery-row i{color:var(--muted);margin-top:.15rem}.delivery-row small{display:block;font:600 .54rem var(--mono);text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin-bottom:.2rem}.delivery-row strong{font-size:.84rem;line-height:1.4}.actions{display:grid;grid-template-columns:1fr 1fr;gap:.6rem;padding:0 .8rem .8rem}.actions .btn{width:100%}.actions .primary-action{grid-column:1/-1}.route-warning{margin:0 .8rem .8rem;padding:.8rem 1rem;border-radius:10px;background:rgba(217,134,10,.1);border:1px solid rgba(217,134,10,.25);color:#e6a846;font-size:.76rem;line-height:1.5;display:none}@media(max-width:600px){.location-panel{grid-template-columns:40px 1fr}.gps-pill{grid-column:2;justify-self:start}.map-wrap{height:55vh;min-height:365px}.route-metrics{grid-template-columns:repeat(2,minmax(0,1fr))}.nav-instruction{padding:.85rem}.instruction-main{font-size:.92rem}.actions{grid-template-columns:1fr}.actions .primary-action{grid-column:auto}}
</style>
</head>
<body>
<header class="nav-top"><a class="brand" href="my_deliveries.php">RIDGE<span>.</span></a><div class="tracking-meta"><strong><?=h($delivery['tracking_id'])?></strong><small><?=h(ridge_delivery_status_label((string)$delivery['status']))?></small></div></header>
<main class="nav-shell">
<section class="location-panel"><span class="location-icon"><i class="fas fa-location-arrow"></i></span><div class="location-copy"><small>Your current location</small><div class="location-name" id="current-location">Finding your street and area…</div><div class="location-detail" id="location-detail">Waiting for an accurate GPS position</div></div><span class="gps-pill" id="gps-pill">GPS waiting</span></section>
<section class="map-wrap"><div id="map"></div><div class="map-loader" id="map-loader"><div class="loader-box"><div class="loader-ring"></div><p id="loader-text">Locating you and building the shortest route…</p></div></div><div class="map-tools"><button class="map-tool active" id="follow-btn" type="button" aria-label="Follow my position" title="Follow my position"><i class="fas fa-location-arrow"></i></button><button class="map-tool" id="overview-btn" type="button" aria-label="Show route overview" title="Show route overview"><i class="fas fa-route"></i></button></div></section>
<section class="nav-instruction"><span class="maneuver-icon" id="maneuver-icon"><i class="fas fa-route"></i></span><div><div class="instruction-main" id="instruction-main">Building the shortest road route…</div><div class="instruction-sub" id="instruction-sub">Destination: <?=h($delivery['recipient_name'])?></div></div></section>
<section class="route-metrics"><div class="route-metric"><small>Shortest available</small><strong id="optimal-distance">—</strong></div><div class="route-metric"><small>Estimated time</small><strong id="optimal-time">—</strong></div><div class="route-metric"><small>Other route cost</small><strong id="baseline-cost">—</strong></div><div class="route-metric saved"><small>Estimated saving</small><strong id="saved-cost">—</strong></div></section>
<div class="route-warning" id="route-warning"><i class="fas fa-exclamation-triangle icon-gap"></i>The routing service is temporarily unavailable. RIDGE is showing your position and a direct-distance estimate while it retries.</div>
<section class="delivery-card"><div class="delivery-row"><i class="fas fa-user"></i><div><small>Recipient</small><strong><?=h($delivery['recipient_name'])?></strong></div></div><div class="delivery-row"><i class="fas fa-map-marker-alt"></i><div><small>Delivery address</small><strong><?=nl2br(h($delivery['recipient_address']))?></strong></div></div><div class="delivery-row"><i class="fas fa-phone"></i><div><small>Phone</small><strong><?=h($delivery['recipient_phone'])?></strong></div></div><?php if(!empty($delivery['package_description'])):?><div class="delivery-row"><i class="fas fa-box"></i><div><small>Package</small><strong><?=h($delivery['package_description'])?></strong></div></div><?php endif;?></section>
<section class="actions"><a class="btn btn-ghost" href="tel:<?=h($delivery['recipient_phone'])?>"><i class="fas fa-phone"></i> Call recipient</a><a class="btn btn-ghost" href="return.php?id=<?=$deliveryId?>"><i class="fas fa-warehouse"></i> Return item</a><a class="btn btn-green primary-action" href="confirm.php?id=<?=$deliveryId?>"><i class="fas fa-lock"></i> Confirm delivery with OTP</a><a class="btn btn-ghost primary-action" href="my_deliveries.php"><i class="fas fa-chevron-left"></i> Back to deliveries</a></section>
</main>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="location-tracker.js"></script>
<script>
const DELIVERY_ID=<?=$deliveryId?>;
const CSRF_TOKEN=<?=json_encode(ridge_csrf_token())?>;
const DEST_NAME=<?=json_encode((string)$delivery['recipient_name'])?>;
const DEST_ADDR=<?=json_encode((string)$delivery['recipient_address'])?>;
let destination={lat:<?=$hasCoords?(float)$destLat:'null'?>,lng:<?=$hasCoords?(float)$destLng:'null'?>};
const FUEL_PRICE=<?=$fuelPrice?>;
const FUEL_EFFICIENCY=<?=$fuelEfficiency?>;
const BASELINE_MULTIPLIER=<?=$baselineMultiplier?>;

const map=L.map('map',{zoomControl:false,attributionControl:true,preferCanvas:true}).setView(destination.lat?[destination.lat,destination.lng]:[6.5244,3.3792],16);
L.control.zoom({position:'bottomright'}).addTo(map);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);
let riderMarker=null,destMarker=null,optimalLayer=null,alternativeLayers=[],followMode=true,lastRouteAt=0,lastRoutePoint=null,routeBounds=null,lastReverseAt=0,lastReversePoint=null,metricsSaved=false;
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function distanceM(a,b){if(!a||!b)return Infinity;const R=6371000,r=Math.PI/180,dlat=(b.lat-a.lat)*r,dlng=(b.lng-a.lng)*r;const q=Math.sin(dlat/2)**2+Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin(dlng/2)**2;return R*2*Math.atan2(Math.sqrt(q),Math.sqrt(1-q));}
function money(v){return '₦'+Math.max(0,v).toLocaleString(undefined,{maximumFractionDigits:0});}
function iconPin(html,size,anchor){return L.divIcon({html,className:'',iconSize:[size,size],iconAnchor:[anchor,anchor],popupAnchor:[0,-anchor]});}
function setDestination(lat,lng){destination={lat:Number(lat),lng:Number(lng)};if(destMarker)map.removeLayer(destMarker);destMarker=L.marker([destination.lat,destination.lng],{icon:iconPin('<div class="destination-pin"><i class="fas fa-map-marker-alt"></i></div>',27,13)}).addTo(map).bindPopup(`<strong>${esc(DEST_NAME)}</strong><br>${esc(DEST_ADDR)}`);}
if(destination.lat)setDestination(destination.lat,destination.lng);
async function geocodeDestination(){if(destination.lat)return;try{const r=await fetch(`https://photon.komoot.io/api/?q=${encodeURIComponent(DEST_ADDR)}&limit=1`);const d=await r.json();if(d.features?.length){const c=d.features[0].geometry.coordinates;setDestination(c[1],c[0]);}}catch(_){}}
geocodeDestination();
function setRider(lat,lng,heading){const html='<div class="live-rider-pin"><i class="fas fa-motorcycle"></i></div>';if(!riderMarker){riderMarker=L.marker([lat,lng],{icon:iconPin(html,34,17),zIndexOffset:1000}).addTo(map).bindPopup('Your current position');}else riderMarker.setLatLng([lat,lng]);if(followMode)map.setView([lat,lng],Math.max(map.getZoom(),17),{animate:true});}
function setLoading(show,text){document.getElementById('map-loader').classList.toggle('hidden',!show);if(text)document.getElementById('loader-text').textContent=text;}
function routeInstruction(step){if(!step){document.getElementById('instruction-main').textContent=`Continue toward ${DEST_NAME}`;document.getElementById('instruction-sub').textContent=DEST_ADDR;return;}const man=step.maneuver||{};const modifier=(man.modifier||'').replace('-',' ');const road=step.name||'the road ahead';let main='Continue';let icon='fa-arrow-right';if(man.type==='arrive'){main=`Arrive at ${DEST_NAME}`;icon='fa-map-marker-alt';}else if(man.type==='depart'){main=`Start on ${road}`;icon='fa-location-arrow';}else if(man.type==='turn'||man.type==='new name'||man.type==='fork'||man.type==='continue'){main=`${modifier?modifier.charAt(0).toUpperCase()+modifier.slice(1):'Continue'} onto ${road}`;icon=modifier.includes('left')?'fa-chevron-left':modifier.includes('right')?'fa-chevron-right':'fa-arrow-right';}else if(man.type==='roundabout'||man.type==='rotary'){main=`Enter the roundabout toward ${road}`;icon='fa-redo';}const dist=step.distance<1000?`${Math.round(step.distance)} m`:`${(step.distance/1000).toFixed(1)} km`;document.getElementById('instruction-main').textContent=main;document.getElementById('instruction-sub').textContent=`In ${dist} · ${DEST_NAME}`;document.getElementById('maneuver-icon').innerHTML=`<i class="fas ${icon}"></i>`;}
function clearRoutes(){if(optimalLayer)map.removeLayer(optimalLayer);optimalLayer=null;alternativeLayers.forEach(l=>map.removeLayer(l));alternativeLayers=[];}
async function saveMetrics(optimal,baseline){if(metricsSaved)return;metricsSaved=true;const body=new URLSearchParams({csrf_token:CSRF_TOKEN,action:'route_metrics',route_km:(optimal.distance/1000).toFixed(2),baseline_km:(baseline.distance/1000).toFixed(2),duration_min:(optimal.duration/60).toFixed(2),baseline_duration_min:(baseline.duration/60).toFixed(2)});try{const r=await fetch(`map.php?id=${DELIVERY_ID}`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},credentials:'same-origin',body:body.toString()});if(!r.ok)metricsSaved=false;}catch(_){metricsSaved=false;}}
function updateCosts(optimal,baseline){const optKm=optimal.distance/1000,baseKm=baseline.distance/1000,savedKm=Math.max(0,baseKm-optKm);const optCost=(optKm/FUEL_EFFICIENCY)*FUEL_PRICE,baseCost=(baseKm/FUEL_EFFICIENCY)*FUEL_PRICE,savedCost=Math.max(0,baseCost-optCost);document.getElementById('optimal-distance').textContent=`${optKm.toFixed(1)} km`;document.getElementById('optimal-time').textContent=`${Math.max(1,Math.round(optimal.duration/60))} min`;document.getElementById('baseline-cost').textContent=FUEL_PRICE>0?money(baseCost):`${(baseKm/FUEL_EFFICIENCY).toFixed(2)} L`;document.getElementById('saved-cost').textContent=FUEL_PRICE>0?money(savedCost):`${(savedKm/FUEL_EFFICIENCY).toFixed(2)} L`;}
async function fetchRoute(lat,lng,force=false){if(!destination.lat)return;const now=Date.now(),point={lat,lng};if(!force&&now-lastRouteAt<15000&&distanceM(lastRoutePoint,point)<40)return;lastRouteAt=now;lastRoutePoint=point;try{const url=`https://router.project-osrm.org/route/v1/driving/${lng},${lat};${destination.lng},${destination.lat}?alternatives=3&steps=true&overview=full&geometries=geojson`;const r=await fetch(url,{cache:'no-store'});const d=await r.json();if(!d.routes?.length)throw new Error('No route');const routes=[...d.routes].sort((a,b)=>a.distance-b.distance);const optimal=routes[0];const baseline=routes.length>1?routes[routes.length-1]:{...optimal,distance:optimal.distance*BASELINE_MULTIPLIER,duration:optimal.duration*BASELINE_MULTIPLIER};clearRoutes();for(const route of routes.slice(1)){const layer=L.geoJSON(route.geometry,{style:{color:'#77736b',weight:4,opacity:.35,dashArray:'7 8'}}).addTo(map);alternativeLayers.push(layer);}optimalLayer=L.geoJSON(optimal.geometry,{style:{color:'#e8500a',weight:6,opacity:.92,lineCap:'round'}}).addTo(map);routeBounds=optimalLayer.getBounds();if(!followMode)map.fitBounds(routeBounds,{padding:[40,40],maxZoom:16});const steps=optimal.legs?.flatMap(l=>l.steps||[])||[];routeInstruction(steps.find(s=>s.distance>20)||steps[0]);updateCosts(optimal,baseline);saveMetrics(optimal,baseline);document.getElementById('route-warning').style.display='none';setLoading(false);}catch(e){document.getElementById('route-warning').style.display='block';straightEstimate(lat,lng);setLoading(false);}}
function straightEstimate(lat,lng){if(!destination.lat)return;const km=distanceM({lat,lng},destination)/1000;document.getElementById('optimal-distance').textContent=km<1?`${Math.round(km*1000)} m`:`${km.toFixed(1)} km`;document.getElementById('optimal-time').textContent=`~${Math.max(1,Math.round(km/25*60))} min`;document.getElementById('instruction-main').textContent=`Continue toward ${DEST_NAME}`;document.getElementById('instruction-sub').textContent='Road route will refresh automatically';}
async function reverseGeocode(lat,lng){const point={lat,lng},now=Date.now();if(now-lastReverseAt<60000&&distanceM(lastReversePoint,point)<200)return;lastReverseAt=now;lastReversePoint=point;try{const r=await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&zoom=18&addressdetails=1`,{headers:{'Accept-Language':'en'}});const d=await r.json();const a=d.address||{};const primary=a.road||a.pedestrian||a.neighbourhood||a.suburb||a.village||a.town||a.city||'Current location';const secondary=[a.neighbourhood||a.suburb,a.city||a.town||a.state_district,a.state].filter((v,i,arr)=>v&&arr.indexOf(v)===i&&v!==primary).slice(0,2).join(', ');document.getElementById('current-location').textContent=primary;document.getElementById('location-detail').textContent=secondary||`${lat.toFixed(5)}, ${lng.toFixed(5)}`;}catch(_){document.getElementById('current-location').textContent='Current GPS position';document.getElementById('location-detail').textContent=`${lat.toFixed(5)}, ${lng.toFixed(5)}`;}}
function onPosition(pos){const lat=pos.coords.latitude,lng=pos.coords.longitude,acc=Math.round(pos.coords.accuracy||0);setRider(lat,lng,pos.coords.heading);document.getElementById('gps-pill').className='gps-pill live';document.getElementById('gps-pill').textContent=`GPS ±${acc}m`;reverseGeocode(lat,lng);fetchRoute(lat,lng);setLoading(false);}
function onError(err){setLoading(false);document.getElementById('gps-pill').className='gps-pill';document.getElementById('gps-pill').textContent='GPS blocked';const messages={1:'Location permission is blocked. Enable it in browser settings.',2:'GPS signal is unavailable. Move into an open area.',3:'GPS timed out. RIDGE will keep retrying.'};document.getElementById('current-location').textContent=messages[err.code]||'Location unavailable';document.getElementById('location-detail').textContent='Live partner tracking needs location permission.';}
document.getElementById('follow-btn').addEventListener('click',()=>{followMode=true;document.getElementById('follow-btn').classList.add('active');document.getElementById('overview-btn').classList.remove('active');if(riderMarker)map.setView(riderMarker.getLatLng(),17,{animate:true});});document.getElementById('overview-btn').addEventListener('click',()=>{followMode=false;document.getElementById('overview-btn').classList.add('active');document.getElementById('follow-btn').classList.remove('active');if(routeBounds)map.fitBounds(routeBounds,{padding:[35,35],maxZoom:16});});map.on('dragstart',()=>{followMode=false;document.getElementById('follow-btn').classList.remove('active');});
RidgeLocationTracker.start({endpoint:'location.php',deliveryId:DELIVERY_ID,csrfToken:CSRF_TOKEN,keepScreenAwake:true,minIntervalMs:10000,minMoveMetres:12,onPosition,onError,onSaveError:()=>{document.getElementById('gps-pill').textContent='GPS · sync retry';}});
setTimeout(()=>map.invalidateSize(),100);setInterval(()=>{if(riderMarker){const p=riderMarker.getLatLng();fetchRoute(p.lat,p.lng,true);}},45000);
</script><script src="pwa.js"></script>
</body></html>
