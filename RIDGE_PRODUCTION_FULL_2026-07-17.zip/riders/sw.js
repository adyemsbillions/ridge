const CACHE='ridge-rider-shell-v3';
const SHELL=[
  '/riders/offline.html','/riders/pwa.js','/riders/location-tracker.js',
  '/riders/icons/icon-192.png','/riders/icons/icon-512.png',
  '/riders/icons/icon-maskable-512.png','/riders/icons/apple-touch-icon.png',
  '/assets/portal.css','/assets/fontawesome.css'
];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)));self.skipWaiting();});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));self.clients.claim();});
self.addEventListener('fetch',event=>{
  const req=event.request;if(req.method!=='GET')return;const url=new URL(req.url);
  if(req.mode==='navigate'){event.respondWith(fetch(req).catch(()=>caches.match('/riders/offline.html')));return;}
  if(url.origin===location.origin){event.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(res=>{if(res.ok){const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy));}return res;})));}
});
