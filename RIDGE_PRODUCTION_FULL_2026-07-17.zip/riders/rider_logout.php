<?php
require_once '../includes/bootstrap.php';
unset($_SESSION['rider_id'], $_SESSION['rider_name']);
session_regenerate_id(true);
ridge_redirect('rider_login.php');
