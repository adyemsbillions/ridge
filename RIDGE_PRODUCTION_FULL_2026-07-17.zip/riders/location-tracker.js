(function () {
  'use strict';

  const api = {
    watchId: null,
    lastSentAt: 0,
    lastSentPosition: null,
    options: null,
    wakeLock: null,

    distanceMetres(a, b) {
      if (!a || !b) return Infinity;
      const R = 6371000;
      const toRad = n => n * Math.PI / 180;
      const dLat = toRad(b.lat - a.lat);
      const dLng = toRad(b.lng - a.lng);
      const s1 = Math.sin(dLat / 2);
      const s2 = Math.sin(dLng / 2);
      const q = s1 * s1 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * s2 * s2;
      return R * 2 * Math.atan2(Math.sqrt(q), Math.sqrt(1 - q));
    },

    async send(position) {
      const opts = api.options || {};
      const now = Date.now();
      const point = {lat: position.coords.latitude, lng: position.coords.longitude};
      const moved = api.distanceMetres(api.lastSentPosition, point);
      if (now - api.lastSentAt < (opts.minIntervalMs || 10000) && moved < (opts.minMoveMetres || 15)) return;

      const body = new URLSearchParams();
      body.set('csrf_token', opts.csrfToken || '');
      body.set('lat', String(point.lat));
      body.set('lng', String(point.lng));
      body.set('accuracy', String(position.coords.accuracy || ''));
      body.set('heading', position.coords.heading == null ? '' : String(position.coords.heading));
      body.set('speed', position.coords.speed == null ? '' : String(position.coords.speed));
      if (opts.deliveryId) body.set('delivery_id', String(opts.deliveryId));

      try {
        const response = await fetch(opts.endpoint || 'location.php', {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
          credentials: 'same-origin',
          cache: 'no-store',
          body: body.toString()
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || !data.ok) throw new Error(data.error || 'Location save failed');
        api.lastSentAt = now;
        api.lastSentPosition = point;
        if (typeof opts.onSaved === 'function') opts.onSaved(data, position);
      } catch (error) {
        if (typeof opts.onSaveError === 'function') opts.onSaveError(error, position);
      }
    },

    async requestWakeLock() {
      if (!api.options?.keepScreenAwake || !('wakeLock' in navigator) || document.visibilityState !== 'visible') return;
      try {
        api.wakeLock = await navigator.wakeLock.request('screen');
      } catch (_) {}
    },

    start(options) {
      api.options = options || {};
      if (!navigator.geolocation) {
        if (typeof api.options.onError === 'function') api.options.onError({code: 0, message: 'Geolocation is not supported'});
        return null;
      }
      if (api.watchId !== null) navigator.geolocation.clearWatch(api.watchId);
      api.requestWakeLock();
      api.watchId = navigator.geolocation.watchPosition(
        position => {
          api.send(position);
          if (typeof api.options.onPosition === 'function') api.options.onPosition(position);
        },
        error => {
          if (typeof api.options.onError === 'function') api.options.onError(error);
        },
        {
          enableHighAccuracy: true,
          timeout: api.options.timeout || 20000,
          maximumAge: api.options.maximumAge || 4000
        }
      );
      return api.watchId;
    },

    stop() {
      if (api.watchId !== null) navigator.geolocation.clearWatch(api.watchId);
      api.watchId = null;
      if (api.wakeLock) api.wakeLock.release().catch(() => {});
      api.wakeLock = null;
    }
  };

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') api.requestWakeLock();
  });
  window.addEventListener('pagehide', () => api.stop());
  window.RidgeLocationTracker = api;
})();
