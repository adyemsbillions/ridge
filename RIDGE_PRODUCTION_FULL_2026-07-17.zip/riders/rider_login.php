<?php
require_once '../includes/bootstrap.php';

if (isset($_SESSION['rider_id'])) {
    ridge_redirect('rider_dashboard.php');
}

$error = '';
ridge_csrf_token();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!ridge_verify_csrf()) {
        $error = 'Your session expired. Refresh the page and try again.';
    } else {
        $rawPhone = trim((string) ($_POST['phone'] ?? ''));
        $phone = ridge_normalize_phone($rawPhone);
        $localPhone = str_starts_with($phone, '234') ? '0' . substr($phone, 3) : $rawPhone;
        $plainRaw = preg_replace('/\D+/', '', $rawPhone) ?? $rawPhone;
        $password = (string) ($_POST['password'] ?? '');
        $stmt = $conn->prepare('SELECT id,rider_name,password,status FROM riders WHERE REPLACE(REPLACE(REPLACE(phone,"+","")," ",""),"-","") IN (?,?,?) LIMIT 1');
        $stmt->bind_param('sss', $phone, $localPhone, $plainRaw);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        if (!$row || !password_verify($password, $row['password'])) {
            $error = 'Invalid phone number or password.';
        } elseif (!in_array((string) $row['status'], ['active', 'on_trip'], true)) {
            $error = 'Your account is inactive. Contact your company.';
        } else {
            session_regenerate_id(true);
            $_SESSION['rider_id'] = (int) $row['id'];
            $_SESSION['rider_name'] = $row['rider_name'];
            ridge_redirect('rider_dashboard.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="#E8500A">
    <link rel="manifest" href="manifest.webmanifest">
    <link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
    <title>Rider Login - RIDGE</title>
    <link rel="stylesheet" href="../assets/fontawesome.css">
    <link rel="stylesheet" href="../assets/portal.css">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --black: #0A0A0A; --off-white: #F5F2EB; --accent: #E8500A;
            --mid: #1A1A1A; --muted: #6B6860; --border: rgba(245,242,235,0.12);
            --card-bg: #111111; --green: #1D9E75;
        }
        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--black);
            color: var(--off-white);
            margin: 0;
            min-height: 100vh;
            padding: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-box {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: clamp(1.4rem,6vw,2.5rem);
            width: 100%;
            max-width: 420px;
        }
        .logo {
            font-family: 'Bebas Neue', sans-serif;
            font-size: 2.8rem;
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .logo span { color: var(--accent); }
    </style>
</head>
<body>

<div class="login-box">
    <div class="logo">RIDGE<span>.</span></div>
    <h2 style="text-align:center; margin-bottom:1.5rem;">Rider Login</h2>

    <?php if ($error): ?>
        <div style="background:rgba(232,80,10,0.2); color:var(--accent); padding:1rem; border-radius:8px; margin-bottom:1.5rem; text-align:center;">
            <?= h($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <?= ridge_csrf_field() ?>
        <div class="form-group" style="margin-bottom:1.25rem;">
            <label style="display:block; margin-bottom:0.5rem; color:var(--muted);">Phone Number</label>
            <input type="tel" name="phone" required placeholder="080XXXXXXXX" 
                   style="width:100%; padding:1rem; background:rgba(255,255,255,0.05); border:1px solid var(--border); border-radius:8px; color:white;">
        </div>
        <div class="form-group" style="margin-bottom:1.5rem;">
            <label style="display:block; margin-bottom:0.5rem; color:var(--muted);">Password</label>
            <input type="password" name="password" required 
                   style="width:100%; padding:1rem; background:rgba(255,255,255,0.05); border:1px solid var(--border); border-radius:8px; color:white;">
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%; padding:1rem; font-size:1rem;"><i class="fas fa-sign-in-alt"></i> Login as Rider</button>
    </form>

    <p style="text-align:center; margin-top:1.5rem; color:var(--muted); font-size:0.9rem;">
        Contact your company if you forgot your password.
    </p>
</div>

<script src="pwa.js"></script>
</body>
</html>