<?php
require_once '../includes/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

if (!isset($_SESSION['rider_id'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Authentication required']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'POST required']);
    exit;
}
if (!ridge_verify_csrf()) {
    http_response_code(419);
    echo json_encode(['ok' => false, 'error' => 'Session expired']);
    exit;
}

$riderId = (int) $_SESSION['rider_id'];
$deliveryId = max(0, (int) ($_POST['delivery_id'] ?? 0));
$lat = filter_var($_POST['lat'] ?? null, FILTER_VALIDATE_FLOAT);
$lng = filter_var($_POST['lng'] ?? null, FILTER_VALIDATE_FLOAT);
$accuracy = filter_var($_POST['accuracy'] ?? null, FILTER_VALIDATE_FLOAT);
$heading = filter_var($_POST['heading'] ?? null, FILTER_VALIDATE_FLOAT);
$speedMps = filter_var($_POST['speed'] ?? null, FILTER_VALIDATE_FLOAT);

if ($lat === false || $lng === false || $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180 || ($lat == 0.0 && $lng == 0.0)) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'Invalid coordinates']);
    exit;
}

$accuracy = ($accuracy === false || $accuracy === null) ? null : min(max((float) $accuracy, 0), 10000);
$heading = ($heading === false || $heading === null || $heading < 0) ? null : fmod((float) $heading, 360.0);
$speedKmh = ($speedMps === false || $speedMps === null || $speedMps < 0) ? null : min((float) $speedMps * 3.6, 300);
$locationDeliveryId = null;

if ($deliveryId > 0) {
    $verify = $conn->prepare("SELECT id FROM deliveries WHERE id=? AND rider_id=? AND status IN ('assigned','enroute') LIMIT 1");
    $verify->bind_param('ii', $deliveryId, $riderId);
    $verify->execute();
    if (!$verify->get_result()->fetch_assoc()) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Delivery is not assigned to this rider']);
        exit;
    }
    $locationDeliveryId = $deliveryId;
}

$updateRider = $conn->prepare('UPDATE riders SET last_lat=?,last_lng=?,last_location_at=NOW(),last_accuracy_m=?,last_heading=?,last_speed_kmh=?,location_delivery_id=? WHERE id=?');
$updateRider->bind_param('dddddii', $lat, $lng, $accuracy, $heading, $speedKmh, $locationDeliveryId, $riderId);
$riderOk = $updateRider->execute();

if ($deliveryId > 0) {
    $updateDelivery = $conn->prepare("UPDATE deliveries SET last_rider_lat=?,last_rider_lng=?,last_location_at=NOW() WHERE id=? AND rider_id=? AND status IN ('assigned','enroute')");
    $updateDelivery->bind_param('ddii', $lat, $lng, $deliveryId, $riderId);
    $updateDelivery->execute();
}

if (!$riderOk) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Location could not be saved']);
    exit;
}

echo json_encode([
    'ok' => true,
    'saved_at' => date(DATE_ATOM),
    'delivery_id' => $deliveryId ?: null,
], JSON_UNESCAPED_SLASHES);
