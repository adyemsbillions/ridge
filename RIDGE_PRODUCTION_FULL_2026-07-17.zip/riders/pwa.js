if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/riders/sw.js').catch(() => {}));
}
let deferredInstallPrompt=null;
window.addEventListener('beforeinstallprompt',event=>{
  event.preventDefault();deferredInstallPrompt=event;
  const button=document.querySelector('[data-install-app]');if(button)button.hidden=false;
});
window.installRidgeRider=async function(){
  if(!deferredInstallPrompt)return;
  deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;
  const button=document.querySelector('[data-install-app]');if(button)button.hidden=true;
};
