<?php
$query = isset($_GET['id']) ? '?id=' . urlencode((string) $_GET['id']) : '';
header('Location: confirm.php' . $query, true, 301);
exit;
