<?php
/**
 * RIDGE database connection.
 * Credentials are loaded from environment variables or config.local.php.
 */
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/ridge-errors.log');
error_reporting(E_ALL);

$local = [];
$localPath = __DIR__ . '/config.local.php';

if (is_file($localPath)) {
    try {
        $loaded = require $localPath;
        if (is_array($loaded)) {
            $local = $loaded;
        } else {
            error_log('RIDGE configuration error: config.local.php did not return an array.');
        }
    } catch (Throwable $e) {
        error_log('RIDGE configuration error in config.local.php: ' . $e->getMessage());
        http_response_code(500);
        exit('RIDGE configuration error. Check ridge-errors.log in the website root.');
    }
}

$host = getenv('RIDGE_DB_HOST') ?: ($local['db_host'] ?? 'localhost');
$dbname = getenv('RIDGE_DB_NAME') ?: ($local['db_name'] ?? '');
$username = getenv('RIDGE_DB_USER') ?: ($local['db_user'] ?? '');
$password = getenv('RIDGE_DB_PASSWORD') ?: ($local['db_password'] ?? '');

$missing = [];
if ($dbname === '') {
    $missing[] = 'db_name';
}
if ($username === '') {
    $missing[] = 'db_user';
}
if ($password === '') {
    $missing[] = 'db_password';
}

if ($missing) {
    error_log('RIDGE configuration error: config.local.php is missing or incomplete. Missing: ' . implode(', ', $missing));
    http_response_code(500);
    exit('RIDGE database configuration is missing. Create config.local.php in the website root, then reload this page.');
}

if (!extension_loaded('mysqli')) {
    error_log('RIDGE server error: mysqli extension is not enabled.');
    http_response_code(500);
    exit('RIDGE server configuration error. The mysqli PHP extension is required.');
}

mysqli_report(MYSQLI_REPORT_OFF);
$conn = @new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    error_log('RIDGE database connection failed (' . $conn->connect_errno . '): ' . $conn->connect_error);
    http_response_code(500);
    exit('RIDGE could not connect to the database. Check ridge-errors.log in the website root.');
}

if (!$conn->set_charset('utf8mb4')) {
    error_log('RIDGE warning: failed to set utf8mb4 character set: ' . $conn->error);
}
