<?php
require_once '../includes/bootstrap.php';
require_once '../includes/notifications.php';

if (!isset($_SESSION['partner_id'])) {
    ridge_redirect('index.php');
}

$partner_id = (int) $_SESSION['partner_id'];

// Add New Delivery
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_delivery'])) {
    $sender_name       = trim((string) $_POST['sender_name']);
    $sender_phone      = ridge_normalize_phone((string) $_POST['sender_phone']);
    $sender_address    = trim((string) $_POST['sender_address']);
    $recipient_name    = trim((string) $_POST['recipient_name']);
    $recipient_phone   = ridge_normalize_phone((string) $_POST['recipient_phone']);
    $recipient_address = trim((string) $_POST['recipient_address']);
    $package_desc      = trim((string) $_POST['package_description']);
    $delivery_date     = (string) $_POST['delivery_date'];
    $recipient_lat     = !empty($_POST['recipient_lat']) ? (float) $_POST['recipient_lat'] : null;
    $recipient_lng     = !empty($_POST['recipient_lng']) ? (float) $_POST['recipient_lng'] : null;
    $tracking_id       = ridge_tracking_id();
    $public_token      = ridge_public_token();

    $stmt = $conn->prepare("INSERT INTO deliveries
        (partner_id, tracking_id, public_token, sender_name, sender_phone, sender_address,
         recipient_name, recipient_phone, recipient_address, package_description,
         delivery_date, status, recipient_lat, recipient_lng)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)");
    $stmt->bind_param("issssssssssdd", $partner_id, $tracking_id, $public_token, $sender_name, $sender_phone,
                      $sender_address, $recipient_name, $recipient_phone, $recipient_address, $package_desc,
                      $delivery_date, $recipient_lat, $recipient_lng);

    if ($stmt->execute()) {
        $delivery_id = (int) $stmt->insert_id;
        ridge_record_event($conn, $delivery_id, 'pending', 'Delivery request created', 'The partner added the package with a mapped destination.', 'partner', $partner_id);
        ridge_notify_delivery_status($conn, [
            'id' => $delivery_id,
            'tracking_id' => $tracking_id,
            'public_token' => $public_token,
            'recipient_name' => $recipient_name,
            'recipient_phone' => $recipient_phone,
            'sender_name' => $sender_name,
            'sender_phone' => $sender_phone,
        ], 'pending');
        $coords_saved = ($recipient_lat && $recipient_lng) ? " · Coordinates saved" : " · No coordinates (address not selected from suggestions)";
        $success = "Delivery added! Tracking ID: <strong>" . h($tracking_id) . "</strong><span style='font-size:0.85em;opacity:0.7;'>" . h($coords_saved) . "</span>";
    } else {
        $error = "Failed to add delivery.";
    }
}

// Fetch Pending Deliveries
$stmt = $conn->prepare("SELECT * FROM deliveries WHERE partner_id = ? AND status = 'pending' ORDER BY created_at DESC");
$stmt->bind_param("i", $partner_id);
$stmt->execute();
$pending_deliveries = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dispatch Orders - RIDGE</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="../assets/fontawesome.css">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --black:#0A0A0A; --off-white:#F5F2EB; --accent:#E8500A;
            --mid:#1A1A1A; --muted:#6B6860; --border:rgba(245,242,235,0.12);
            --card-bg:#111111; --green:#1D9E75;
            --amber:#D9860A; --amber-dim:rgba(217,134,10,0.12);
        }
        *, *::before, *::after { box-sizing: border-box; }
        body { font-family:'DM Sans',sans-serif; background:var(--black); color:var(--off-white); margin:0; }
        .dashboard { display:flex; min-height:100vh; }
        .sidebar { width:260px; background:var(--mid); border-right:1px solid var(--border); padding:2rem 1.5rem; position:fixed; height:100vh; display:flex; flex-direction:column; }
        .sidebar-logo { font-family:'Bebas Neue',sans-serif; font-size:2.2rem; letter-spacing:0.1em; margin-bottom:3rem; }
        .sidebar-logo span { color:var(--accent); }
        .nav-menu { list-style:none; padding:0; margin:0; }
        .nav-menu a { display:flex; align-items:center; gap:1rem; padding:0.9rem 1.25rem; color:var(--muted); text-decoration:none; border-radius:8px; margin-bottom:0.2rem; }
        .nav-menu a:hover, .nav-menu a.active { background:rgba(232,80,10,0.15); color:var(--off-white); }
        .main-content { flex:1; margin-left:260px; padding:2rem; }
        .card { background:var(--card-bg); border:1px solid var(--border); border-radius:12px; padding:2rem; margin-bottom:2rem; }
        .form-grid { display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; }
        .alert { padding:1rem 1.25rem; border-radius:8px; margin:1rem 0; font-size:0.9rem; }
        .alert-success { background:rgba(29,158,117,0.15); color:var(--green); border:1px solid rgba(29,158,117,0.25); }
        .alert-error   { background:rgba(232,80,10,0.15); color:var(--accent); border:1px solid rgba(232,80,10,0.25); }

        /* Form inputs */
        input[type=text], input[type=tel], input[type=date], textarea {
            width:100%; background:rgba(245,242,235,0.05); border:1px solid var(--border);
            color:var(--off-white); border-radius:8px; padding:0.75rem 1rem;
            font-family:'DM Sans',sans-serif; font-size:0.9rem; margin-bottom:0.85rem;
            outline:none; transition:border-color 0.15s;
        }
        input:focus, textarea:focus { border-color:rgba(232,80,10,0.5); }
        textarea { resize:vertical; }
        label { display:block; font-size:0.8rem; color:var(--muted); margin-bottom:0.3rem; }

        /* Address autocomplete wrapper */
        .addr-wrap { position:relative; margin-bottom:0.85rem; }
        .addr-wrap input { margin-bottom:0; }

        /* Coord badge shown after selection */
        .coord-badge {
            display:none; align-items:center; gap:0.4rem;
            margin-top:0.4rem; padding:0.4rem 0.75rem;
            background:rgba(29,158,117,0.12); border:1px solid rgba(29,158,117,0.25);
            border-radius:6px; font-family:'JetBrains Mono',monospace; font-size:0.7rem; color:var(--green);
        }
        .coord-badge.show { display:flex; }
        .coord-badge svg { flex-shrink:0; }

        /* Suggestions dropdown */
        .suggestions {
            position:absolute; top:calc(100% + 4px); left:0; right:0; z-index:999;
            background:#1C1C1C; border:1px solid var(--border); border-radius:10px;
            overflow:hidden; box-shadow:0 8px 24px rgba(0,0,0,0.5);
            max-height:240px; overflow-y:auto; display:none;
        }
        .suggestions.open { display:block; }
        .suggestion-item {
            padding:0.75rem 1rem; cursor:pointer; font-size:0.85rem;
            border-bottom:1px solid var(--border); transition:background 0.1s;
            display:flex; align-items:flex-start; gap:0.6rem;
        }
        .suggestion-item:last-child { border-bottom:none; }
        .suggestion-item:hover, .suggestion-item.highlighted { background:rgba(232,80,10,0.12); }
        .suggestion-item svg { flex-shrink:0; margin-top:2px; color:var(--accent); }
        .sug-main { font-weight:500; color:var(--off-white); }
        .sug-sub  { font-size:0.75rem; color:var(--muted); margin-top:2px; }

        /* No results */
        .sug-empty { padding:0.9rem 1rem; font-size:0.83rem; color:var(--muted); text-align:center; }

        /* Spinner inside field */
        .addr-spinner {
            position:absolute; right:0.85rem; top:0.85rem;
            width:14px; height:14px; border:2px solid var(--border);
            border-top-color:var(--accent); border-radius:50%;
            animation:spin 0.7s linear infinite; display:none;
        }
        .addr-spinner.show { display:block; }
        @keyframes spin { to { transform:rotate(360deg); } }

        /* Table */
        table { width:100%; border-collapse:collapse; margin-top:1rem; }
        th { text-align:left; padding:0.75rem 1rem; font-size:0.78rem; color:var(--muted); border-bottom:1px solid var(--border); font-weight:500; text-transform:uppercase; letter-spacing:0.05em; }
        td { padding:0.85rem 1rem; font-size:0.88rem; border-bottom:1px solid rgba(245,242,235,0.05); vertical-align:middle; }
        tr:last-child td { border-bottom:none; }
        .coord-dot { display:inline-block; width:7px; height:7px; border-radius:50%; margin-right:4px; }
        .coord-dot.yes { background:var(--green); }
        .coord-dot.no  { background:var(--amber); }

        .btn-primary {
            width:100%; margin-top:1.5rem; padding:1rem; font-size:1rem;
            background:var(--accent); color:white; border:none; border-radius:8px;
            font-family:'DM Sans',sans-serif; font-weight:600; cursor:pointer;
            transition:opacity 0.15s;
        }
        .btn-primary:hover { opacity:0.88; }
    </style>
</head>
<body>
<div class="dashboard">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="sidebar-logo">RIDGE<span>.</span></div>
        <ul class="nav-menu">
            <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="manage_riders.php"><i class="fas fa-motorcycle"></i> Manage Riders</a></li>
            <li><a href="dispatch.php"><i class="fas fa-paper-plane"></i> Dispatch Orders</a></li>
            <li><a href="mapped_delivery.php" class="active"><i class="fas fa-map-marked-alt"></i> Mapped Delivery</a></li>
            <li><a href="enroute.php"><i class="fas fa-satellite-dish"></i> Live Enroute</a></li>
            <li><a href="out.php"><i class="fas fa-box"></i> Dispatched Orders</a></li>
            <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
            <li><a href="settings.php"><i class="fas fa-cog"></i> Fleet Settings</a></li>
        </ul>
        <a href="index.php?logout=1" style="color:var(--muted); margin-top:auto; display:block; padding:0.9rem 1.25rem;"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <!-- MAIN -->
    <div class="main-content">
        <h1 style="font-family:'Bebas Neue',sans-serif; font-size:2.4rem; margin-bottom:1.5rem;">Dispatch Center</h1>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>

        <!-- Add New Package Form -->
        <div class="card">
            <h2 style="margin-bottom:1.5rem;">Add New Delivery / Package</h2>
            <form method="POST" id="dispatch-form">

                <div class="form-grid">
                    <!-- Sender -->
                    <div>
                        <h3 style="margin-bottom:1rem; color:var(--accent);">Sender Information</h3>
                        <input type="text" name="sender_name" placeholder="Sender Full Name" required>
                        <input type="tel" name="sender_phone" placeholder="Sender Phone Number" required>
                        <textarea name="sender_address" rows="3" placeholder="Sender Address" required></textarea>
                    </div>

                    <!-- Recipient -->
                    <div>
                        <h3 style="margin-bottom:1rem; color:var(--accent);">Recipient Information</h3>
                        <input type="text" name="recipient_name" placeholder="Recipient Full Name" required>
                        <input type="tel" name="recipient_phone" placeholder="Recipient Phone Number" required>

                        <!-- Address autocomplete -->
                        <label>Recipient Address <span style="color:var(--accent);">*</span></label>
                        <div class="addr-wrap">
                            <input type="text" id="recipient_address_input" name="recipient_address"
                                   placeholder="Start typing address or area…" autocomplete="off" required>
                            <div class="addr-spinner" id="addr-spinner"></div>
                            <div class="suggestions" id="suggestions"></div>
                        </div>
                        <div class="coord-badge" id="coord-badge">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            <span id="coord-text">—</span>
                        </div>

                        <!-- Hidden lat/lng posted with form -->
                        <input type="hidden" name="recipient_lat" id="recipient_lat">
                        <input type="hidden" name="recipient_lng" id="recipient_lng">
                    </div>
                </div>

                <!-- Package -->
                <div style="margin-top:1.5rem;">
                    <h3 style="margin-bottom:1rem;">Package Details</h3>
                    <textarea name="package_description" rows="3" placeholder="Describe the package (weight, content, special instructions…)" required></textarea>
                </div>

                <div style="margin-top:0.5rem;">
                    <label>Preferred Delivery Date</label>
                    <input type="date" name="delivery_date" value="<?= date('Y-m-d', strtotime('+1 day')) ?>" required>
                </div>

                <button type="submit" name="add_delivery" class="btn-primary">Add Package to System</button>
            </form>
        </div>

        <!-- Pending Packages -->
        <div class="card">
            <h2>Pending Packages</h2>
            <?php if ($pending_deliveries->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Tracking ID</th>
                            <th>Recipient</th>
                            <th>Address</th>
                            <th>Delivery Date</th>
                            <th>Coords</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $pending_deliveries->fetch_assoc()): ?>
                        <tr>
                            <td><strong style="font-family:'JetBrains Mono',monospace; font-size:0.82rem;"><?= htmlspecialchars($row['tracking_id']) ?></strong></td>
                            <td><?= htmlspecialchars($row['recipient_name']) ?></td>
                            <td style="color:var(--muted); font-size:0.83rem;"><?= htmlspecialchars(substr($row['recipient_address'], 0, 55)) ?>…</td>
                            <td style="font-family:'JetBrains Mono',monospace; font-size:0.8rem;"><?= htmlspecialchars($row['delivery_date']) ?></td>
                            <td>
                                <?php if ($row['recipient_lat'] && $row['recipient_lng']): ?>
                                    <span class="coord-dot yes"></span>
                                    <span style="font-family:'JetBrains Mono',monospace; font-size:0.72rem; color:var(--green);">
                                        <?= number_format($row['recipient_lat'], 4) ?>, <?= number_format($row['recipient_lng'], 4) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="coord-dot no"></span>
                                    <span style="font-size:0.78rem; color:var(--amber);">Missing</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="color:var(--muted); padding:2rem 0; text-align:center;">No pending packages yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// ── Address autocomplete via Photon (OpenStreetMap, free, no key) ──
const input      = document.getElementById('recipient_address_input');
const dropdown   = document.getElementById('suggestions');
const spinner    = document.getElementById('addr-spinner');
const latField   = document.getElementById('recipient_lat');
const lngField   = document.getElementById('recipient_lng');
const coordBadge = document.getElementById('coord-badge');
const coordText  = document.getElementById('coord-text');

let debounceTimer = null;
let currentQuery  = '';
let highlighted   = -1;

function clearCoords() {
    latField.value = '';
    lngField.value = '';
    coordBadge.classList.remove('show');
}

function setCoords(lat, lng, label) {
    latField.value = lat;
    lngField.value = lng;
    coordText.textContent = `${parseFloat(lat).toFixed(5)}, ${parseFloat(lng).toFixed(5)}`;
    coordBadge.classList.add('show');
}

function closeDropdown() {
    dropdown.classList.remove('open');
    dropdown.innerHTML = '';
    highlighted = -1;
}

function buildLabel(props) {
    // Main: name or street
    const main = props.name || props.street || props.city || '';
    // Sub: city, state, country
    const parts = [props.city, props.state, props.country].filter(Boolean);
    return { main, sub: parts.join(', ') };
}

function renderSuggestions(features) {
    dropdown.innerHTML = '';
    highlighted = -1;

    if (!features.length) {
        dropdown.innerHTML = `<div class="sug-empty">No results found — try a different address</div>`;
        dropdown.classList.add('open');
        return;
    }

    features.forEach((f, i) => {
        const { main, sub } = buildLabel(f.properties);
        const item = document.createElement('div');
        item.className = 'suggestion-item';
        item.innerHTML = `
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                <circle cx="12" cy="10" r="3"/>
            </svg>
            <div>
                <div class="sug-main">${main}</div>
                ${sub ? `<div class="sug-sub">${sub}</div>` : ''}
            </div>`;

        item.addEventListener('mousedown', (e) => {
            e.preventDefault(); // don't blur input before we set value
            const [lng, lat] = f.geometry.coordinates;
            // Build a full readable address string
            const p = f.properties;
            const addrParts = [p.housenumber, p.street || p.name, p.city, p.state, p.country].filter(Boolean);
            const fullAddr = addrParts.join(', ');
            input.value = fullAddr;
            setCoords(lat, lng, fullAddr);
            closeDropdown();
        });

        dropdown.appendChild(item);
    });

    dropdown.classList.add('open');
}

function search(query) {
    if (query.length < 3) { closeDropdown(); clearCoords(); return; }
    currentQuery = query;
    spinner.classList.add('show');

    // Bias results toward Nigeria (viewbox: roughly Nigeria bounding box)
    const url = `https://photon.komoot.io/api/?q=${encodeURIComponent(query)}&limit=6&bbox=2.676932,4.272543,14.680073,13.892007`;

    fetch(url)
        .then(r => r.json())
        .then(data => {
            if (currentQuery !== query) return; // stale response
            spinner.classList.remove('show');
            renderSuggestions(data.features || []);
        })
        .catch(() => {
            spinner.classList.remove('show');
            dropdown.innerHTML = `<div class="sug-empty">Search failed — check connection</div>`;
            dropdown.classList.add('open');
        });
}

// Debounce input
input.addEventListener('input', () => {
    clearCoords();
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => search(input.value.trim()), 320);
});

// Keyboard navigation
input.addEventListener('keydown', (e) => {
    const items = dropdown.querySelectorAll('.suggestion-item');
    if (!items.length) return;

    if (e.key === 'ArrowDown') {
        e.preventDefault();
        highlighted = Math.min(highlighted + 1, items.length - 1);
        items.forEach((el, i) => el.classList.toggle('highlighted', i === highlighted));
    } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        highlighted = Math.max(highlighted - 1, 0);
        items.forEach((el, i) => el.classList.toggle('highlighted', i === highlighted));
    } else if (e.key === 'Enter' && highlighted >= 0) {
        e.preventDefault();
        items[highlighted].dispatchEvent(new MouseEvent('mousedown'));
    } else if (e.key === 'Escape') {
        closeDropdown();
    }
});

// Close on outside click
document.addEventListener('click', (e) => {
    if (!e.target.closest('.addr-wrap')) closeDropdown();
});

// Warn if submitting without coords
document.getElementById('dispatch-form').addEventListener('submit', (e) => {
    if (!latField.value || !lngField.value) {
        const ok = confirm(
            'No coordinates saved for this recipient address.\n\n' +
            'The rider\'s route optimisation will not work for this delivery.\n\n' +
            'Submit anyway?'
        );
        if (!ok) e.preventDefault();
    }
});
</script>
</body>
</html>