<?php
require_once '../includes/bootstrap.php';
require_once '../includes/notifications.php';

if (!isset($_SESSION['partner_id'])) {
    ridge_redirect('index.php');
}

ridge_csrf_token();
$partner_id = (int) $_SESSION['partner_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !ridge_verify_csrf()) {
    $error = 'Your session expired. Refresh the page and try again.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_package'])) {
    $sender_name         = trim((string) ($_POST['sender_name'] ?? ''));
    $sender_phone        = ridge_normalize_phone((string) ($_POST['sender_phone'] ?? ''));
    $sender_address      = trim((string) ($_POST['sender_address'] ?? ''));
    $recipient_name      = trim((string) ($_POST['recipient_name'] ?? ''));
    $recipient_phone     = ridge_normalize_phone((string) ($_POST['recipient_phone'] ?? ''));
    $recipient_address   = trim((string) ($_POST['recipient_address'] ?? ''));
    $package_description = trim((string) ($_POST['package_description'] ?? ''));
    $delivery_date       = (string) ($_POST['delivery_date'] ?? '');
    $tracking_id         = ridge_tracking_id();
    $public_token        = ridge_public_token();

    if ($sender_name === '' || $sender_phone === '' || $sender_address === '' || $recipient_name === '' || $recipient_phone === '' || $recipient_address === '' || $package_description === '' || $delivery_date === '') {
        $error = 'Complete all package, sender and recipient fields.';
    } else {
        $stmt = $conn->prepare("INSERT INTO deliveries
            (partner_id, tracking_id, public_token, sender_name, sender_phone, sender_address,
             recipient_name, recipient_phone, recipient_address, package_description,
             delivery_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
        $stmt->bind_param("issssssssss", $partner_id, $tracking_id, $public_token, $sender_name, $sender_phone,
                          $sender_address, $recipient_name, $recipient_phone, $recipient_address,
                          $package_description, $delivery_date);

        if ($stmt->execute()) {
            $delivery_id = (int) $stmt->insert_id;
            ridge_record_event($conn, $delivery_id, 'pending', 'Delivery request created', 'The partner added the package to the dispatch queue.', 'partner', $partner_id);
            ridge_notify_delivery_status($conn, [
                'id' => $delivery_id,
                'tracking_id' => $tracking_id,
                'public_token' => $public_token,
                'recipient_name' => $recipient_name,
                'recipient_phone' => $recipient_phone,
                'sender_name' => $sender_name,
                'sender_phone' => $sender_phone,
            ], 'pending');
            $success = "New package added successfully! Tracking ID: <strong>" . h($tracking_id) . "</strong>";
        } else {
            $error = 'Failed to add package.';
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['assign_rider']) || isset($_POST['reassign_returned']))) {
    $rider_id = (int) ($_POST['rider_id'] ?? 0);
    $selected = array_values(array_unique(array_filter(array_map('intval', $_POST['selected'] ?? []))));
    $isReturnQueue = isset($_POST['reassign_returned']);
    $requiredStatus = $isReturnQueue ? 'returned' : 'pending';

    if (!$rider_id || !$selected) {
        $error = 'Select at least one package and an available rider.';
    } else {
        $riderLookup = $conn->prepare("SELECT rider_name FROM riders WHERE id=? AND partner_id=? AND status='active' LIMIT 1");
        $riderLookup->bind_param('ii', $rider_id, $partner_id);
        $riderLookup->execute();
        $riderRow = $riderLookup->get_result()->fetch_assoc();

        if (!$riderRow) {
            $error = 'The selected rider is unavailable.';
        } else {
            $updated = 0;
            $lookup = $conn->prepare('SELECT id,status,return_reason,return_notes,return_count FROM deliveries WHERE id=? AND partner_id=? LIMIT 1');
            $assign = $conn->prepare("UPDATE deliveries SET
                rider_id=?, status='assigned', accepted_at=NOW(), enroute_at=NULL,
                delivered_at=NULL, cancelled_at=NULL, delivery_otp=NULL, otp_expires_at=NULL,
                assignment_count=COALESCE(assignment_count,0)+1,
                last_reassigned_at=CASE WHEN return_count>0 THEN NOW() ELSE last_reassigned_at END
                WHERE id=? AND partner_id=? AND status=?");

            foreach ($selected as $deliveryId) {
                $lookup->bind_param('ii', $deliveryId, $partner_id);
                $lookup->execute();
                $current = $lookup->get_result()->fetch_assoc();
                if (!$current || $current['status'] !== $requiredStatus) {
                    continue;
                }

                $assign->bind_param('iiis', $rider_id, $deliveryId, $partner_id, $requiredStatus);
                if (!$assign->execute() || $assign->affected_rows < 1) {
                    continue;
                }

                if ($isReturnQueue) {
                    $reason = ridge_return_reason_label((string) ($current['return_reason'] ?? ''));
                    $description = 'Returned item reassigned to ' . $riderRow['rider_name'] . ' for another delivery attempt. Previous return reason: ' . $reason . '.';
                    ridge_record_event($conn, $deliveryId, 'assigned', 'Returned item reassigned', $description, 'partner', $partner_id);
                } else {
                    ridge_record_event($conn, $deliveryId, 'assigned', 'Rider assigned', 'Assigned to ' . $riderRow['rider_name'] . '.', 'partner', $partner_id);
                }

                $deliveryStmt = $conn->prepare('SELECT * FROM deliveries WHERE id=? LIMIT 1');
                $deliveryStmt->bind_param('i', $deliveryId);
                $deliveryStmt->execute();
                if ($deliveryRow = $deliveryStmt->get_result()->fetch_assoc()) {
                    ridge_notify_delivery_status($conn, $deliveryRow, 'assigned', (string) $riderRow['rider_name']);
                }
                $updated++;
            }

            if ($updated > 0) {
                $success = $isReturnQueue
                    ? $updated . ' returned item' . ($updated === 1 ? ' was' : 's were') . ' reassigned for another last-mile attempt.'
                    : $updated . ' package' . ($updated === 1 ? ' was' : 's were') . ' assigned successfully.';
            } else {
                $error = 'No package was updated. Refresh the page and confirm the selected items are still available.';
            }
        }
    }
}

$rider_stmt = $conn->prepare("SELECT id,rider_name,bike_plate FROM riders WHERE partner_id=? AND status='active' ORDER BY rider_name");
$rider_stmt->bind_param('i', $partner_id);
$rider_stmt->execute();
$riders_arr = [];
$rider_result = $rider_stmt->get_result();
while ($rider = $rider_result->fetch_assoc()) {
    $riders_arr[] = $rider;
}

$stmt = $conn->prepare("SELECT * FROM deliveries WHERE partner_id=? AND status='pending' ORDER BY created_at DESC");
$stmt->bind_param('i', $partner_id);
$stmt->execute();
$pending = $stmt->get_result();

$returnedStmt = $conn->prepare("SELECT d.*,r.rider_name returned_by_name FROM deliveries d LEFT JOIN riders r ON r.id=d.returned_by_rider_id WHERE d.partner_id=? AND d.status='returned' ORDER BY d.returned_at DESC,d.updated_at DESC");
$returnedStmt->bind_param('i', $partner_id);
$returnedStmt->execute();
$returned = $returnedStmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dispatch Orders - RIDGE</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="../assets/fontawesome.css">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --black:#0A0A0A; --off-white:#F5F2EB; --accent:#E8500A;
            --mid:#1A1A1A; --muted:#6B6860; --border:rgba(245,242,235,0.12);
            --card-bg:#111111; --green:#1D9E75;
        }
        body { font-family:'DM Sans',sans-serif; background:var(--black); color:var(--off-white); margin:0; }
        .dashboard { display:flex; min-height:100vh; }
        .sidebar { width:260px; background:var(--mid); border-right:1px solid var(--border); padding:2rem 1.5rem; position:fixed; height:100vh; }
        .sidebar-logo { font-family:'Bebas Neue',sans-serif; font-size:2.2rem; letter-spacing:0.1em; margin-bottom:3rem; }
        .sidebar-logo span { color:var(--accent); }
        .nav-menu a { display:flex; align-items:center; gap:1rem; padding:0.9rem 1.25rem; color:var(--muted); text-decoration:none; border-radius:8px; }
        .nav-menu a:hover, .nav-menu a.active { background:rgba(232,80,10,0.15); color:var(--off-white); }
        .main-content { flex:1; margin-left:260px; padding:2rem; }
        .card { background:var(--card-bg); border:1px solid var(--border); border-radius:12px; padding:2rem; margin-bottom:2rem; }
        table { width:100%; border-collapse:collapse; }
        th, td { padding:1rem; border-bottom:1px solid var(--border); text-align:left; }
        th { color:var(--muted); text-transform:uppercase; font-size:0.8rem; }
        .alert { padding:1rem; border-radius:8px; margin-bottom:1.5rem; }
        .alert-success { background:rgba(29,158,117,0.2); color:var(--green); }
        .alert-error { background:rgba(232,80,10,0.2); color:var(--accent); }
        input[type="checkbox"] { transform: scale(1.2); }
    </style>
</head>
<body>

<div class="dashboard">
    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="sidebar-logo">RIDGE<span>.</span></div>
        <ul class="nav-menu">
            <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="manage_riders.php"><i class="fas fa-motorcycle"></i> Manage Riders</a></li>
            <li><a href="dispatch.php" class="active"><i class="fas fa-paper-plane"></i> Dispatch Orders</a></li>
            <li><a href="mapped_delivery.php"><i class="fas fa-map-marked-alt"></i> Mapped Delivery</a></li>
            <li><a href="enroute.php"><i class="fas fa-satellite-dish"></i> Live Enroute</a></li>
            <li><a href="out.php"><i class="fas fa-box"></i> Dispatched Orders</a></li>
            <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
            <li><a href="settings.php"><i class="fas fa-cog"></i> Fleet Settings</a></li>
        </ul>
        <a href="index.php?logout=1" style="color:var(--muted);"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <h1 style="font-family:'Bebas Neue',sans-serif; font-size:2.4rem;">Dispatch Center</h1>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>

        <!-- Add New Package -->
        <div class="card">
            <h2>Add New Package</h2>
            <form method="POST">
                <?=ridge_csrf_field()?>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem;">
                    <div>
                        <h3 style="color:var(--accent);">Sender</h3>
                        <input type="text" name="sender_name" placeholder="Sender Name" required>
                        <input type="tel" name="sender_phone" placeholder="Sender Phone" required>
                        <textarea name="sender_address" rows="2" placeholder="Sender Address" required></textarea>
                    </div>
                    <div>
                        <h3 style="color:var(--accent);">Recipient</h3>
                        <input type="text" name="recipient_name" placeholder="Recipient Name" required>
                        <input type="tel" name="recipient_phone" placeholder="Recipient Phone" required>
                        <textarea name="recipient_address" rows="2" placeholder="Delivery Address" required></textarea>
                    </div>
                </div>
                <textarea name="package_description" rows="3" placeholder="Package Description" required style="margin-top:1rem; width:100%;"></textarea>
                <input type="date" name="delivery_date" value="<?= date('Y-m-d', strtotime('+1 day')) ?>" required>
                <button type="submit" name="add_package" class="btn-primary" style="margin-top:1.5rem; width:100%;">Add Package</button>
            </form>
        </div>

        <!-- Pending Packages List -->
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem;">
                <h2>Pending Packages (Ready to Dispatch)</h2>
            </div>

            <form method="POST">
                <?=ridge_csrf_field()?>
                <div style="margin-bottom:1rem;display:flex;gap:.7rem;align-items:center;flex-wrap:wrap;">
                    <label style="color:var(--muted);">Assign Selected Packages To Rider:</label>
                    <select name="rider_id" required style="padding:0.8rem; width:300px;">
                        <option value="">Select Rider...</option>
                        <?php foreach ($riders_arr as $r): ?>
                            <option value="<?= (int)$r['id'] ?>"><?= h($r['rider_name']) ?> (<?= h($r['bike_plate']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" name="assign_rider" class="btn-primary">Assign Selected</button>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th><input type="checkbox" onclick="toggleAll(this,'pending-selected')"></th>
                            <th>Tracking ID</th>
                            <th>Recipient</th>
                            <th>Package</th>
                            <th>Delivery Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($pending->num_rows > 0): ?>
                            <?php while ($row = $pending->fetch_assoc()): ?>
                            <tr>
                                <td><input class="pending-selected" type="checkbox" name="selected[]" value="<?= (int)$row['id'] ?>"></td>
                                <td><strong><?= htmlspecialchars($row['tracking_id']) ?></strong></td>
                                <td><?= htmlspecialchars($row['recipient_name']) ?></td>
                                <td><?= htmlspecialchars(substr($row['package_description'], 0, 60)) ?>...</td>
                                <td><?= $row['delivery_date'] ?></td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="text-align:center; padding:3rem; color:var(--muted);">
                                    No pending packages yet. Add some above.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </form>
        </div>

        <!-- Returned Items Queue -->
        <div class="card" id="returned-items" style="border-color:rgba(212,85,85,.32);">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap;margin-bottom:1.2rem;">
                <div>
                    <h2 style="margin:0;">Returned to Last Mile</h2>
                    <p style="color:var(--muted);margin:.35rem 0 0;font-size:.86rem;">Review the rider's reason, then reassign the item for another delivery attempt.</p>
                </div>
                <span style="background:rgba(212,85,85,.14);color:#ff9d9d;padding:.35rem .75rem;border-radius:999px;font-weight:600;"><?= (int)$returned->num_rows ?> awaiting action</span>
            </div>

            <form method="POST">
                <?=ridge_csrf_field()?>
                <div style="margin-bottom:1rem;display:flex;gap:.7rem;align-items:center;flex-wrap:wrap;">
                    <label style="color:var(--muted);">Reassign Selected Returned Items:</label>
                    <select name="rider_id" required style="padding:0.8rem;width:300px;">
                        <option value="">Select Rider...</option>
                        <?php foreach ($riders_arr as $r): ?>
                            <option value="<?= (int)$r['id'] ?>"><?= h($r['rider_name']) ?> (<?= h($r['bike_plate']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" name="reassign_returned" class="btn-primary">Reassign for Delivery</button>
                </div>

                <div style="overflow-x:auto;">
                <table>
                    <thead><tr>
                        <th><input type="checkbox" onclick="toggleAll(this,'returned-selected')"></th>
                        <th>Tracking ID</th><th>Recipient</th><th>Returned By</th><th>Reason</th><th>Details</th><th>Returned At</th><th>Returns</th>
                    </tr></thead>
                    <tbody>
                    <?php if($returned->num_rows>0):?>
                        <?php while($row=$returned->fetch_assoc()):?>
                        <tr>
                            <td><input class="returned-selected" type="checkbox" name="selected[]" value="<?= (int)$row['id'] ?>"></td>
                            <td><strong><?=h($row['tracking_id'])?></strong></td>
                            <td><?=h($row['recipient_name'])?><br><small style="color:var(--muted)"><?=h($row['recipient_phone'])?></small></td>
                            <td><?=h($row['returned_by_name']?:'Rider')?></td>
                            <td style="color:#ffb08b;font-weight:600;"><?=h(ridge_return_reason_label((string)$row['return_reason']))?></td>
                            <td style="white-space:normal;min-width:220px;color:var(--muted)"><?=h($row['return_notes']?:'No additional details')?></td>
                            <td><?= $row['returned_at'] ? h(date('d M Y, h:i A',strtotime($row['returned_at']))) : '—' ?></td>
                            <td><?= (int)$row['return_count'] ?></td>
                        </tr>
                        <?php endwhile;?>
                    <?php else:?><tr><td colspan="8" style="text-align:center;padding:3rem;color:var(--muted);">No items are waiting in the return queue.</td></tr><?php endif;?>
                    </tbody>
                </table>
                </div>
            </form>
        </div>

    </div>
</div>

<script>
function toggleAll(source, className) {
    const checkboxes = document.getElementsByClassName(className);
    for (let i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = source.checked;
    }
}
</script>
</body>
</html>