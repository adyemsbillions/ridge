<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_SESSION['partner_id'])) {
    ridge_redirect('index.php');
}

$partnerId = (int) $_SESSION['partner_id'];
$success = '';
$error = '';
$temporaryPassword = '';

function ridge_generate_rider_password(int $length = 12): string
{
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
    $password = '';
    $max = strlen($alphabet) - 1;
    for ($i = 0; $i < $length; $i++) {
        $password .= $alphabet[random_int(0, $max)];
    }
    return $password;
}

function ridge_send_rider_welcome_email(string $email, string $riderName, string $phone, string $password): bool
{
    $host = trim((string) ridge_config('smtp_host', ''));
    $username = trim((string) ridge_config('smtp_username', ''));
    $smtpPassword = (string) ridge_config('smtp_password', '');
    $from = trim((string) ridge_config('email_from', ''));

    if ($host === '' || $username === '' || $smtpPassword === '' || $from === '') {
        error_log('RIDGE rider welcome email skipped: SMTP settings are incomplete.');
        return false;
    }

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = $host;
        $mail->SMTPAuth = true;
        $mail->Username = $username;
        $mail->Password = $smtpPassword;
        $mail->Port = (int) ridge_config('smtp_port', 465);

        $encryption = strtolower(trim((string) ridge_config('smtp_encryption', 'ssl')));
        if ($encryption === 'tls') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        } elseif ($encryption === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } else {
            $mail->SMTPAutoTLS = false;
        }

        $fromName = trim((string) ridge_config('email_from_name', 'RIDGE Dispatch')) ?: 'RIDGE Dispatch';
        $mail->setFrom($from, $fromName);
        $mail->addAddress($email, $riderName);
        $mail->isHTML(true);
        $mail->Subject = 'Your RIDGE Rider Account Details';

        $safeName = h($riderName);
        $safePhone = h($phone);
        $safePassword = h($password);
        $loginUrl = h(ridge_url('riders/rider_login.php'));

        $mail->Body = <<<HTML
<!doctype html>
<html lang="en"><body style="margin:0;background:#f4f4f4;font-family:Arial,sans-serif;color:#1a1a1a">
  <div style="max-width:600px;margin:24px auto;background:#fff;border-radius:14px;padding:32px;box-shadow:0 8px 30px rgba(0,0,0,.08)">
    <div style="font-size:30px;font-weight:800;letter-spacing:.08em">RIDGE<span style="color:#E8500A">.</span></div>
    <h1 style="font-size:24px;margin:24px 0 10px">Welcome to the rider team</h1>
    <p>Hello <strong>{$safeName}</strong>, your rider account has been created.</p>
    <div style="background:#f7f5f0;border-radius:10px;padding:18px;margin:22px 0;line-height:1.8">
      <strong>Login details</strong><br>
      Phone: <strong>{$safePhone}</strong><br>
      Temporary password: <strong>{$safePassword}</strong>
    </div>
    <a href="{$loginUrl}" style="display:inline-block;background:#E8500A;color:#fff;text-decoration:none;padding:13px 22px;border-radius:8px;font-weight:700">Open Rider App</a>
    <p style="font-size:13px;color:#6B6860;margin-top:24px">Keep the temporary password private and contact your company if you cannot sign in.</p>
  </div>
</body></html>
HTML;
        $mail->AltBody = "Hello {$riderName}, your RIDGE rider login is {$phone} and your temporary password is {$password}. Login: " . ridge_url('riders/rider_login.php');
        $mail->send();
        return true;
    } catch (Exception $exception) {
        error_log('RIDGE rider welcome email failed: ' . $exception->getMessage());
        return false;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ridge_require_csrf();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'add_rider') {
        $riderName = trim((string) ($_POST['rider_name'] ?? ''));
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $phone = trim((string) ($_POST['phone'] ?? ''));
        $bikePlate = strtoupper(trim((string) ($_POST['bike_plate'] ?? '')));

        if ($riderName === '' || $email === '' || $phone === '' || $bikePlate === '') {
            $error = 'Complete every rider field.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Enter a valid email address.';
        } elseif (strlen(ridge_normalize_phone($phone)) < 10) {
            $error = 'Enter a valid rider phone number.';
        } else {
            $duplicate = $conn->prepare('SELECT id FROM riders WHERE email=? OR phone=? LIMIT 1');
            $duplicate->bind_param('ss', $email, $phone);
            $duplicate->execute();
            if ($duplicate->get_result()->fetch_assoc()) {
                $error = 'A rider already uses that email address or phone number.';
            } else {
                $plainPassword = ridge_generate_rider_password();
                $hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO riders (partner_id, rider_name, email, phone, bike_plate, password, status) VALUES (?, ?, ?, ?, ?, ?, 'active')");
                $stmt->bind_param('isssss', $partnerId, $riderName, $email, $phone, $bikePlate, $hashedPassword);
                if ($stmt->execute()) {
                    if (ridge_send_rider_welcome_email($email, $riderName, $phone, $plainPassword)) {
                        $success = 'Rider added. Login details were emailed successfully.';
                    } else {
                        $success = 'Rider added, but the welcome email could not be delivered. Copy the temporary password below and share it securely.';
                        $temporaryPassword = $plainPassword;
                    }
                } else {
                    $error = 'The rider could not be added. Review the details and try again.';
                }
            }
        }
    } elseif ($action === 'toggle_rider') {
        $riderId = (int) ($_POST['rider_id'] ?? 0);
        $newStatus = (string) ($_POST['new_status'] ?? 'inactive');
        if (!in_array($newStatus, ['active', 'inactive'], true)) {
            $error = 'Invalid rider status.';
        } else {
            $stmt = $conn->prepare('UPDATE riders SET status=? WHERE id=? AND partner_id=?');
            $stmt->bind_param('sii', $newStatus, $riderId, $partnerId);
            $stmt->execute();
            $success = $stmt->affected_rows > 0 ? 'Rider status updated.' : 'No rider status was changed.';
        }
    } elseif ($action === 'delete_rider') {
        $riderId = (int) ($_POST['rider_id'] ?? 0);
        $count = $conn->prepare('SELECT COUNT(*) AS total FROM deliveries WHERE rider_id=?');
        $count->bind_param('i', $riderId);
        $count->execute();
        $deliveryCount = (int) ($count->get_result()->fetch_assoc()['total'] ?? 0);

        if ($deliveryCount > 0) {
            $error = 'This rider has delivery history and cannot be permanently deleted. Deactivate the account instead.';
        } else {
            $stmt = $conn->prepare('DELETE FROM riders WHERE id=? AND partner_id=?');
            $stmt->bind_param('ii', $riderId, $partnerId);
            $stmt->execute();
            $success = $stmt->affected_rows > 0 ? 'Rider deleted.' : 'The rider could not be found.';
        }
    }
}

$stmt = $conn->prepare("SELECT r.*,
    COALESCE(SUM(d.status IN ('assigned','enroute')),0) AS active_deliveries,
    COALESCE(SUM(d.status='delivered'),0) AS completed_deliveries
    FROM riders r
    LEFT JOIN deliveries d ON d.rider_id=r.id
    WHERE r.partner_id=?
    GROUP BY r.id
    ORDER BY r.created_at DESC");
$stmt->bind_param('i', $partnerId);
$stmt->execute();
$riders = $stmt->get_result();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Manage Riders - RIDGE</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="../assets/fontawesome.css">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--black:#0a0a0a;--mid:#151515;--card:#111;--off:#f5f2eb;--accent:#e8500a;--muted:#97938b;--green:#34c48a;--border:rgba(245,242,235,.12)}
*{box-sizing:border-box}body{margin:0;background:var(--black);color:var(--off);font-family:'DM Sans',sans-serif}.layout{min-height:100vh;display:grid;grid-template-columns:260px 1fr}.sidebar{background:var(--mid);border-right:1px solid var(--border);padding:28px 22px;position:sticky;top:0;height:100vh}.logo{font:42px 'Bebas Neue';letter-spacing:.1em;margin-bottom:34px}.logo span{color:var(--accent)}nav a{display:flex;align-items:center;gap:.7rem;color:var(--muted);text-decoration:none;padding:12px 14px;border-radius:8px;margin:4px 0}nav a:hover,nav a.active{background:rgba(232,80,10,.15);color:var(--off)}.logout{position:absolute;bottom:28px;color:var(--muted);text-decoration:none}.main{padding:34px;min-width:0}.top{display:flex;align-items:center;justify-content:space-between;gap:18px;margin-bottom:24px}.top h1{font:48px/1 'Bebas Neue';letter-spacing:.04em;margin:0}.btn{border:0;border-radius:8px;padding:12px 17px;font:600 14px 'DM Sans';cursor:pointer}.primary{background:var(--accent);color:#fff}.secondary{background:transparent;border:1px solid var(--border);color:var(--off)}.danger{background:transparent;border:1px solid rgba(232,80,10,.45);color:#ff8350}.card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:22px;margin-bottom:22px}.alert{padding:14px 16px;border-radius:9px;margin-bottom:18px}.success{background:rgba(52,196,138,.14);color:#7ce2b5}.error{background:rgba(232,80,10,.16);color:#ff9b70}.password-box{font:700 22px monospace;letter-spacing:.08em;background:#050505;border:1px dashed var(--accent);padding:13px 16px;border-radius:8px;display:inline-block;margin-top:10px}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.field label{display:block;color:var(--muted);font-size:13px;margin-bottom:7px}.field input{width:100%;padding:12px 13px;color:#fff;background:#090909;border:1px solid var(--border);border-radius:8px}.actions{display:flex;flex-wrap:wrap;gap:8px}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;min-width:900px}th,td{text-align:left;padding:15px 12px;border-bottom:1px solid var(--border)}th{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}.status{display:inline-block;padding:5px 9px;border-radius:20px;font-size:12px;font-weight:700}.active{background:rgba(52,196,138,.14);color:#7ce2b5}.inactive{background:rgba(151,147,139,.13);color:#bbb7ae}.empty{text-align:center;color:var(--muted);padding:42px}.mobile-nav{display:none}
@media(max-width:900px){.layout{display:block}.sidebar{display:none}.main{padding:22px 16px 92px}.top{align-items:flex-start}.top h1{font-size:40px}.form-grid{grid-template-columns:1fr}.mobile-nav{position:fixed;display:flex;left:0;right:0;bottom:0;background:#111;border-top:1px solid var(--border);z-index:10}.mobile-nav a{flex:1;text-align:center;color:var(--muted);text-decoration:none;padding:14px 5px;font-size:12px}.mobile-nav a.active{color:var(--accent)}}
</style>
</head>
<body>
<div class="layout">
<aside class="sidebar">
  <div class="logo">RIDGE<span>.</span></div>
  <nav>
    <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a class="active" href="manage_riders.php"><i class="fas fa-motorcycle"></i> Manage Riders</a>
    <a href="dispatch.php"><i class="fas fa-paper-plane"></i> Dispatch Orders</a>
    <a href="mapped_delivery.php"><i class="fas fa-map-marked-alt"></i> Mapped Delivery</a>
    <a href="enroute.php"><i class="fas fa-satellite-dish"></i> Live Enroute</a>
    <a href="out.php"><i class="fas fa-box"></i> Dispatched Orders</a>
    <a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <a href="settings.php"><i class="fas fa-cog"></i> Fleet Settings</a>
  </nav>
  <a class="logout" href="index.php?logout=1"><i class="fas fa-sign-out-alt"></i> Sign out</a>
</aside>
<main class="main">
  <div class="top"><div><h1>Manage Riders</h1><div style="color:var(--muted);margin-top:6px">Create accounts, control access and review rider activity.</div></div><button class="btn primary" type="button" onclick="document.getElementById('add-card').hidden=false">+ Add rider</button></div>
  <?php if ($success !== ''): ?><div class="alert success"><?=h($success)?><?php if ($temporaryPassword !== ''): ?><br><span class="password-box"><?=h($temporaryPassword)?></span><?php endif; ?></div><?php endif; ?>
  <?php if ($error !== ''): ?><div class="alert error"><?=h($error)?></div><?php endif; ?>

  <section id="add-card" class="card" <?=($error !== '' && ($_POST['action'] ?? '') === 'add_rider') ? '' : 'hidden'?>>
    <div style="display:flex;justify-content:space-between;gap:15px;align-items:center;margin-bottom:18px"><div><strong style="font-size:20px">New rider account</strong><div style="color:var(--muted);font-size:13px;margin-top:4px">A secure temporary password will be created automatically.</div></div><button class="btn secondary" type="button" onclick="this.closest('.card').hidden=true">Close</button></div>
    <form method="post">
      <?=ridge_csrf_field()?>
      <input type="hidden" name="action" value="add_rider">
      <div class="form-grid">
        <div class="field"><label>Full name</label><input name="rider_name" required maxlength="120" value="<?=h($_POST['rider_name']??'')?>"></div>
        <div class="field"><label>Email address</label><input type="email" name="email" required maxlength="160" value="<?=h($_POST['email']??'')?>"></div>
        <div class="field"><label>Phone number</label><input type="tel" name="phone" required maxlength="30" value="<?=h($_POST['phone']??'')?>"></div>
        <div class="field"><label>Bike plate number</label><input name="bike_plate" required maxlength="40" value="<?=h($_POST['bike_plate']??'')?>"></div>
      </div>
      <div style="margin-top:18px"><button class="btn primary" type="submit">Create rider and send login</button></div>
    </form>
  </section>

  <section class="card table-wrap">
    <table>
      <thead><tr><th>Rider</th><th>Contact</th><th>Bike</th><th>Status</th><th>Active jobs</th><th>Completed</th><th>Actions</th></tr></thead>
      <tbody>
      <?php if ($riders->num_rows === 0): ?><tr><td colspan="7" class="empty">No riders have been added yet.</td></tr><?php endif; ?>
      <?php while ($rider = $riders->fetch_assoc()): $isActive = $rider['status'] === 'active'; ?>
        <tr>
          <td><strong><?=h($rider['rider_name'])?></strong></td>
          <td><?=h($rider['email'])?><br><span style="color:var(--muted);font-size:13px"><?=h($rider['phone'])?></span></td>
          <td><?=h($rider['bike_plate'])?></td>
          <td><span class="status <?=$isActive?'active':'inactive'?>"><?=h(ucfirst($rider['status']))?></span></td>
          <td><?=number_format((int)$rider['active_deliveries'])?></td>
          <td><?=number_format((int)$rider['completed_deliveries'])?></td>
          <td><div class="actions">
            <form method="post"><?=ridge_csrf_field()?><input type="hidden" name="action" value="toggle_rider"><input type="hidden" name="rider_id" value="<?=(int)$rider['id']?>"><input type="hidden" name="new_status" value="<?=$isActive?'inactive':'active'?>"><button class="btn secondary" type="submit"><?=$isActive?'Deactivate':'Activate'?></button></form>
            <form method="post" onsubmit="return confirm('Permanently delete this rider? This works only when there is no delivery history.')"><?=ridge_csrf_field()?><input type="hidden" name="action" value="delete_rider"><input type="hidden" name="rider_id" value="<?=(int)$rider['id']?>"><button class="btn danger" type="submit">Delete</button></form>
          </div></td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </section>
</main>
</div>
<nav class="mobile-nav"><a href="dashboard.php"><i class="fas fa-home"></i><br>Home</a><a class="active" href="manage_riders.php"><i class="fas fa-motorcycle"></i><br>Riders</a><a href="dispatch.php"><i class="fas fa-paper-plane"></i><br>Dispatch</a><a href="enroute.php"><i class="fas fa-satellite-dish"></i><br>Live</a><a href="reports.php"><i class="fas fa-chart-bar"></i><br>Reports</a></nav>
</body>
</html>
