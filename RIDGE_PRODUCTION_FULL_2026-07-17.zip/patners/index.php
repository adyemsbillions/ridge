<?php
require_once '../includes/bootstrap.php';

// Logout
if (isset($_GET['logout'])) {
    unset($_SESSION['partner_id'], $_SESSION['company_name']);
    session_regenerate_id(true);
    ridge_redirect('index.php');
}

// ==================== LOGIN HANDLER ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    ridge_require_csrf();
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $password = (string) ($_POST['password'] ?? '');

    $stmt = $conn->prepare("SELECT id, company_name, password, status FROM partners WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if ($row['status'] === 'pending') {
            $login_error = 'Your account is awaiting admin approval.';
        } elseif ($row['status'] !== 'active') {
            $login_error = 'This partner account is inactive. Contact RIDGE support.';
        } elseif (password_verify($password, $row['password'])) {
            session_regenerate_id(true);
            $_SESSION['partner_id'] = (int) $row['id'];
            $_SESSION['company_name'] = (string) $row['company_name'];
            ridge_redirect('dashboard.php');
        } else {
            $login_error = 'Invalid email address or password.';
        }
    } else {
        $login_error = 'Invalid email address or password.';
    }
}

// ==================== SIGNUP HANDLER ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signup'])) {
    ridge_require_csrf();
    $company_name     = trim($_POST['company_name']);
    $company_address  = trim($_POST['company_address']);
    $num_dispatchers  = (int)$_POST['num_dispatchers'];
    $phone            = trim($_POST['phone']);
    $email            = strtolower(trim((string) ($_POST['email'] ?? '')));
    $contact_person   = trim($_POST['contact_person']);
    $password         = (string) ($_POST['password'] ?? '');
    $confirm_password = (string) ($_POST['confirm_password'] ?? '');

    $errors = [];

    if (empty($company_name)) $errors[] = "Company name is required.";
    if (empty($company_address)) $errors[] = "Company address is required.";
    if ($num_dispatchers < 1) $errors[] = "Number of dispatchers must be at least 1.";
    if (empty($phone)) $errors[] = "Phone number is required.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Valid email is required.";
    if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
    if ($password !== $confirm_password) $errors[] = "Passwords do not match.";

    $check = $conn->prepare("SELECT id FROM partners WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        $errors[] = "This email is already registered.";
    }

    if (empty($errors)) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO partners 
            (company_name, company_address, num_dispatchers, phone, email, contact_person, password, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
        
        $stmt->bind_param("ssissss", $company_name, $company_address, $num_dispatchers, $phone, $email, $contact_person, $hashed);

        if ($stmt->execute()) {
            $success = "Account created successfully!<br>Your account is now <strong>pending admin approval</strong>.";
        } else {
            $errors[] = "Registration failed. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RIDGE Partners – Grow Your Delivery Business</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="../assets/fontawesome.css">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --black: #0A0A0A; --off-white: #F5F2EB; --accent: #E8500A;
            --accent-dim: #B03D06; --mid: #1A1A1A; --muted: #6B6860;
            --border: rgba(245,242,235,0.12); --card-bg: #111111; --green: #1D9E75;
        }
        .hero {
            min-height: 100vh;
            display: grid;
            grid-template-columns: 1fr 1fr;
            align-items: center;
            padding: 8rem 4rem 4rem;
            gap: 4rem;
            position: relative;
        }
        .auth-container {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 2.5rem;
            max-width: 460px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        }
        .alert {
            padding: 1rem 1.25rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
        }
        .alert-success { background: rgba(29,158,117,0.15); border:1px solid var(--green); color:var(--green); }
        .alert-error { background: rgba(232,80,10,0.15); border:1px solid var(--accent); color:var(--accent); }

        .tab-buttons { display: flex; background: rgba(255,255,255,0.05); border-radius: 8px; padding: 4px; margin-bottom: 2rem; }
        .tab-btn { flex:1; padding:0.85rem; border:none; background:transparent; color:var(--muted); font-weight:600; border-radius:6px; cursor:pointer; }
        .tab-btn.active { background:var(--accent); color:white; }

        .form-group { margin-bottom: 1.25rem; }
        .form-group label { display:block; margin-bottom:0.5rem; font-size:0.85rem; color:var(--muted); }
        .form-group input, .form-group textarea {
            width:100%; padding:0.9rem 1rem; background:rgba(255,255,255,0.05);
            border:1px solid var(--border); border-radius:6px; color:var(--off-white);
        }
        .password-wrapper { position:relative; }
        .toggle-password {
            position:absolute; right:1rem; top:50%; transform:translateY(-50%);
            background:none; border:none; color:var(--muted); cursor:pointer; font-size:1.25rem;
        }
    </style>
</head>
<body>
    <!-- NAV -->
    <nav style="position:fixed; top:0; left:0; right:0; z-index:100; background:rgba(10,10,10,0.9); backdrop-filter:blur(12px); padding:1.25rem 4rem; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--border);">
        <div class="nav-logo">RIDGE<span>.</span></div>
        <a href="../" style="color:var(--muted);">Back Back to Main Site</a>
    </nav>

    <!-- HERO WITH RIGHT SIDE AUTH -->
    <section class="hero">
        <div class="hero-grid-bg"></div>
        
        <!-- Left Side -->
        <div class="hero-left">
            <div class="hero-eyebrow">FOR FLEET OWNERS & LOGISTICS COMPANIES</div>
            <h1>WELCOME<br>PARTNERS</h1>
            <p class="hero-sub">Manage your dispatch fleet smarter. Reduce fuel costs, improve on-time delivery, and scale your operations in Lagos.</p>
            <div class="hero-actions">
                <a href="#auth-form" class="btn-primary">Join as Partner</a>
                <a href="#auth-form" class="btn-ghost">Login</a>
            </div>
        </div>

        <!-- Right Side - Auth Form -->
        <div class="hero-right" id="auth-form">
            <div class="auth-container">
                <div class="tab-buttons">
                    <button class="tab-btn active" onclick="switchTab(0)">Login</button>
                    <button class="tab-btn" onclick="switchTab(1)">Register</button>
                </div>

                <!-- Login Form -->
                <div id="login-form">
                    <?php if (isset($login_error)): ?>
                        <div class="alert alert-error"><?= h($login_error) ?></div>
                    <?php endif; ?>
                    <form method="POST">
                        <?= ridge_csrf_field() ?>
                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <div class="password-wrapper">
                                <input type="password" id="login-pass" name="password" required>
                                <button type="button" class="toggle-password" onclick="togglePassword('login-pass')"><i class="fas fa-eye"></i></button>
                            </div>
                        </div>
                        <button type="submit" name="login" class="btn-primary" style="width:100%; padding:1rem;">Login to Dashboard</button>
                    </form>
                </div>

                <!-- Signup Form -->
                <div id="signup-form" style="display:none;">
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-error">
                            <?php foreach($errors as $e): ?>
                                <p>• <?= h($e) ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success">Account created successfully. It is now pending admin approval.</div>
                    <?php endif; ?>

                    <form method="POST">
                        <?= ridge_csrf_field() ?>
                        <div class="form-group"><label>Company Name</label><input type="text" name="company_name" required></div>
                        <div class="form-group"><label>Company Address</label><input type="text" name="company_address" required></div>
                        <div class="form-group"><label>Number of Dispatchers</label><input type="number" name="num_dispatchers" min="1" required></div>
                        <div class="form-group"><label>Phone Number</label><input type="tel" name="phone" required></div>
                        <div class="form-group"><label>Email Address</label><input type="email" name="email" required></div>
                        <div class="form-group"><label>Contact Person</label><input type="text" name="contact_person" required></div>
                        
                        <div class="form-group">
                            <label>Password</label>
                            <div class="password-wrapper">
                                <input type="password" id="signup-pass" name="password" minlength="8" required>
                                <button type="button" class="toggle-password" onclick="togglePassword('signup-pass')"><i class="fas fa-eye"></i></button>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <div class="password-wrapper">
                                <input type="password" id="confirm-pass" name="confirm_password" minlength="8" required>
                                <button type="button" class="toggle-password" onclick="togglePassword('confirm-pass')"><i class="fas fa-eye"></i></button>
                            </div>
                        </div>
                        <button type="submit" name="signup" class="btn-primary" style="width:100%; padding:1rem;">Create Partner Account</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <script>
        function switchTab(n) {
            document.getElementById('login-form').style.display = n === 0 ? 'block' : 'none';
            document.getElementById('signup-form').style.display = n === 1 ? 'block' : 'none';
            document.querySelectorAll('.tab-btn').forEach((el,i) => el.classList.toggle('active', i===n));
        }
        function togglePassword(id) {
            const inp = document.getElementById(id);
            const btn = inp.parentElement.querySelector('.toggle-password');
            if (inp.type === 'password') {
                inp.type = 'text';
                btn.innerHTML = '<i class="fas fa-eye-slash"></i>';
            } else {
                inp.type = 'password';
                btn.innerHTML = '<i class="fas fa-eye"></i>';
            }
        }
    </script>
</body>
</html>