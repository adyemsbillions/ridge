<?php
require_once '../includes/bootstrap.php';
require_once '../includes/notifications.php';
if (!isset($_SESSION['partner_id'])) {
    ridge_redirect('index.php');
}
$partner_id = (int) $_SESSION['partner_id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $delivery_id = (int) ($_POST['delivery_id'] ?? 0);
    $new_status = (string) ($_POST['status'] ?? '');
    $allowed = ['assigned','enroute','delivered','cancelled'];
    $owned = $conn->prepare('SELECT d.*,r.rider_name FROM deliveries d LEFT JOIN riders r ON r.id=d.rider_id WHERE d.id=? AND d.partner_id=? LIMIT 1');
    $owned->bind_param('ii', $delivery_id, $partner_id); $owned->execute();
    $delivery = $owned->get_result()->fetch_assoc();
    if ($delivery && in_array($new_status, $allowed, true) && ridge_set_delivery_status($conn, $delivery_id, $new_status, 'partner', $partner_id, 'Status updated from the partner dashboard.')) {
        $delivery['status'] = $new_status;
        ridge_notify_delivery_status($conn, $delivery, $new_status, (string) ($delivery['rider_name'] ?? ''));
        $success = 'Status updated successfully!';
    }
}
$stmt = $conn->prepare("SELECT d.*,r.rider_name,r.bike_plate FROM deliveries d LEFT JOIN riders r ON d.rider_id=r.id WHERE d.partner_id=? AND d.status!='pending' ORDER BY d.created_at DESC");
$stmt->bind_param('i', $partner_id); $stmt->execute(); $dispatched = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dispatched Orders - RIDGE</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="../assets/fontawesome.css">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --black:#0A0A0A; --off-white:#F5F2EB; --accent:#E8500A;
            --mid:#1A1A1A; --muted:#6B6860; --border:rgba(245,242,235,0.12);
            --card-bg:#111111; --green:#1D9E75;
        }
        body { font-family:'DM Sans',sans-serif; background:var(--black); color:var(--off-white); margin:0; }
        .dashboard { display:flex; min-height:100vh; }
        .sidebar { width:260px; background:var(--mid); border-right:1px solid var(--border); padding:2rem 1.5rem; position:fixed; height:100vh; }
        .sidebar-logo { font-family:'Bebas Neue',sans-serif; font-size:2.2rem; letter-spacing:0.1em; margin-bottom:3rem; }
        .sidebar-logo span { color:var(--accent); }
        .nav-menu a { display:flex; align-items:center; gap:1rem; padding:0.9rem 1.25rem; color:var(--muted); text-decoration:none; border-radius:8px; }
        .nav-menu a:hover, .nav-menu a.active { background:rgba(232,80,10,0.15); color:var(--off-white); }
        .main-content { flex:1; margin-left:260px; padding:2rem; }
        .card { background:var(--card-bg); border:1px solid var(--border); border-radius:12px; padding:2rem; margin-bottom:2rem; }
        table { width:100%; border-collapse:collapse; }
        th, td { padding:1rem; border-bottom:1px solid var(--border); text-align:left; }
        th { color:var(--muted); text-transform:uppercase; font-size:0.8rem; letter-spacing:0.05em; }
        .status-pending { color:#FFAA00; }
        .status-assigned { color:#FF8800; }
        .status-enroute { color:var(--accent); font-weight:600; }
        .status-delivered { color:var(--green); }
        .status-returned { color:#ff9d9d; font-weight:600; }
        .alert { padding:1rem; border-radius:8px; margin-bottom:1.5rem; }
        .alert-success { background:rgba(29,158,117,0.2); color:var(--green); }
    </style>
</head>
<body>

<div class="dashboard">
    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="sidebar-logo">RIDGE<span>.</span></div>
        <ul class="nav-menu">
            <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="manage_riders.php"><i class="fas fa-motorcycle"></i> Manage Riders</a></li>
            <li><a href="dispatch.php"><i class="fas fa-paper-plane"></i> Dispatch Orders</a></li>
            <li><a href="mapped_delivery.php"><i class="fas fa-map-marked-alt"></i> Mapped Delivery</a></li>
            <li><a href="enroute.php"><i class="fas fa-satellite-dish"></i> Live Enroute</a></li>
            <li><a href="out.php" class="active"><i class="fas fa-box"></i> Dispatched Orders</a></li>
            <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
            <li><a href="settings.php"><i class="fas fa-cog"></i> Fleet Settings</a></li>
        </ul>
        <a href="index.php?logout=1" style="color:var(--muted); margin-top:auto; display:block;"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <h1 style="font-family:'Bebas Neue',sans-serif; font-size:2.4rem; margin-bottom:1rem;">Dispatched Orders</h1>
        <p style="color:var(--muted);">All orders that have been assigned to riders</p>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>

        <div class="card">
            <?php if ($dispatched->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Tracking ID</th>
                            <th>Recipient</th>
                            <th>Rider</th>
                            <th>Package Summary</th>
                            <th>Delivery Date</th>
                            <th>Current Status</th>
                            <th>Return Reason</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $dispatched->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($row['tracking_id']) ?></strong></td>
                            <td><?= htmlspecialchars($row['recipient_name']) ?></td>
                            <td><?= htmlspecialchars($row['status']==='returned' ? 'At last-mile hub' : ($row['rider_name'] ?? 'Not Assigned')) ?></td>
                            <td><?= htmlspecialchars(substr($row['package_description'], 0, 55)) ?>...</td>
                            <td><?= $row['delivery_date'] ?></td>
                            <td>
                                <span class="status-<?=h($row['status'])?>">
                                    <?=h(strtoupper(ridge_delivery_status_label((string)$row['status'])))?>
                                </span>
                            </td>
                            <td><?= $row['status']==='returned' ? h(ridge_return_reason_label((string)$row['return_reason'])) : '—' ?></td>
                            <td>
                                <?php if($row['status']==='returned'):?>
                                    <a href="dispatch.php#returned-items" style="color:#ff9d9d;text-decoration:none;font-weight:600;">Review & reassign to</a>
                                <?php else:?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="delivery_id" value="<?= $row['id'] ?>">
                                    <select name="status" onchange="this.form.submit()" style="padding:0.4rem; border-radius:6px;">
                                        <option value="assigned" <?= $row['status']=='assigned' ? 'selected' : '' ?>>Assigned</option>
                                        <option value="enroute" <?= $row['status']=='enroute' ? 'selected' : '' ?>>Enroute</option>
                                        <option value="delivered" <?= $row['status']=='delivered' ? 'selected' : '' ?>>Delivered</option>
                                        <option value="cancelled" <?= $row['status']=='cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                    </select>
                                    <input type="hidden" name="update_status" value="1">
                                </form>
                                <?php endif;?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align:center; padding:4rem 2rem; color:var(--muted);">
                    <h3>No dispatched orders yet.</h3>
                    <p>Go to <a href="dispatch.php" style="color:var(--accent);">Dispatch Orders</a> to assign packages.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>