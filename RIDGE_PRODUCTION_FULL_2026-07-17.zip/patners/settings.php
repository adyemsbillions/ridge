<?php
require_once '../includes/bootstrap.php';
if (!isset($_SESSION['partner_id'])) {
    ridge_redirect('index.php');
}

$partnerId = (int) $_SESSION['partner_id'];
$companyName = (string) ($_SESSION['company_name'] ?? 'Partner');
$feedback = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!ridge_verify_csrf()) {
        $feedback = ['type' => 'error', 'text' => 'Your session expired. Refresh the page and try again.'];
    } else {
        $fuelPrice = (float) ($_POST['fuel_price_per_litre'] ?? 0);
        $efficiency = (float) ($_POST['fuel_efficiency_km_per_litre'] ?? 35);
        if ($fuelPrice < 0 || $fuelPrice > 100000) {
            $feedback = ['type' => 'error', 'text' => 'Enter a valid fuel price per litre.'];
        } elseif ($efficiency < 5 || $efficiency > 150) {
            $feedback = ['type' => 'error', 'text' => 'Fuel efficiency must be between 5 and 150 km per litre.'];
        } else {
            $stmt = $conn->prepare('UPDATE partners SET fuel_price_per_litre=?,fuel_efficiency_km_per_litre=? WHERE id=?');
            $stmt->bind_param('ddi', $fuelPrice, $efficiency, $partnerId);
            if ($stmt->execute()) {
                $feedback = ['type' => 'success', 'text' => 'Fuel-cost settings have been updated. Dashboard and reports will use these values.'];
            } else {
                $feedback = ['type' => 'error', 'text' => 'The settings could not be saved.'];
            }
        }
    }
}

$settings = ridge_partner_fuel_settings($conn, $partnerId);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fleet Settings — RIDGE</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/fontawesome.css">
<link rel="stylesheet" href="../assets/portal.css">
</head>
<body>
<div class="partner-shell">
    <aside class="partner-sidebar">
        <a class="brand" href="dashboard.php">RIDGE<span>.</span></a>
        <nav class="partner-nav">
            <a href="dashboard.php"><i class="fas fa-home"></i>Dashboard</a>
            <a href="manage_riders.php"><i class="fas fa-motorcycle"></i>Manage riders</a>
            <a href="dispatch.php"><i class="fas fa-paper-plane"></i>Dispatch orders</a>
            <a href="mapped_delivery.php"><i class="fas fa-map-marked-alt"></i>Mapped delivery</a>
            <a href="enroute.php"><i class="fas fa-satellite-dish"></i>Live enroute</a>
            <a href="out.php"><i class="fas fa-box"></i>Dispatched orders</a>
            <a href="reports.php"><i class="fas fa-chart-bar"></i>Reports</a>
            <a class="active" href="settings.php"><i class="fas fa-cog"></i>Fleet settings</a>
        </nav>
        <div class="partner-sidebar-footer"><a class="btn btn-ghost" style="width:100%" href="index.php?logout=1"><i class="fas fa-sign-out-alt"></i> Logout</a></div>
    </aside>
    <main class="partner-main">
        <header class="partner-header">
            <div><div class="eyebrow">Cost intelligence</div><h1>Fleet Settings</h1><p class="lead" style="margin-bottom:0">Set the variables RIDGE should use to calculate route fuel cost and savings for <?=h($companyName)?>.</p></div>
            <div class="partner-header-meta"><span class="soft-chip"><i class="fas fa-gas-pump"></i> Partner controlled</span></div>
        </header>

        <?php if ($feedback): ?><div class="alert alert-<?=h($feedback['type'])?>"><i class="fas <?= $feedback['type']==='success'?'fa-check-circle':'fa-exclamation-triangle' ?> icon-gap"></i><?=h($feedback['text'])?></div><?php endif; ?>

        <section class="card" style="max-width:760px">
            <div class="card-head"><h2>Fuel and bike assumptions</h2><span class="pill assigned">Used in live reports</span></div>
            <div class="card-body">
                <form method="post">
                    <?=ridge_csrf_field()?>
                    <div class="form-grid">
                        <div class="field">
                            <label for="fuel-price">Fuel price per litre (₦)</label>
                            <div class="input-prefix"><i class="fas fa-gas-pump"></i><input id="fuel-price" name="fuel_price_per_litre" type="number" min="0" max="100000" step="0.01" value="<?=h(number_format((float)$settings['fuel_price_per_litre'],2,'.',''))?>" required></div>
                            <div class="form-help">Enter the price your fleet currently pays. Use 0 if you only want litre and distance savings.</div>
                        </div>
                        <div class="field">
                            <label for="fuel-efficiency">Average bike efficiency (km/L)</label>
                            <div class="input-prefix"><i class="fas fa-motorcycle"></i><input id="fuel-efficiency" name="fuel_efficiency_km_per_litre" type="number" min="5" max="150" step="0.1" value="<?=h(number_format((float)$settings['fuel_efficiency_km_per_litre'],1,'.',''))?>" required></div>
                            <div class="form-help">Use the real average for your motorcycles. RIDGE divides route distance by this value.</div>
                        </div>
                    </div>
                    <div class="form-actions"><button class="btn btn-primary" type="submit"><i class="fas fa-check"></i> Save settings</button><a class="btn btn-ghost" href="reports.php"><i class="fas fa-chart-bar"></i> View reports</a></div>
                </form>
            </div>
        </section>

        <section class="card" style="max-width:760px;margin-top:1rem">
            <div class="card-head"><h2>How savings are calculated</h2></div>
            <div class="card-body">
                <div class="detail-grid">
                    <div class="detail"><small>Optimised fuel</small><strong>Shortest route distance ÷ km/L</strong></div>
                    <div class="detail"><small>Other-route fuel</small><strong>Alternative route distance ÷ km/L</strong></div>
                    <div class="detail"><small>Money saved</small><strong>Fuel litres saved × price/L</strong></div>
                    <div class="detail"><small>Fallback</small><strong>15% route baseline when no alternative is returned</strong></div>
                </div>
                <p class="footer-note">Route values are estimates based on road-network routing and the settings above. Actual fuel use may vary with traffic, load, riding style and motorcycle condition.</p>
            </div>
        </section>
    </main>
</div>
</body>
</html>
