<?php
require_once '../includes/bootstrap.php';
if (!isset($_SESSION['partner_id'])) {
    ridge_redirect('index.php');
}

$partnerId = (int) $_SESSION['partner_id'];
$companyName = (string) ($_SESSION['company_name'] ?? 'Your Company');

$stmt = $conn->prepare("SELECT COUNT(*) total, COALESCE(SUM(status IN ('active','on_trip')),0) active FROM riders WHERE partner_id=?");
$stmt->bind_param('i', $partnerId);
$stmt->execute();
$riderStats = $stmt->get_result()->fetch_assoc();

$stmt = $conn->prepare("SELECT
    COUNT(*) total,
    COALESCE(SUM(DATE(created_at)=CURDATE()),0) today,
    COALESCE(SUM(status IN ('assigned','enroute')),0) active,
    COALESCE(SUM(status='returned'),0) returned,
    COALESCE(SUM(status='delivered'),0) delivered,
    COALESCE(SUM(status='delivered' AND DATE(COALESCE(delivered_at,updated_at,created_at))<=delivery_date),0) on_time
FROM deliveries WHERE partner_id=?");
$stmt->bind_param('i', $partnerId);
$stmt->execute();
$deliveryStats = $stmt->get_result()->fetch_assoc();

$stmt = $conn->prepare("SELECT
    COALESCE(SUM(route_distance_km),0) route_km,
    COALESCE(SUM(GREATEST(COALESCE(route_baseline_km,0)-COALESCE(route_distance_km,0),0)),0) saved_km
FROM deliveries
WHERE partner_id=? AND created_at>=DATE_FORMAT(CURDATE(),'%Y-%m-01')");
$stmt->bind_param('i', $partnerId);
$stmt->execute();
$routeStats = $stmt->get_result()->fetch_assoc();

$fuelSettings = ridge_partner_fuel_settings($conn, $partnerId);
$fuelSavings = ridge_route_savings(
    (float) ($routeStats['route_km'] ?? 0),
    (float) ($routeStats['route_km'] ?? 0) + (float) ($routeStats['saved_km'] ?? 0),
    (float) $fuelSettings['fuel_price_per_litre'],
    (float) $fuelSettings['fuel_efficiency_km_per_litre']
);
$delivered = (int) ($deliveryStats['delivered'] ?? 0);
$onTimeRate = $delivered > 0 ? round(((int) $deliveryStats['on_time'] / $delivered) * 100, 1) : 0;

$recentStmt = $conn->prepare("SELECT d.id,d.tracking_id,d.recipient_name,d.status,d.created_at,r.rider_name
    FROM deliveries d LEFT JOIN riders r ON r.id=d.rider_id
    WHERE d.partner_id=? ORDER BY d.created_at DESC LIMIT 7");
$recentStmt->bind_param('i', $partnerId);
$recentStmt->execute();
$recentDeliveries = $recentStmt->get_result();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Partner Dashboard — RIDGE</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/fontawesome.css">
<link rel="stylesheet" href="../assets/portal.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
#partner-live-map{height:430px}.live-list{display:flex;flex-direction:column;max-height:430px;overflow:auto}.live-row{display:grid;grid-template-columns:40px 1fr auto;gap:.7rem;align-items:center;padding:.85rem 1rem;border-bottom:1px solid var(--border);cursor:pointer}.live-row:hover{background:rgba(245,242,235,.025)}.live-row:last-child{border-bottom:0}.live-row .rider-icon{width:38px;height:38px;border-radius:11px;display:grid;place-items:center;background:var(--accent-soft);color:var(--accent)}.live-row strong{display:block;font-size:.87rem}.live-row small{display:block;color:var(--muted);font-size:.7rem;margin-top:.18rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.freshness{font:600 .58rem var(--mono);padding:.22rem .45rem;border-radius:999px;background:rgba(245,242,235,.05);color:var(--muted)}.freshness.live{background:var(--green-soft);color:#69d3ad}.quick-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.7rem}.quick-link{display:flex;align-items:center;gap:.75rem;padding:.9rem;border:1px solid var(--border);border-radius:12px;text-decoration:none;background:rgba(245,242,235,.025);font-size:.82rem;font-weight:600}.quick-link i{width:34px;height:34px;border-radius:10px;background:var(--accent-soft);color:var(--accent);display:grid;place-items:center}.quick-link:hover{border-color:rgba(232,80,10,.35);background:rgba(232,80,10,.06)}@media(max-width:650px){#partner-live-map{height:360px}.quick-grid{grid-template-columns:1fr}.live-row{grid-template-columns:36px 1fr}.live-row .freshness{display:none}}
</style>
</head>
<body>
<div class="partner-shell">
<aside class="partner-sidebar">
    <a class="brand" href="dashboard.php">RIDGE<span>.</span></a>
    <nav class="partner-nav">
        <a class="active" href="dashboard.php"><i class="fas fa-home"></i>Dashboard</a>
        <a href="manage_riders.php"><i class="fas fa-motorcycle"></i>Manage riders</a>
        <a href="dispatch.php"><i class="fas fa-paper-plane"></i>Dispatch orders</a>
        <a href="mapped_delivery.php"><i class="fas fa-map-marked-alt"></i>Mapped delivery</a>
        <a href="enroute.php"><i class="fas fa-satellite-dish"></i>Live enroute</a>
        <a href="out.php"><i class="fas fa-box"></i>Dispatched orders</a>
        <a href="reports.php"><i class="fas fa-chart-bar"></i>Reports</a>
        <a href="settings.php"><i class="fas fa-cog"></i>Fleet settings</a>
    </nav>
    <div class="partner-sidebar-footer"><a class="btn btn-ghost" style="width:100%" href="index.php?logout=1"><i class="fas fa-sign-out-alt"></i> Logout</a></div>
</aside>

<main class="partner-main">
    <header class="partner-header">
        <div><div class="eyebrow">Operations overview</div><h1><?=h($companyName)?></h1><p class="lead" style="margin-bottom:0">Live fleet status, delivery performance and route-cost intelligence.</p></div>
        <div class="partner-header-meta"><span class="soft-chip"><i class="fas fa-calendar-day"></i><?=date('d M Y')?></span><span class="soft-chip live"><i class="fas fa-signal"></i><span id="sync-label">Connecting…</span></span></div>
    </header>

    <section class="clean-stats">
        <article class="clean-stat"><span class="stat-icon"><i class="fas fa-motorcycle"></i></span><small>Active riders</small><strong class="metric-green"><?=(int)$riderStats['active']?></strong><p><?=(int)$riderStats['total']?> riders registered</p></article>
        <article class="clean-stat"><span class="stat-icon"><i class="fas fa-shipping-fast"></i></span><small>Deliveries today</small><strong><?=(int)$deliveryStats['today']?></strong><p><?=(int)$deliveryStats['active']?> currently active</p></article>
        <article class="clean-stat"><span class="stat-icon"><i class="fas fa-stopwatch"></i></span><small>On-time rate</small><strong class="metric-accent"><?=$onTimeRate?><span style="font-size:1rem">%</span></strong><p><?= (int)$deliveryStats['on_time'] ?> completed on schedule</p></article>
        <article class="clean-stat"><span class="stat-icon"><i class="fas fa-gas-pump"></i></span><small>Fuel saved this month</small><strong><?=number_format($fuelSavings['saved_litres'],1)?><span style="font-size:1rem"> L</span></strong><p><?= $fuelSettings['fuel_price_per_litre']>0 ? ridge_format_naira($fuelSavings['saved_cost']).' estimated saving' : 'Set fuel price to see Naira savings' ?></p></article>
        <article class="clean-stat"><span class="stat-icon"><i class="fas fa-box-open"></i></span><small>Returned queue</small><strong class="metric-red"><?=(int)$deliveryStats['returned']?></strong><p><a href="dispatch.php#returned-items" style="color:inherit">Review and reassign items</a></p></article>
    </section>

    <section class="split-layout" style="margin-bottom:1rem">
        <article class="card">
            <div class="card-head"><h2>Live fleet map</h2><span class="soft-chip"><i class="fas fa-sync-alt"></i>10-second refresh</span></div>
            <div class="card-body" style="padding:.65rem"><div id="partner-live-map" class="map-surface"></div></div>
        </article>
        <article class="card">
            <div class="card-head"><h2>Rider activity</h2><span class="pill assigned" id="rider-count">0 riders</span></div>
            <div id="live-rider-list" class="live-list"><div class="empty">Loading rider locations…</div></div>
        </article>
    </section>

    <section class="split-layout">
        <article class="card">
            <div class="card-head"><h2>Recent deliveries</h2><a class="btn btn-primary btn-sm" href="dispatch.php"><i class="fas fa-plus"></i> New dispatch</a></div>
            <div class="table-wrap"><table><thead><tr><th>Tracking ID</th><th>Rider</th><th>Recipient</th><th>Status</th></tr></thead><tbody>
            <?php if ($recentDeliveries->num_rows): while($row=$recentDeliveries->fetch_assoc()): ?>
                <tr><td><strong><?=h($row['tracking_id'])?></strong></td><td><?=h($row['rider_name'] ?: 'Unassigned')?></td><td><?=h($row['recipient_name'])?></td><td><span class="pill <?=h($row['status'])?>"><?=h(ridge_delivery_status_label($row['status']))?></span></td></tr>
            <?php endwhile; else: ?><tr><td colspan="4"><div class="empty">No deliveries have been created yet.</div></td></tr><?php endif; ?>
            </tbody></table></div>
        </article>
        <article class="card">
            <div class="card-head"><h2>Quick actions</h2></div>
            <div class="card-body"><div class="quick-grid">
                <a class="quick-link" href="dispatch.php"><i class="fas fa-paper-plane"></i><span>Dispatch orders</span></a>
                <a class="quick-link" href="manage_riders.php"><i class="fas fa-users"></i><span>Manage riders</span></a>
                <a class="quick-link" href="enroute.php"><i class="fas fa-satellite-dish"></i><span>Live tracking</span></a>
                <a class="quick-link" href="reports.php"><i class="fas fa-chart-bar"></i><span>View reports</span></a>
                <a class="quick-link" href="settings.php"><i class="fas fa-gas-pump"></i><span>Fuel settings</span></a>
                <a class="quick-link" href="out.php"><i class="fas fa-box"></i><span>All orders</span></a>
            </div></div>
        </article>
    </section>
</main>
</div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const map=L.map('partner-live-map',{zoomControl:true,preferCanvas:true}).setView([6.5244,3.3792],11);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);
const riderLayers=new Map();
let initialFit=true;
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function icon(html,className,size,anchor){return L.divIcon({html,className:'',iconSize:[size,size],iconAnchor:[anchor,anchor],popupAnchor:[0,-anchor]});}
function freshnessClass(r){return r.location_fresh?'freshness live':'freshness';}
function focusRider(id){const layer=riderLayers.get(String(id));if(layer){map.flyTo(layer.getLatLng(),17,{duration:.6});layer.openPopup();}}
function clearMap(){for(const layer of riderLayers.values())map.removeLayer(layer);riderLayers.clear();document.querySelectorAll('.ridge-destination-layer').forEach(()=>{});}
async function loadLive(){
 try{
  const response=await fetch('live_data.php',{cache:'no-store',credentials:'same-origin'});
  const data=await response.json();
  if(!response.ok||!data.ok)throw new Error(data.error||'Could not load');
  for(const layer of riderLayers.values())map.removeLayer(layer);riderLayers.clear();
  const list=document.getElementById('live-rider-list');list.innerHTML='';
  const bounds=[];let visible=0;
  for(const r of data.riders){
    const lat=Number(r.last_lat),lng=Number(r.last_lng);const has=Number.isFinite(lat)&&Number.isFinite(lng)&&lat!==0&&lng!==0;
    if(has){
      visible++;bounds.push([lat,lng]);
      const marker=L.marker([lat,lng],{icon:icon('<div class="live-rider-pin"><i class="fas fa-motorcycle"></i></div>','',34,17),zIndexOffset:900}).addTo(map);
      marker.bindPopup(`<strong>${esc(r.rider_name)}</strong><br>${esc(r.bike_plate||'No bike plate')}<br>${r.tracking_id?`<span>${esc(r.tracking_id)} · ${esc(r.recipient_name||'')}</span><br>`:''}<small>${esc(r.location_label||'')}</small>`);
      riderLayers.set(String(r.rider_id),marker);
      const dlat=Number(r.recipient_lat),dlng=Number(r.recipient_lng);
      if(Number.isFinite(dlat)&&Number.isFinite(dlng)&&dlat!==0&&dlng!==0){
        const dest=L.marker([dlat,dlng],{icon:icon('<div class="destination-pin"><i class="fas fa-map-marker-alt"></i></div>','',27,13)}).addTo(map).bindPopup(`<strong>Destination</strong><br>${esc(r.recipient_name||'')}`);
        const line=L.polyline([[lat,lng],[dlat,dlng]],{color:'#e8500a',dashArray:'6 8',weight:2,opacity:.55}).addTo(map);
        riderLayers.set('dest-'+r.rider_id,dest);riderLayers.set('line-'+r.rider_id,line);bounds.push([dlat,dlng]);
      }
    }
    const row=document.createElement('div');row.className='live-row';row.onclick=()=>focusRider(r.rider_id);
    row.innerHTML=`<span class="rider-icon"><i class="fas fa-motorcycle"></i></span><span><strong>${esc(r.rider_name)}</strong><small>${r.tracking_id?`${esc(r.tracking_id)} · ${esc(r.recipient_name||'Active job')}`:'No active delivery'}${!has?' · Location not shared':''}</small></span><span class="${freshnessClass(r)}">${esc(r.location_label||'No location')}</span>`;
    list.appendChild(row);
  }
  if(!data.riders.length)list.innerHTML='<div class="empty">No riders registered for this partner.</div>';
  document.getElementById('rider-count').textContent=`${visible} sharing`;
  document.getElementById('sync-label').textContent=`Live · ${new Date(data.updated_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'})}`;
  if(initialFit&&bounds.length){map.fitBounds(bounds,{padding:[40,40],maxZoom:15});initialFit=false;}
  setTimeout(()=>map.invalidateSize(),50);
 }catch(error){document.getElementById('sync-label').textContent='Retrying live data';}
}
loadLive();setInterval(loadLive,10000);window.addEventListener('resize',()=>map.invalidateSize());
</script>
</body>
</html>
