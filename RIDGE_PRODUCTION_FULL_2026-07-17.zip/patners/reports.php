<?php
require_once '../includes/bootstrap.php';
if (!isset($_SESSION['partner_id'])) {
    ridge_redirect('index.php');
}

$partnerId=(int)$_SESSION['partner_id'];
$today=date('Y-m-d');
$start=(string)($_GET['start']??date('Y-m-d',strtotime('-29 days')));
$end=(string)($_GET['end']??$today);
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$start)) $start=date('Y-m-d',strtotime('-29 days'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$end)) $end=$today;
if (strtotime($start)>strtotime($end)) [$start,$end]=[$end,$start];

$metric=$conn->prepare("SELECT
 COUNT(*) total,
 COALESCE(SUM(d.status='pending'),0) pending,
 COALESCE(SUM(d.status IN ('assigned','enroute')),0) active,
 COALESCE(SUM(d.status='delivered'),0) delivered,
 COALESCE(SUM(d.status='returned'),0) returned,
 COALESCE(SUM(d.return_count),0) return_attempts,
 COALESCE(SUM(d.status='cancelled'),0) cancelled,
 COALESCE(SUM(d.status='delivered' AND DATE(COALESCE(d.delivered_at,d.updated_at,d.created_at))<=d.delivery_date),0) on_time,
 COALESCE(AVG(CASE WHEN d.status='delivered' THEN TIMESTAMPDIFF(MINUTE,d.created_at,COALESCE(d.delivered_at,d.updated_at))/60 END),0) avg_hours,
 COALESCE(SUM(d.route_distance_km),0) route_km,
 COALESCE(SUM(GREATEST(COALESCE(d.route_baseline_km,0)-COALESCE(d.route_distance_km,0),0)),0) saved_km
 FROM deliveries d WHERE d.partner_id=? AND DATE(d.created_at) BETWEEN ? AND ?");
$metric->bind_param('iss',$partnerId,$start,$end);$metric->execute();$stats=$metric->get_result()->fetch_assoc();
$delivered=(int)($stats['delivered']??0);
$onTimeRate=$delivered>0?round(((int)$stats['on_time']/$delivered)*100,1):0;
$fuelSettings=ridge_partner_fuel_settings($conn,$partnerId);
$routeSavings=ridge_route_savings(
    (float)$stats['route_km'],
    (float)$stats['route_km']+(float)$stats['saved_km'],
    (float)$fuelSettings['fuel_price_per_litre'],
    (float)$fuelSettings['fuel_efficiency_km_per_litre']
);

$riderStmt=$conn->prepare("SELECT r.id,r.rider_name,r.bike_plate,
 COUNT(d.id) assigned,
 COALESCE(SUM(d.status='delivered'),0) delivered,
 COALESCE(SUM(d.status IN ('assigned','enroute')),0) active,
 COALESCE(SUM(d.status='cancelled'),0) cancelled,
 COALESCE(SUM(d.status='delivered' AND DATE(COALESCE(d.delivered_at,d.updated_at,d.created_at))<=d.delivery_date),0) on_time,
 COALESCE(AVG(CASE WHEN d.status='delivered' THEN TIMESTAMPDIFF(MINUTE,d.created_at,COALESCE(d.delivered_at,d.updated_at))/60 END),0) avg_hours,
 COALESCE(SUM(d.route_distance_km),0) route_km,
 COALESCE(SUM(GREATEST(COALESCE(d.route_baseline_km,0)-COALESCE(d.route_distance_km,0),0)),0) saved_km
 FROM riders r LEFT JOIN deliveries d ON d.rider_id=r.id AND DATE(d.created_at) BETWEEN ? AND ?
 WHERE r.partner_id=? GROUP BY r.id,r.rider_name,r.bike_plate ORDER BY delivered DESC,assigned DESC,r.rider_name");
$riderStmt->bind_param('ssi',$start,$end,$partnerId);$riderStmt->execute();$riderResult=$riderStmt->get_result();$riderRows=[];while($row=$riderResult->fetch_assoc())$riderRows[]=$row;

if (($_GET['export']??'')==='csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="ridge-rider-report-'.$start.'-to-'.$end.'.csv"');
    $out=fopen('php://output','w');
    fputcsv($out,['Rider','Bike plate','Assigned','Delivered','Active','Cancelled','Completion rate','On-time rate','Average hours','Route km','Distance saved km','Fuel saved L','Money saved NGN']);
    foreach($riderRows as $r){
        $assigned=(int)$r['assigned'];$done=(int)$r['delivered'];
        $saving=ridge_route_savings((float)$r['route_km'],(float)$r['route_km']+(float)$r['saved_km'],(float)$fuelSettings['fuel_price_per_litre'],(float)$fuelSettings['fuel_efficiency_km_per_litre']);
        fputcsv($out,[$r['rider_name'],$r['bike_plate'],$assigned,$done,$r['active'],$r['cancelled'],$assigned?round($done/$assigned*100,1).'%':'0%',$done?round((int)$r['on_time']/$done*100,1).'%':'0%',round((float)$r['avg_hours'],1),round((float)$r['route_km'],1),round($saving['saved_km'],1),round($saving['saved_litres'],2),round($saving['saved_cost'],2)]);
    }
    fclose($out);exit;
}

$trendStmt=$conn->prepare("SELECT DATE(created_at) day,COUNT(*) total,COALESCE(SUM(status='delivered'),0) delivered,COALESCE(SUM(status='cancelled'),0) cancelled FROM deliveries WHERE partner_id=? AND DATE(created_at) BETWEEN ? AND ? GROUP BY DATE(created_at) ORDER BY day");
$trendStmt->bind_param('iss',$partnerId,$start,$end);$trendStmt->execute();$trend=[];$trendRes=$trendStmt->get_result();while($row=$trendRes->fetch_assoc())$trend[]=$row;
$statusStmt=$conn->prepare("SELECT status,COUNT(*) count FROM deliveries WHERE partner_id=? AND DATE(created_at) BETWEEN ? AND ? GROUP BY status");
$statusStmt->bind_param('iss',$partnerId,$start,$end);$statusStmt->execute();$statusData=[];$sr=$statusStmt->get_result();while($row=$sr->fetch_assoc())$statusData[$row['status']] = (int)$row['count'];
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Performance Reports — RIDGE</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/fontawesome.css"><link rel="stylesheet" href="../assets/portal.css"><script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<style>.filter{display:flex;align-items:end;gap:.7rem;flex-wrap:wrap;margin:1rem 0 1.3rem}.filter .field{min-width:170px}.analytics{display:grid;grid-template-columns:1.45fr .55fr;gap:1rem;margin-bottom:1rem}.chart-card{height:350px}.chart-card canvas{max-height:280px}.kpi-note{font-size:.7rem;color:var(--muted);line-height:1.5;margin-top:.4rem}.cost-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:.7rem}@media(max-width:900px){.analytics{grid-template-columns:1fr}.chart-card{height:auto}.cost-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:560px){.filter .field{min-width:100%;width:100%}.cost-grid{grid-template-columns:1fr 1fr}}</style></head><body>
<div class="partner-shell"><aside class="partner-sidebar"><a class="brand" href="dashboard.php">RIDGE<span>.</span></a><nav class="partner-nav"><a href="dashboard.php"><i class="fas fa-home"></i>Dashboard</a><a href="manage_riders.php"><i class="fas fa-motorcycle"></i>Manage riders</a><a href="dispatch.php"><i class="fas fa-paper-plane"></i>Dispatch orders</a><a href="mapped_delivery.php"><i class="fas fa-map-marked-alt"></i>Mapped delivery</a><a href="enroute.php"><i class="fas fa-satellite-dish"></i>Live enroute</a><a href="out.php"><i class="fas fa-box"></i>Dispatched orders</a><a class="active" href="reports.php"><i class="fas fa-chart-bar"></i>Reports</a><a href="settings.php"><i class="fas fa-cog"></i>Fleet settings</a></nav><div class="partner-sidebar-footer"><a class="btn btn-ghost" style="width:100%" href="index.php?logout=1"><i class="fas fa-sign-out-alt"></i> Logout</a></div></aside>
<main class="partner-main"><header class="partner-header"><div><div class="eyebrow">Operations intelligence</div><h1>Performance Reports</h1><p class="lead" style="margin-bottom:0">Measure delivery volume, on-time performance, route distance, fuel consumption and monetary savings.</p></div><div class="partner-header-meta"><a class="btn btn-ghost btn-sm" href="settings.php"><i class="fas fa-gas-pump"></i> Fuel settings</a></div></header>
<form class="filter" method="get"><div class="field"><label>Start date</label><input type="date" name="start" value="<?=h($start)?>" max="<?=h($today)?>"></div><div class="field"><label>End date</label><input type="date" name="end" value="<?=h($end)?>" max="<?=h($today)?>"></div><button class="btn btn-primary"><i class="fas fa-search"></i> Apply period</button><a class="btn btn-ghost" href="?start=<?=h($start)?>&end=<?=h($end)?>&export=csv"><i class="fas fa-download"></i> Export CSV</a></form>
<section class="clean-stats"><article class="clean-stat"><span class="stat-icon"><i class="fas fa-box"></i></span><small>Total orders</small><strong><?=(int)$stats['total']?></strong><p><?=h(date('d M',strtotime($start)))?> to <?=h(date('d M Y',strtotime($end)))?></p></article><article class="clean-stat"><span class="stat-icon"><i class="fas fa-check-circle"></i></span><small>Delivered</small><strong class="metric-green"><?=$delivered?></strong><p><?=(int)$stats['active']?> currently active</p></article><article class="clean-stat"><span class="stat-icon"><i class="fas fa-stopwatch"></i></span><small>On-time rate</small><strong class="metric-accent"><?=$onTimeRate?><span style="font-size:1rem">%</span></strong><p><?=(int)$stats['on_time']?> completed on schedule</p></article><article class="clean-stat"><span class="stat-icon"><i class="fas fa-gas-pump"></i></span><small>Fuel saved</small><strong><?=number_format($routeSavings['saved_litres'],1)?><span style="font-size:1rem"> L</span></strong><p><?=number_format($routeSavings['saved_km'],1)?> route km avoided</p></article><article class="clean-stat"><span class="stat-icon"><i class="fas fa-coins"></i></span><small>Money saved</small><strong><?=ridge_format_naira($routeSavings['saved_cost'])?></strong><p><?= $fuelSettings['fuel_price_per_litre']>0 ? ridge_format_naira($fuelSettings['fuel_price_per_litre'],2).'/L at '.number_format($fuelSettings['fuel_efficiency_km_per_litre'],1).' km/L' : 'Set a fuel price for monetary estimates' ?></p></article></section>
<div class="analytics"><section class="card chart-card"><div class="card-head"><h2>Delivery trend</h2><span class="pill delivered"><?=count($trend)?> active days</span></div><div class="card-body"><canvas id="trendChart"></canvas></div></section><section class="card chart-card"><div class="card-head"><h2>Status mix</h2></div><div class="card-body"><canvas id="statusChart"></canvas></div></section></div>
<section class="card" style="margin-bottom:1rem"><div class="card-head"><h2>Route cost comparison</h2></div><div class="card-body"><div class="cost-grid"><div class="detail"><small>Optimised route distance</small><strong><?=number_format($routeSavings['route_km'],1)?> km</strong></div><div class="detail"><small>Other-route distance</small><strong><?=number_format($routeSavings['baseline_km'],1)?> km</strong></div><div class="detail"><small>Optimised fuel cost</small><strong><?=ridge_format_naira($routeSavings['optimal_cost'])?></strong></div><div class="detail"><small>Other-route fuel cost</small><strong><?=ridge_format_naira($routeSavings['baseline_cost'])?></strong></div></div><p class="footer-note">RIDGE uses the shortest returned road route as the optimised route and the longer returned alternative as the comparison route. When the routing provider returns only one route, the configured baseline multiplier is used as an estimate.</p></div></section>
<section class="card" style="margin-bottom:1rem"><div class="card-head"><h2>Operational summary</h2></div><div class="card-body"><div class="detail-grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))"><div class="detail"><small>Awaiting assignment</small><strong><?=(int)$stats['pending']?></strong></div><div class="detail"><small>Returned queue</small><strong class="metric-red"><?=(int)$stats['returned']?></strong></div><div class="detail"><small>Return attempts</small><strong><?=(int)$stats['return_attempts']?></strong></div><div class="detail"><small>Cancelled</small><strong><?=(int)$stats['cancelled']?></strong></div><div class="detail"><small>Average completion</small><strong><?=round((float)$stats['avg_hours'],1)?> hours</strong></div></div></div></section>
<section class="card"><div class="card-head"><h2>Rider performance</h2><span class="soft-chip"><i class="fas fa-users"></i><?=count($riderRows)?> riders</span></div><?php if($riderRows):?><div class="table-wrap"><table><thead><tr><th>Rider</th><th>Plate</th><th>Assigned</th><th>Delivered</th><th>Completion</th><th>On-time</th><th>Route km</th><th>Fuel saved</th></tr></thead><tbody><?php foreach($riderRows as $r):$assigned=(int)$r['assigned'];$done=(int)$r['delivered'];$completion=$assigned?round($done/$assigned*100,1):0;$onTime=$done?round((int)$r['on_time']/$done*100,1):0;$saving=ridge_route_savings((float)$r['route_km'],(float)$r['route_km']+(float)$r['saved_km'],(float)$fuelSettings['fuel_price_per_litre'],(float)$fuelSettings['fuel_efficiency_km_per_litre']);?><tr><td><strong><?=h($r['rider_name'])?></strong></td><td><?=h($r['bike_plate']?:'—')?></td><td><?=$assigned?></td><td><?=$done?></td><td><span class="pill <?=$completion>=80?'delivered':($completion>=50?'assigned':'pending')?>"><?=$completion?>%</span></td><td><?=$onTime?>%</td><td><?=number_format((float)$r['route_km'],1)?></td><td><?=number_format($saving['saved_litres'],2)?> L<?php if($fuelSettings['fuel_price_per_litre']>0):?><br><small><?=ridge_format_naira($saving['saved_cost'])?></small><?php endif;?></td></tr><?php endforeach;?></tbody></table></div><?php else:?><div class="empty">No riders or deliveries fall inside this period.</div><?php endif;?></section>
</main></div>
<script>Chart.defaults.color='#8a877f';Chart.defaults.borderColor='rgba(245,242,235,.08)';new Chart(document.getElementById('trendChart'),{type:'line',data:{labels:<?=json_encode(array_column($trend,'day'))?>,datasets:[{label:'Orders',data:<?=json_encode(array_map('intval',array_column($trend,'total')))?>,tension:.35,fill:false,borderColor:'#e8500a',backgroundColor:'rgba(232,80,10,.12)'},{label:'Delivered',data:<?=json_encode(array_map('intval',array_column($trend,'delivered')))?>,tension:.35,fill:false,borderColor:'#1d9e75',backgroundColor:'rgba(29,158,117,.12)'}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom'}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});new Chart(document.getElementById('statusChart'),{type:'doughnut',data:{labels:['Pending','Assigned','En route','Returned','Delivered','Cancelled'],datasets:[{data:<?=json_encode([(int)($statusData['pending']??0),(int)($statusData['assigned']??0),(int)($statusData['enroute']??0),(int)($statusData['returned']??0),(int)($statusData['delivered']??0),(int)($statusData['cancelled']??0)])?>,backgroundColor:['#d9860a','#648fff','#e8500a','#d45555','#1d9e75','#6b6860'],borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,cutout:'68%',plugins:{legend:{position:'bottom'}}}});</script></body></html>
