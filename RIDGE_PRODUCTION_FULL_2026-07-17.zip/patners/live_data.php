<?php
require_once '../includes/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

if (!isset($_SESSION['partner_id'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Authentication required']);
    exit;
}

$partnerId = (int) $_SESSION['partner_id'];

$sql = "SELECT
            r.id AS rider_id,
            r.rider_name,
            r.bike_plate,
            r.phone AS rider_phone,
            r.status AS rider_status,
            r.last_lat,
            r.last_lng,
            r.last_location_at,
            r.last_accuracy_m,
            r.last_heading,
            r.last_speed_kmh,
            d.id AS delivery_id,
            d.tracking_id,
            d.recipient_name,
            d.recipient_address,
            d.status AS delivery_status,
            d.recipient_lat,
            d.recipient_lng,
            d.delivery_date,
            d.route_distance_km,
            d.route_baseline_km
        FROM riders r
        LEFT JOIN deliveries d ON d.id = (
            SELECT d2.id
            FROM deliveries d2
            WHERE d2.rider_id = r.id
              AND d2.partner_id = r.partner_id
              AND d2.status IN ('enroute','assigned')
            ORDER BY FIELD(d2.status,'enroute','assigned'), d2.created_at ASC
            LIMIT 1
        )
        WHERE r.partner_id = ?
        ORDER BY
            (r.last_location_at IS NULL),
            FIELD(COALESCE(d.status,''),'enroute','assigned',''),
            r.last_location_at DESC,
            r.rider_name ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $partnerId);
$stmt->execute();
$result = $stmt->get_result();
$rows = [];
$now = time();

while ($row = $result->fetch_assoc()) {
    $lastTimestamp = !empty($row['last_location_at']) ? strtotime((string) $row['last_location_at']) : false;
    $ageSeconds = $lastTimestamp ? max(0, $now - $lastTimestamp) : null;
    $row['location_age_seconds'] = $ageSeconds;
    $row['location_fresh'] = $ageSeconds !== null && $ageSeconds <= 90;
    $row['location_label'] = ridge_location_age_label($row['last_location_at'] ?: null);
    $rows[] = $row;
}

echo json_encode([
    'ok' => true,
    'updated_at' => date(DATE_ATOM),
    'riders' => $rows,
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
