# RIDGE Return-to-Last-Mile Upgrade

## What was added

1. A rider can open an assigned or en-route delivery and choose **Return to Last Mile**.
2. The rider must select a return reason. Additional details are optional, except when **Other reason** is selected.
3. The item is removed from the rider's active list and moved into the partner's **Returned to Last Mile** queue.
4. The sender receives an SMS containing the tracking ID, return reason, optional details, and tracking link.
5. The partner can select one or more returned items and reassign them to an active rider for another delivery attempt.
6. Each return and reassignment is written to the delivery event timeline.
7. Sender tracking, public tracking, partner reports, dispatched orders, partner dashboard, and admin views show the returned status.

## Deployment order

1. Back up the website files and database.
2. Run `database/migrations/2026_07_16_return_to_last_mile.sql` in phpMyAdmin.
3. Upload the supplied files while preserving their directories.
4. Confirm `config.local.php` remains in the website root. Do not overwrite or delete it.
5. Test the workflow below.

## Required production test

1. Create or use a pending delivery.
2. Assign it to a rider.
3. Log in as that rider and open the delivery.
4. Select **Return to Last Mile**, choose a reason, and submit.
5. Confirm the delivery disappears from the rider's active list.
6. Confirm the item appears under Partner > Dispatch Orders > Returned to Last Mile.
7. Confirm the sender receives the return reason by SMS, or that a logged notification appears when SMS credentials are not configured.
8. Reassign the returned item to an active rider.
9. Confirm the item returns to `assigned`, appears for the new rider, and the timeline records the new attempt.

## Database fields added

- `return_reason`
- `return_notes`
- `returned_at`
- `returned_by_rider_id`
- `return_count`
- `assignment_count`
- `last_reassigned_at`

The delivery status enum now includes `returned`.
