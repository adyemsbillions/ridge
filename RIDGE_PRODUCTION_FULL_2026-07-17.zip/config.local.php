<?php

return [
    'db_host' => 'localhost',
    'db_name' => 'craviing_ridge',
    'db_user' => 'craviing_adyems',
    'db_password' => '#adyems123AD',

    'base_url' => 'https://ridge.cravii.ng',

    'sms_username' => 'adyemsgodlove@gmail.com',
    'sms_api_key' => '36ada7944066623a456b981312c7e0dfcb08c20de819e2f1338c286baea1879a',
    'sms_sender' => 'RIDGE',

    'smtp_host' => 'mail.cravii.ng',
    'smtp_username' => 'adyems@cravii.ng',
    'smtp_password' => '#adyems123AD',
    'smtp_port' => 465,
    'smtp_encryption' => 'ssl',

    'email_from' => 'info@cravii.ng',
    'email_from_name' => 'RIDGE Dispatch',

    'fuel_efficiency_km_per_litre' => 35,
    'route_baseline_multiplier' => 1.15,
];