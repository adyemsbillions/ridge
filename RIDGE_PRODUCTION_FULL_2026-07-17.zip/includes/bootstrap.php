<?php
// RIDGE runtime error logging. The .htaccess rule blocks public access to *.log files.
ini_set('log_errors', '1');
ini_set('error_log', dirname(__DIR__) . '/ridge-errors.log');
error_reporting(E_ALL);

register_shutdown_function(function (): void {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        error_log('RIDGE fatal error: ' . $error['message'] . ' in ' . $error['file'] . ':' . $error['line']);
    }
});

if (defined('RIDGE_BOOTSTRAPPED')) {
    return;
}
define('RIDGE_BOOTSTRAPPED', true);

date_default_timezone_set('Africa/Lagos');

if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

require_once dirname(__DIR__) . '/db.php';
$RIDGE_CONFIG = require __DIR__ . '/config.php';

function ridge_config(string $key, mixed $default = null): mixed
{
    global $RIDGE_CONFIG;
    return $RIDGE_CONFIG[$key] ?? $default;
}

function h(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function ridge_redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function ridge_csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function ridge_csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . h(ridge_csrf_token()) . '">';
}

function ridge_verify_csrf(): bool
{
    $given = $_POST['csrf_token'] ?? '';
    return is_string($given) && hash_equals(ridge_csrf_token(), $given);
}

function ridge_require_csrf(): void
{
    if (!ridge_verify_csrf()) {
        http_response_code(419);
        exit('Your session expired. Refresh the page and try again.');
    }
}

function ridge_base_url(): string
{
    $configured = rtrim((string) ridge_config('base_url', ''), '/');
    if ($configured !== '') {
        return $configured;
    }
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return $scheme . '://' . $host;
}

function ridge_url(string $path = ''): string
{
    return ridge_base_url() . '/' . ltrim($path, '/');
}

function ridge_tracking_id(): string
{
    return 'RD-' . strtoupper(bin2hex(random_bytes(4)));
}

function ridge_public_token(): string
{
    return bin2hex(random_bytes(16));
}

function ridge_normalize_phone(string $phone): string
{
    $phone = preg_replace('/\D+/', '', $phone) ?? '';
    if (str_starts_with($phone, '0')) {
        return '234' . substr($phone, 1);
    }
    if (!str_starts_with($phone, '234') && $phone !== '') {
        return '234' . ltrim($phone, '0');
    }
    return $phone;
}

function ridge_mask_phone(string $phone): string
{
    $digits = ridge_normalize_phone($phone);
    if (strlen($digits) < 7) {
        return $digits;
    }
    return substr($digits, 0, 4) . '••••' . substr($digits, -3);
}


function ridge_format_naira(float $amount, int $decimals = 0): string
{
    return '₦' . number_format(max(0, $amount), $decimals);
}

function ridge_partner_fuel_settings(mysqli $conn, int $partnerId): array
{
    $defaults = [
        'fuel_price_per_litre' => 0.0,
        'fuel_efficiency_km_per_litre' => max(1.0, (float) ridge_config('fuel_efficiency_km_per_litre', 35)),
    ];
    if ($partnerId < 1 || !ridge_table_exists($conn, 'partners')) {
        return $defaults;
    }

    $columns = [];
    foreach (['fuel_price_per_litre', 'fuel_efficiency_km_per_litre'] as $column) {
        if (ridge_column_exists($conn, 'partners', $column)) {
            $columns[] = $column;
        }
    }
    if (!$columns) {
        return $defaults;
    }

    $stmt = $conn->prepare('SELECT ' . implode(',', $columns) . ' FROM partners WHERE id=? LIMIT 1');
    $stmt->bind_param('i', $partnerId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc() ?: [];
    return [
        'fuel_price_per_litre' => max(0.0, (float) ($row['fuel_price_per_litre'] ?? 0)),
        'fuel_efficiency_km_per_litre' => max(1.0, (float) ($row['fuel_efficiency_km_per_litre'] ?? $defaults['fuel_efficiency_km_per_litre'])),
    ];
}

function ridge_route_savings(
    float $routeKm,
    float $baselineKm,
    float $fuelPrice,
    float $efficiencyKmPerLitre
): array {
    $routeKm = max(0.0, $routeKm);
    $baselineKm = max($routeKm, $baselineKm);
    $efficiencyKmPerLitre = max(1.0, $efficiencyKmPerLitre);
    $fuelPrice = max(0.0, $fuelPrice);

    $savedKm = max(0.0, $baselineKm - $routeKm);
    $optimalLitres = $routeKm / $efficiencyKmPerLitre;
    $baselineLitres = $baselineKm / $efficiencyKmPerLitre;
    $savedLitres = $savedKm / $efficiencyKmPerLitre;

    return [
        'route_km' => $routeKm,
        'baseline_km' => $baselineKm,
        'saved_km' => $savedKm,
        'optimal_litres' => $optimalLitres,
        'baseline_litres' => $baselineLitres,
        'saved_litres' => $savedLitres,
        'optimal_cost' => $optimalLitres * $fuelPrice,
        'baseline_cost' => $baselineLitres * $fuelPrice,
        'saved_cost' => $savedLitres * $fuelPrice,
    ];
}

function ridge_location_age_label(?string $dateTime): string
{
    if (!$dateTime) {
        return 'No location yet';
    }
    $timestamp = strtotime($dateTime);
    if (!$timestamp) {
        return 'Location time unavailable';
    }
    $seconds = max(0, time() - $timestamp);
    if ($seconds < 15) {
        return 'Live now';
    }
    if ($seconds < 60) {
        return $seconds . ' sec ago';
    }
    if ($seconds < 3600) {
        return floor($seconds / 60) . ' min ago';
    }
    if ($seconds < 86400) {
        return floor($seconds / 3600) . ' hr ago';
    }
    return date('d M, H:i', $timestamp);
}

function ridge_table_exists(mysqli $conn, string $table): bool
{
    $stmt = $conn->prepare('SELECT COUNT(*) c FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?');
    $stmt->bind_param('s', $table);
    $stmt->execute();
    return (int) ($stmt->get_result()->fetch_assoc()['c'] ?? 0) > 0;
}

function ridge_column_exists(mysqli $conn, string $table, string $column): bool
{
    $stmt = $conn->prepare('SELECT COUNT(*) c FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?');
    $stmt->bind_param('ss', $table, $column);
    $stmt->execute();
    return (int) ($stmt->get_result()->fetch_assoc()['c'] ?? 0) > 0;
}

function ridge_index_exists(mysqli $conn, string $table, string $index): bool
{
    $stmt = $conn->prepare('SELECT COUNT(*) c FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?');
    $stmt->bind_param('ss', $table, $index);
    $stmt->execute();
    return (int) ($stmt->get_result()->fetch_assoc()['c'] ?? 0) > 0;
}

function ridge_ensure_schema(mysqli $conn): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $conn->query("CREATE TABLE IF NOT EXISTS senders (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        full_name VARCHAR(120) NOT NULL,
        phone VARCHAR(30) NOT NULL,
        email VARCHAR(160) NOT NULL,
        address TEXT NULL,
        password VARCHAR(255) NOT NULL,
        status ENUM('active','inactive') NOT NULL DEFAULT 'active',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_senders_email (email),
        UNIQUE KEY uq_senders_phone (phone)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $conn->query("CREATE TABLE IF NOT EXISTS delivery_events (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        delivery_id INT NOT NULL,
        status VARCHAR(30) NOT NULL,
        title VARCHAR(160) NOT NULL,
        description TEXT NULL,
        actor_type VARCHAR(30) NULL,
        actor_id INT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_delivery_events_delivery (delivery_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $conn->query("CREATE TABLE IF NOT EXISTS notification_logs (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        delivery_id INT NULL,
        channel VARCHAR(20) NOT NULL DEFAULT 'sms',
        recipient VARCHAR(40) NOT NULL,
        event_key VARCHAR(120) NOT NULL,
        message TEXT NOT NULL,
        status VARCHAR(20) NOT NULL,
        provider_response TEXT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_notification_once (delivery_id, event_key, recipient),
        KEY idx_notification_delivery (delivery_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if (ridge_table_exists($conn, 'partners')) {
        $partnerColumns = [
            'fuel_price_per_litre' => 'DECIMAL(10,2) NOT NULL DEFAULT 0',
            'fuel_efficiency_km_per_litre' => 'DECIMAL(8,2) NOT NULL DEFAULT 35',
        ];
        foreach ($partnerColumns as $name => $definition) {
            if (!ridge_column_exists($conn, 'partners', $name)) {
                $conn->query("ALTER TABLE partners ADD COLUMN {$name} {$definition}");
            }
        }
    }

    if (ridge_table_exists($conn, 'riders')) {
        $riderColumns = [
            'last_lat' => 'DECIMAL(10,7) NULL',
            'last_lng' => 'DECIMAL(10,7) NULL',
            'last_location_at' => 'DATETIME NULL',
            'last_accuracy_m' => 'DECIMAL(8,2) NULL',
            'last_heading' => 'DECIMAL(8,2) NULL',
            'last_speed_kmh' => 'DECIMAL(8,2) NULL',
            'location_delivery_id' => 'INT NULL',
        ];
        foreach ($riderColumns as $name => $definition) {
            if (!ridge_column_exists($conn, 'riders', $name)) {
                $conn->query("ALTER TABLE riders ADD COLUMN {$name} {$definition}");
            }
        }
        if (!ridge_index_exists($conn, 'riders', 'idx_riders_partner_location')) {
            $conn->query('ALTER TABLE riders ADD INDEX idx_riders_partner_location (partner_id, last_location_at)');
        }
    }

    if (!ridge_table_exists($conn, 'deliveries')) {
        return;
    }

    $columns = [
        'sender_id' => 'INT NULL',
        'public_token' => 'VARCHAR(64) NULL',
        'accepted_at' => 'DATETIME NULL',
        'enroute_at' => 'DATETIME NULL',
        'delivered_at' => 'DATETIME NULL',
        'cancelled_at' => 'DATETIME NULL',
        'route_distance_km' => 'DECIMAL(10,2) NULL',
        'route_baseline_km' => 'DECIMAL(10,2) NULL',
        'route_duration_min' => 'DECIMAL(10,2) NULL',
        'route_baseline_duration_min' => 'DECIMAL(10,2) NULL',
        'route_updated_at' => 'DATETIME NULL',
        'last_rider_lat' => 'DECIMAL(10,7) NULL',
        'last_rider_lng' => 'DECIMAL(10,7) NULL',
        'last_location_at' => 'DATETIME NULL',
        'delivery_otp' => 'VARCHAR(6) NULL',
        'otp_expires_at' => 'DATETIME NULL',
        'return_reason' => 'VARCHAR(80) NULL',
        'return_notes' => 'TEXT NULL',
        'returned_at' => 'DATETIME NULL',
        'returned_by_rider_id' => 'INT NULL',
        'return_count' => 'INT NOT NULL DEFAULT 0',
        'assignment_count' => 'INT NOT NULL DEFAULT 0',
        'last_reassigned_at' => 'DATETIME NULL',
        'updated_at' => 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
    ];

    foreach ($columns as $name => $definition) {
        if (!ridge_column_exists($conn, 'deliveries', $name)) {
            $conn->query("ALTER TABLE deliveries ADD COLUMN {$name} {$definition}");
        }
    }

    if (!ridge_index_exists($conn, 'deliveries', 'idx_deliveries_public_token')) {
        $conn->query('ALTER TABLE deliveries ADD INDEX idx_deliveries_public_token (public_token)');
    }
    if (!ridge_index_exists($conn, 'deliveries', 'idx_deliveries_sender')) {
        $conn->query('ALTER TABLE deliveries ADD INDEX idx_deliveries_sender (sender_id)');
    }
    if (!ridge_index_exists($conn, 'deliveries', 'idx_deliveries_return_queue')) {
        $conn->query('ALTER TABLE deliveries ADD INDEX idx_deliveries_return_queue (partner_id, status, returned_at)');
    }

    $statusTypeStmt = $conn->prepare("SELECT COLUMN_TYPE FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'deliveries' AND column_name = 'status' LIMIT 1");
    if ($statusTypeStmt && $statusTypeStmt->execute()) {
        $statusType = (string) ($statusTypeStmt->get_result()->fetch_assoc()['COLUMN_TYPE'] ?? '');
        if ($statusType !== '' && strpos($statusType, "'returned'") === false) {
            $conn->query("ALTER TABLE deliveries MODIFY status ENUM('pending','assigned','enroute','returned','delivered','cancelled') NOT NULL DEFAULT 'pending'");
        }
    }

    $result = $conn->query("SELECT id FROM deliveries WHERE public_token IS NULL OR public_token = '' LIMIT 500");
    if ($result) {
        $update = $conn->prepare('UPDATE deliveries SET public_token = ? WHERE id = ?');
        while ($row = $result->fetch_assoc()) {
            $token = ridge_public_token();
            $id = (int) $row['id'];
            $update->bind_param('si', $token, $id);
            $update->execute();
        }
    }
}

function ridge_record_event(
    mysqli $conn,
    int $deliveryId,
    string $status,
    string $title,
    string $description = '',
    ?string $actorType = null,
    ?int $actorId = null
): void {
    ridge_ensure_schema($conn);
    $stmt = $conn->prepare('INSERT INTO delivery_events (delivery_id, status, title, description, actor_type, actor_id) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->bind_param('issssi', $deliveryId, $status, $title, $description, $actorType, $actorId);
    $stmt->execute();
}

function ridge_return_reason_options(): array
{
    return [
        'recipient_unavailable' => 'Recipient unavailable',
        'recipient_refused' => 'Recipient refused the item',
        'recipient_unreachable' => 'Recipient phone unreachable',
        'incorrect_address' => 'Incorrect or incomplete address',
        'payment_issue' => 'Payment or collection issue',
        'damaged_package' => 'Package damaged or unsafe to deliver',
        'security_concern' => 'Safety or security concern',
        'other' => 'Other reason',
    ];
}

function ridge_return_reason_label(string $reason): string
{
    $options = ridge_return_reason_options();
    return $options[$reason] ?? ($reason !== '' ? $reason : 'Reason not specified');
}

function ridge_set_delivery_status(
    mysqli $conn,
    int $deliveryId,
    string $status,
    ?string $actorType = null,
    ?int $actorId = null,
    string $description = ''
): bool {
    ridge_ensure_schema($conn);
    $allowed = ['pending', 'assigned', 'enroute', 'returned', 'delivered', 'cancelled'];
    if (!in_array($status, $allowed, true)) {
        return false;
    }

    if ($status === 'returned') {
        $stmt = $conn->prepare("UPDATE deliveries SET
            returned_by_rider_id=COALESCE(returned_by_rider_id,rider_id),
            return_reason=COALESCE(NULLIF(return_reason,''),'other'),
            return_count=COALESCE(return_count,0)+IF(status='returned',0,1),
            returned_at=COALESCE(returned_at,NOW()), status='returned',
            rider_id=NULL, delivery_otp=NULL, otp_expires_at=NULL,
            last_rider_lat=NULL, last_rider_lng=NULL, last_location_at=NULL
            WHERE id=?");
        $stmt->bind_param('i', $deliveryId);
        $ok = $stmt->execute();
        if ($ok) {
            ridge_record_event($conn, $deliveryId, 'returned', 'Returned to last mile', $description, $actorType, $actorId);
        }
        return $ok;
    }

    $timestampColumn = match ($status) {
        'assigned' => 'accepted_at',
        'enroute' => 'enroute_at',
        'returned' => 'returned_at',
        'delivered' => 'delivered_at',
        'cancelled' => 'cancelled_at',
        default => null,
    };

    $sql = 'UPDATE deliveries SET status = ?';
    if ($timestampColumn !== null) {
        $sql .= ", {$timestampColumn} = COALESCE({$timestampColumn}, NOW())";
    }
    $sql .= ' WHERE id = ?';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('si', $status, $deliveryId);
    $ok = $stmt->execute();

    if ($ok) {
        $title = match ($status) {
            'pending' => 'Delivery request received',
            'assigned' => 'Rider assigned',
            'enroute' => 'Delivery is on the way',
            'returned' => 'Returned to last mile',
            'delivered' => 'Delivery completed',
            'cancelled' => 'Delivery cancelled',
        };
        ridge_record_event($conn, $deliveryId, $status, $title, $description, $actorType, $actorId);
    }
    return $ok;
}

function ridge_mark_delivery_returned(
    mysqli $conn,
    int $deliveryId,
    int $riderId,
    string $reason,
    string $notes = ''
): bool {
    ridge_ensure_schema($conn);
    $options = ridge_return_reason_options();
    if (!isset($options[$reason])) {
        return false;
    }

    $notes = trim($notes);
    if ($reason === 'other' && $notes === '') {
        return false;
    }
    if (strlen($notes) > 1000) {
        $notes = substr($notes, 0, 1000);
    }

    $stmt = $conn->prepare("UPDATE deliveries
        SET status='returned', return_reason=?, return_notes=?, returned_at=NOW(),
            returned_by_rider_id=?, return_count=COALESCE(return_count,0)+1,
            rider_id=NULL, delivery_otp=NULL, otp_expires_at=NULL,
            last_rider_lat=NULL, last_rider_lng=NULL, last_location_at=NULL
        WHERE id=? AND rider_id=? AND status IN ('assigned','enroute')");
    $stmt->bind_param('ssiii', $reason, $notes, $riderId, $deliveryId, $riderId);
    if (!$stmt->execute() || $stmt->affected_rows < 1) {
        return false;
    }

    $description = 'Reason: ' . ridge_return_reason_label($reason) . '.';
    if ($notes !== '') {
        $description .= ' Details: ' . $notes;
    }
    ridge_record_event($conn, $deliveryId, 'returned', 'Returned to last mile', $description, 'rider', $riderId);
    return true;
}

function ridge_delivery_status_label(string $status): string
{
    return match ($status) {
        'assigned' => 'Rider Assigned',
        'enroute' => 'En Route',
        'returned' => 'Returned to Last Mile',
        'delivered' => 'Delivered',
        'cancelled' => 'Cancelled',
        default => 'Pending',
    };
}

function ridge_status_rank(string $status): int
{
    return match ($status) {
        'pending' => 1,
        'assigned' => 2,
        'enroute' => 3,
        'returned' => 2,
        'delivered' => 4,
        'cancelled' => 0,
        default => 0,
    };
}

function ridge_delivery_events(mysqli $conn, int $deliveryId): array
{
    ridge_ensure_schema($conn);
    $stmt = $conn->prepare('SELECT status, title, description, created_at FROM delivery_events WHERE delivery_id = ? ORDER BY created_at ASC, id ASC');
    $stmt->bind_param('i', $deliveryId);
    $stmt->execute();
    $rows = [];
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    return $rows;
}

ridge_ensure_schema($conn);
