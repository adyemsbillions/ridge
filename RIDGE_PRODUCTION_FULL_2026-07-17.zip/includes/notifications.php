<?php
require_once __DIR__ . '/bootstrap.php';

function ridge_sms_send(string $phone, string $message): array
{
    $phone = ridge_normalize_phone($phone);
    $username = trim((string) ridge_config('sms_username', ''));
    $apiKey = trim((string) ridge_config('sms_api_key', ''));
    $sender = trim((string) ridge_config('sms_sender', 'RIDGE')) ?: 'RIDGE';

    if ($phone === '') {
        return ['ok' => false, 'status' => 'failed', 'response' => 'No valid phone number.'];
    }

    if ($username === '' || $apiKey === '') {
        return ['ok' => true, 'status' => 'logged', 'response' => 'SMS credentials are not configured; notification was logged only.'];
    }

    $payload = json_encode([
        'SMS' => [
            'auth' => ['username' => $username, 'apikey' => $apiKey],
            'message' => ['sender' => $sender, 'messagetext' => $message, 'flash' => '0'],
            'recipients' => ['gsm' => [[
                'msidn' => $phone,
                'msgid' => substr(uniqid('ridge_', true), 0, 30),
            ]]],
            'dndsender' => '1',
        ],
    ], JSON_UNESCAPED_SLASHES);

    $response = false;
    $error = '';
    if (function_exists('curl_init')) {
        $ch = curl_init('https://api.ebulksms.com/sendsms.json');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
        ]);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
    } elseif (filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOL)) {
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/json\r\n",
                'content' => $payload,
                'timeout' => 20,
                'ignore_errors' => true,
            ],
        ]);
        $response = @file_get_contents('https://api.ebulksms.com/sendsms.json', false, $context);
        if ($response === false) {
            $error = 'SMS provider request failed.';
        }
    } else {
        $error = 'Neither cURL nor allow_url_fopen is available for SMS delivery.';
    }

    if ($error !== '') {
        return ['ok' => false, 'status' => 'failed', 'response' => $error];
    }

    $data = json_decode((string) $response, true);
    $ok = (($data['response']['status'] ?? '') === 'SUCCESS');
    return [
        'ok' => $ok,
        'status' => $ok ? 'sent' : 'failed',
        'response' => $ok ? 'SUCCESS' : (string) ($data['response']['message'] ?? $response ?? 'Unknown response'),
    ];
}

function ridge_notify_once(
    mysqli $conn,
    ?int $deliveryId,
    string $eventKey,
    string $phone,
    string $message
): array {
    ridge_ensure_schema($conn);
    $normalized = ridge_normalize_phone($phone);

    $check = $conn->prepare('SELECT status, provider_response FROM notification_logs WHERE delivery_id <=> ? AND event_key = ? AND recipient = ? LIMIT 1');
    $check->bind_param('iss', $deliveryId, $eventKey, $normalized);
    $check->execute();
    $existing = $check->get_result()->fetch_assoc();
    if ($existing && in_array((string) $existing['status'], ['sent', 'logged'], true)) {
        return ['ok' => true, 'status' => 'duplicate', 'response' => $existing['provider_response'] ?? 'Already processed.'];
    }

    $result = ridge_sms_send($normalized, $message);
    $status = $result['status'];
    $response = $result['response'];
    $channel = 'sms';

    if ($existing) {
        $update = $conn->prepare('UPDATE notification_logs SET message=?, status=?, provider_response=?, created_at=NOW() WHERE delivery_id <=> ? AND event_key=? AND recipient=?');
        $update->bind_param('sssiss', $message, $status, $response, $deliveryId, $eventKey, $normalized);
        $update->execute();
    } else {
        $insert = $conn->prepare('INSERT INTO notification_logs (delivery_id, channel, recipient, event_key, message, status, provider_response) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $insert->bind_param('issssss', $deliveryId, $channel, $normalized, $eventKey, $message, $status, $response);
        $insert->execute();
    }

    return $result;
}

function ridge_tracking_link(array $delivery): string
{
    $trackingId = rawurlencode((string) $delivery['tracking_id']);
    $token = rawurlencode((string) ($delivery['public_token'] ?? ''));
    return ridge_url("track.php?tracking_id={$trackingId}&t={$token}");
}

function ridge_notify_delivery_status(mysqli $conn, array $delivery, string $status, string $riderName = ''): void
{
    $deliveryId = (int) $delivery['id'];
    $tracking = $delivery['tracking_id'];
    $link = ridge_tracking_link($delivery);
    $recipientName = trim((string) ($delivery['recipient_name'] ?? '')) ?: 'there';
    $senderName = trim((string) ($delivery['sender_name'] ?? '')) ?: 'there';

    if ($status === 'pending') {
        $message = "Hi {$recipientName}, a RIDGE delivery ({$tracking}) has been created for you. Track it here: {$link}";
        ridge_notify_once($conn, $deliveryId, 'recipient_pending', (string) $delivery['recipient_phone'], $message);
    } elseif ($status === 'assigned') {
        $riderText = $riderName !== '' ? " Rider: {$riderName}." : '';
        $attempt = max(1, (int) ($delivery['assignment_count'] ?? 1));
        $message = "Hi {$recipientName}, your RIDGE delivery {$tracking} has been assigned.{$riderText} Track: {$link}";
        ridge_notify_once($conn, $deliveryId, 'recipient_assigned_' . $attempt, (string) $delivery['recipient_phone'], $message);
    } elseif ($status === 'enroute') {
        $attempt = max(1, (int) ($delivery['assignment_count'] ?? 1));
        $message = "Hi {$recipientName}, your RIDGE delivery {$tracking} is now on the way. Keep your phone available. Live status: {$link}";
        ridge_notify_once($conn, $deliveryId, 'recipient_enroute_' . $attempt, (string) $delivery['recipient_phone'], $message);
    } elseif ($status === 'returned') {
        $returnNumber = max(1, (int) ($delivery['return_count'] ?? 1));
        $reason = ridge_return_reason_label((string) ($delivery['return_reason'] ?? ''));
        $notes = trim((string) ($delivery['return_notes'] ?? ''));
        $details = $notes !== '' ? ' Details: ' . substr($notes, 0, 120) . '.' : '';
        $message = "Hi {$senderName}, RIDGE delivery {$tracking} was returned to the last-mile hub. Reason: {$reason}.{$details} The partner will review it for reassignment. Track: {$link}";
        ridge_notify_once($conn, $deliveryId, 'sender_returned_' . $returnNumber, (string) $delivery['sender_phone'], $message);
    } elseif ($status === 'delivered') {
        $recipientMessage = "Your RIDGE delivery {$tracking} has been completed. Thank you for using RIDGE.";
        ridge_notify_once($conn, $deliveryId, 'recipient_delivered', (string) $delivery['recipient_phone'], $recipientMessage);

        $senderMessage = "Hi {$senderName}, your package {$tracking} has been delivered to {$recipientName}. View status: {$link}";
        ridge_notify_once($conn, $deliveryId, 'sender_delivered', (string) $delivery['sender_phone'], $senderMessage);
    } elseif ($status === 'cancelled') {
        $message = "Your RIDGE delivery {$tracking} has been cancelled. Please contact the dispatch partner for assistance.";
        ridge_notify_once($conn, $deliveryId, 'recipient_cancelled', (string) $delivery['recipient_phone'], $message);
    }
}
