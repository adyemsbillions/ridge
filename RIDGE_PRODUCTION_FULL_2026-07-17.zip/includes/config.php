<?php
/**
 * RIDGE application configuration.
 * Local secrets are loaded from config.local.php when present.
 */
$config = [
    'base_url' => getenv('RIDGE_BASE_URL') ?: '',
    'sms_username' => getenv('RIDGE_SMS_USERNAME') ?: '',
    'sms_api_key' => getenv('RIDGE_SMS_API_KEY') ?: '',
    'sms_sender' => getenv('RIDGE_SMS_SENDER') ?: 'RIDGE',
    'smtp_host' => getenv('RIDGE_SMTP_HOST') ?: '',
    'smtp_username' => getenv('RIDGE_SMTP_USERNAME') ?: '',
    'smtp_password' => getenv('RIDGE_SMTP_PASSWORD') ?: '',
    'smtp_port' => (int) (getenv('RIDGE_SMTP_PORT') ?: 465),
    'smtp_encryption' => getenv('RIDGE_SMTP_ENCRYPTION') ?: 'ssl',
    'email_from' => getenv('RIDGE_EMAIL_FROM') ?: '',
    'email_from_name' => getenv('RIDGE_EMAIL_FROM_NAME') ?: 'RIDGE Dispatch',
    'fuel_efficiency_km_per_litre' => (float) (getenv('RIDGE_FUEL_EFFICIENCY') ?: 35),
    'route_baseline_multiplier' => (float) (getenv('RIDGE_ROUTE_BASELINE_MULTIPLIER') ?: 1.15),
];

$localConfig = dirname(__DIR__) . '/config.local.php';
if (is_file($localConfig)) {
    $local = require $localConfig;
    if (is_array($local)) {
        $config = array_replace($config, $local);
    }
}

return $config;
