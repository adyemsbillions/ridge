# RIDGE Production Release — Routing, Live Tracking and UI Upgrade

Release date: 17 July 2026

## What changed

- Cleaned partner and rider interfaces and replaced decorative emoji/SVG navigation icons with Font Awesome icons.
- Added persistent rider GPS updates from the rider dashboard, delivery list and navigation screen.
- Rebuilt partner live maps to show all registered riders, current position freshness, active delivery destination and rider-to-destination line.
- Added close-range in-app rider navigation with a prominent current street/area, shortest available road route, alternatives, instructions, ETA and route overview.
- Redesigned the delivery OTP screen.
- Added partner-controlled fuel price and average bike fuel efficiency settings.
- Added route distance, other-route estimate, fuel litres and Naira savings to dashboard, reports and CSV export.
- Connected the public landing page to live database totals instead of demo numbers.
- Rebuilt PWA icons with safe padding, including separate standard, maskable and Apple touch icons.
- Secured the emergency admin recovery utility by disabling it by default.

## Deployment order

1. Back up the live website and database.
2. Select the RIDGE database in phpMyAdmin.
3. Run `database/migrations/2026_07_17_production_routing_live_tracking.sql`.
4. Upload the project files and preserve the existing `config.local.php` values.
5. Use PHP 8.1–8.3 with `mysqli`, HTTPS and outbound HTTPS access enabled.
6. Sign in as a partner and set fuel price and average bike efficiency under **Fleet Settings**.
7. On a rider phone, open RIDGE over HTTPS and allow **precise location**.
8. Keep the RIDGE rider screen active during a trip so the browser can continue sending positions.
9. Test the workflow below before accepting live deliveries.

## Required production test

1. Assign a delivery to a rider.
2. Rider signs in and allows precise location.
3. Partner opens Dashboard or Live Enroute and confirms the rider marker appears.
4. Rider walks or rides at least 20–50 metres and partner confirms the marker updates within about 10 seconds.
5. Rider opens navigation and confirms the nearby street map, destination, shortest available route, instructions and ETA appear.
6. Partner confirms route and fuel savings appear after a route is recorded.
7. Rider sends and verifies the delivery OTP.
8. Test one return-to-last-mile and reassignment flow.

## Important technical limits

RIDGE is an installable web app. Browser location tracking works while a RIDGE rider page is open and the browser permits location use. Reliable tracking after the app is force-closed or removed from memory requires a compiled native Android/iOS application with background-location permissions.

Route, map tile and reverse-geocoding displays require internet access to the configured external mapping services. Fuel and monetary figures are estimates based on route alternatives, partner fuel price and average motorcycle km/L; actual consumption varies with traffic, load, riding style and vehicle condition.

## Security

- Do not share `config.local.php`.
- Delete `ridge_diagnostic.php` from the live server after troubleshooting.
- `me/make_admin.php` is disabled by default. Enable it only temporarily, set a unique password, run it once, then disable or delete it.
- Keep `.htaccess`, `database/.htaccess` and `includes/.htaccess` in place.
