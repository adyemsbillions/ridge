<?php
require_once __DIR__ . '/includes/bootstrap.php';
$publicStats=['partners'=>0,'riders'=>0,'live_riders'=>0,'deliveries'=>0,'active'=>0,'delivered'=>0,'on_time'=>0,'route_km'=>0.0,'saved_km'=>0.0,'fuel_saved_pct'=>0.0];
try {
    if($r=$conn->query("SELECT COUNT(*) c FROM partners WHERE status='active'")) $publicStats['partners']=(int)$r->fetch_assoc()['c'];
    if($r=$conn->query("SELECT COUNT(*) riders,COALESCE(SUM(last_location_at>=DATE_SUB(NOW(),INTERVAL 15 MINUTE)),0) live_riders FROM riders WHERE status<>'inactive'")){ $x=$r->fetch_assoc();$publicStats['riders']=(int)$x['riders'];$publicStats['live_riders']=(int)$x['live_riders']; }
    if($r=$conn->query("SELECT COUNT(*) deliveries,COALESCE(SUM(status IN ('assigned','enroute')),0) active,COALESCE(SUM(status='delivered'),0) delivered,COALESCE(SUM(status='delivered' AND delivered_at IS NOT NULL AND DATE(delivered_at)<=delivery_date),0) on_time,COALESCE(SUM(route_distance_km),0) route_km,COALESCE(SUM(GREATEST(COALESCE(route_baseline_km,0)-COALESCE(route_distance_km,0),0)),0) saved_km,COALESCE(SUM(route_baseline_km),0) baseline_km FROM deliveries")){ $x=$r->fetch_assoc();foreach(['deliveries','active','delivered','on_time'] as $k)$publicStats[$k]=(int)$x[$k];$publicStats['route_km']=(float)$x['route_km'];$publicStats['saved_km']=(float)$x['saved_km'];$base=(float)$x['baseline_km'];$publicStats['fuel_saved_pct']=$base>0?($publicStats['saved_km']/$base*100):0; }
} catch(Throwable $e) { error_log('RIDGE landing stats: '.$e->getMessage()); }
$onTimePct=$publicStats['delivered']>0?round($publicStats['on_time']/$publicStats['delivered']*100):0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>RIDGE – Smarter Routes. Better Deliveries.</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/fontawesome.css">
<link rel="stylesheet" href="index.css">
</head>
<body>
<!-- NAV -->
<nav>
 <div class="nav-logo">RIDGE<span>.</span></div>
 <ul>
 <li><a href="#features">Features</a></li>
 <li><a href="track.php">Track Delivery</a></li>
 <li><a href="senders/index.php">Sender Portal</a></li>
 <li><a href="riders/index.php">Rider App</a></li>
 <li><a href="patners/index.php" class="nav-cta">Partner Login</a></li>
 </ul>
</nav>
<!-- HERO -->
<section class="hero">
 <div class="hero-grid-bg"></div>
 <div class="hero-left fade-up visible">
 <div class="hero-eyebrow">Built for Lagos. Built for Scale.</div>
 <h1>SMARTER<br>ROUTES.<br><em>BETTER</em><br>DELIVERIES.</h1>
 <p class="hero-sub">Route optimisation and fleet management for urban dispatch
fleets of 5–20 motorcycles. No complex setup. Just results.</p>
 <div class="hero-actions">
 <a href="senders/index.php" class="btn-primary">Send a Package</a>
 <a href="track.php" class="btn-ghost">Track a Delivery</a>
 </div>
 </div>
 <div class="hero-right fade-up visible" style="transition-delay:0.2s">
 <div class="hero-device">
 <div class="device-topbar">
 <div class="dot dot-r"></div>
 <div class="dot dot-y"></div>
 <div class="dot dot-g"></div>
 <span class="device-title">RIDGE DISPATCH — LIVE</span>
 </div>
 <div class="map-area">
 <div class="map-grid"></div>
 <svg class="route-svg" viewBox="0 0 400 220"
xmlns="http://www.w3.org/2000/svg">
 <path d="M 80 70 Q 140 30 210 80 T 340 60" stroke="#E8500A" stroke-width="1.5" fill="none" stroke-dasharray="4 3" opacity="0.7"/>
 <path d="M 80 70 Q 100 130 155 150 T 240 160" stroke="#1D9E75" stroke-width="1.5" fill="none" stroke-dasharray="4 3" opacity="0.7"/>
 <path d="M 240 160 Q 310 170 360 140" stroke="#1D9E75" stroke-width="1.5" fill="none" stroke-dasharray="4 3" opacity="0.5"/>
 </svg>
 <div class="rider-dot r1"></div>
 <div class="rider-dot r2"></div>
 <div class="rider-dot r3"></div>
 <div class="dest-dot" style="top:22%;left:52%"></div>
 <div class="dest-dot" style="top:68%;left:82%"></div>
 <div class="dest-dot" style="top:40%;left:75%"></div>
 </div>
 <div class="device-stats">
 <div class="device-stat">
 <div class="device-stat-val"><span><?=number_format($publicStats['live_riders'])?></span></div>
 <div class="device-stat-label">Active Riders</div>
 </div>
 <div class="device-stat">
 <div class="device-stat-val"><?=number_format($publicStats['fuel_saved_pct'],0)?><span>%</span></div>
 <div class="device-stat-label">Fuel Saved</div>
 </div>
 <div class="device-stat">
 <div class="device-stat-val"><?=number_format($onTimePct)?><span>%</span></div>
 <div class="device-stat-label">On-Time Rate</div>
 </div>
 </div>
 </div>
 </div>
</section>
<!-- STATS STRIP -->
<div class="stats-strip">
 <div class="stat-item fade-up">
 <div class="stat-num"><?=number_format($publicStats['deliveries'])?></div>
 <div class="stat-desc">Deliveries recorded on RIDGE</div>
 </div>
 <div class="stat-item fade-up">
 <div class="stat-num"><?=number_format($publicStats['active'])?></div>
 <div class="stat-desc">Deliveries currently active</div>
 </div>
 <div class="stat-item fade-up">
 <div class="stat-num"><?=number_format($publicStats['saved_km'],1)?><span>km</span></div>
 <div class="stat-desc">Route distance saved from recorded comparisons</div>
 </div>
 <div class="stat-item fade-up">
 <div class="stat-num"><?=number_format($publicStats['partners'])?></div>
 <div class="stat-desc">Active delivery partners</div>
 </div>
</div>
<!-- FEATURES -->
<section class="features" id="features">
 <div class="section-label">Core Features</div>
 <h2 class="section-h">Everything Your Dispatch<br>Team Needs</h2>
 <p class="section-sub">One lightweight platform replacing spreadsheets,
WhatsApp threads, and guesswork.</p>
 <div class="features-grid">
 <div class="feature-card fade-up">
 <div class="feat-icon"><i class="fas fa-route"></i></div>
 <h3>Route Optimisation</h3>
 <p>Compare available road routes and guide riders along the shortest available option, with distance and fuel-cost savings recorded for reporting.</p>
 </div>
 <div class="feature-card fade-up">
 <div class="feat-icon"><i class="fas fa-map-marker-alt"></i></div>
 <h3>Live Delivery Tracking</h3>
 <p>Monitor every rider in real time. Know exactly where each delivery is without
calling your team every five minutes.</p>
 </div>
 <div class="feature-card fade-up">
 <div class="feat-icon"><i class="fas fa-chart-bar"></i></div>
 <h3>Rider Performance</h3>
 <p>Track delivery times, completion rates, and fuel usage per rider. Reward your
best performers with data, not guesswork.</p>
 </div>
 <div class="feature-card fade-up">
 <div class="feat-icon"><i class="fas fa-satellite-dish"></i></div>
 <h3>Dispatch Management</h3>
 <p>Assign orders, manage capacity, and coordinate your fleet from a single web-based dashboard — from any device.</p>
 </div>
 <div class="feature-card fade-up">
 <div class="feat-icon"><i class="fas fa-mobile-alt"></i></div>
 <h3>Mobile-First Design</h3>
 <p>Designed for riders with smartphones. Lightweight, fast-loading, and works
on basic Android devices and data plans.</p>
 </div>
 <div class="feature-card fade-up">
 <div class="feat-icon"><i class="fas fa-bolt"></i></div>
 <h3>Zero Installation</h3>
 <p>Browser-based and cloud-hosted. Your team is operational the same day —
no IT department required.</p>
 </div>
 </div>
</section>
<!-- HOW IT WORKS -->
<section class="how" id="how">
 <div class="section-label">Process</div>
 <h2 class="section-h">Up and Running in 3 Steps</h2>
 <p class="section-sub">From zero to optimised deliveries in under an hour. No
training manuals. No long onboarding.</p>
 <div class="steps">
 <div class="step fade-up">
 <div class="step-num">01</div>
 <div>
 <h3>Add Your Riders & Orders</h3>
 <p>Input your riders' details and today's delivery orders. Import from a
spreadsheet or add them manually. Takes minutes.</p>
 </div>
 </div>
 <div class="step fade-up">
 <div class="step-num">02</div>
 <div>
 <h3>RIDGE Builds the Routes</h3>
 <p>The platform automatically assigns stops and calculates optimal routes
using destination coordinates, rider location, available road alternatives, and proximity.</p>
 </div>
 </div>
 <div class="step fade-up">
 <div class="step-num">03</div>
 <div>
 <h3>Dispatch & Monitor Live</h3>
 <p>Send route instructions to each rider's phone. Track deliveries in real time
and intervene instantly when plans change.</p>
 </div>
 </div>
 </div>
</section>
<!-- LIVE OPERATIONS -->
<section class="market" id="operations">
 <div class="market-inner">
  <div>
   <div class="section-label">Live Operations</div>
   <h2 class="section-h">Real Platform Data,<br>Not Demo Numbers</h2>
   <p class="section-sub">This public snapshot is calculated directly from the RIDGE operational database and updates whenever the page is loaded.</p>
   <div class="market-numbers">
    <div class="market-num"><span class="market-num-val"><?=number_format($publicStats['riders'])?></span><span class="market-num-label">Active riders registered</span></div>
    <div class="market-num"><span class="market-num-val"><?=number_format($publicStats['delivered'])?></span><span class="market-num-label">Completed deliveries</span></div>
    <div class="market-num"><span class="market-num-val"><?=number_format($publicStats['route_km'],1)?> km</span><span class="market-num-label">Optimised route distance recorded</span></div>
   </div>
  </div>
  <div class="market-visual fade-up">
   <div style="font-family:'JetBrains Mono',monospace;font-size:.7rem;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:1.5rem;">RIDGE operating snapshot</div>
   <div class="bar-chart">
    <div class="bar-row"><div class="bar-label"><span>Live riders now</span><span style="color:var(--green)"><?=number_format($publicStats['live_riders'])?></span></div><div class="bar-track"><div class="bar-fill green" style="width:<?=min(100,$publicStats['riders']?($publicStats['live_riders']/$publicStats['riders']*100):0)?>%"></div></div></div>
    <div class="bar-row"><div class="bar-label"><span>On-time completion</span><span style="color:var(--accent)"><?=$onTimePct?>%</span></div><div class="bar-track"><div class="bar-fill" style="width:<?=min(100,$onTimePct)?>%"></div></div></div>
    <div class="bar-row"><div class="bar-label"><span>Recorded route saving</span><span style="color:var(--green)"><?=number_format($publicStats['fuel_saved_pct'],0)?>%</span></div><div class="bar-track"><div class="bar-fill green" style="width:<?=min(100,$publicStats['fuel_saved_pct'])?>%"></div></div></div>
   </div>
   <div style="margin-top:1.25rem;font-size:.7rem;color:var(--muted);">Live values depend on completed route records and riders currently sharing location.</div>
  </div>
 </div>
</section>
<!-- PRICING -->
<section class="pricing" id="pricing">
 <div class="section-label">Pricing</div>
 <h2 class="section-h">Affordable for Every SME</h2>
 <p class="section-sub">Straightforward plans. Cancel anytime. No hidden fees. All
prices in Naira.</p>
 <div class="pricing-grid">
 <div class="price-card fade-up">
 <div class="price-tier">Starter</div>
 <div class="price-amount"><sub>₦</sub>15,000</div>
 <div class="price-period">per month · up to 5 riders</div>
 <div class="price-divider"></div>
 <ul class="price-features">
 <li>Route optimisation</li>
 <li>Live tracking (5 riders)</li>
 <li>Basic performance reports</li>
 <li>Web & mobile access</li>
 <li>Email support</li>
 </ul>
 <a href="#cta" class="price-cta">Get Started</a>
 </div>
 <div class="price-card featured fade-up">
 <div class="featured-badge">Most Popular</div>
 <div class="price-tier">Growth</div>
 <div class="price-amount"><sub>₦</sub>35,000</div>
 <div class="price-period">per month · up to 12 riders</div>
 <div class="price-divider"></div>
 <ul class="price-features">
 <li>Everything in Starter</li>
 <li>Live tracking (12 riders)</li>
 <li>Advanced analytics dashboard</li>
 <li>Dispatch management tools</li>
 <li>Priority support</li>
 <li>Rider mobile app</li>
 </ul>
 <a href="#cta" class="price-cta">Start Free Trial</a>
 </div>
 <div class="price-card fade-up">
 <div class="price-tier">Scale</div>
 <div class="price-amount"><sub>₦</sub>60,000</div>
 <div class="price-period">per month · up to 20 riders</div>
 <div class="price-divider"></div>
 <ul class="price-features">
 <li>Everything in Growth</li>
 <li>Full fleet of 20 riders</li>
 <li>Custom reporting</li>
 <li>Multi-depot support</li>
 <li>Dedicated account manager</li>
 <li>API access</li>
 </ul>
 <a href="#cta" class="price-cta">Contact Sales</a>
 </div>
 </div>
</section>
<!-- CTA -->
<section class="cta-section" id="cta">
 <h2>READY TO OPTIMISE<br>YOUR FLEET?</h2>
 <p>Join our pilot programme and see measurable savings in your first week. No
commitment required.</p>
 <div class="cta-actions">
 <a href="patners/index.php" class="btn-primary">Create Partner Account</a>
 <a href="track.php" class="btn-ghost">Track a Delivery</a>
 </div>
</section>
<!-- FOOTER -->
<footer>
 <div class="footer-logo">RIDGE<span>.</span></div>
 <p>© 2026 RIDGE. Smarter Routes. Better Deliveries. Lagos, Nigeria.</p>
 <p style="font-size:0.75rem;color:var(--muted)">hello@ridgeapp.ng</p>
</footer>
<script>
 const observer = new IntersectionObserver((entries) => {
 entries.forEach((e, i) => {
 if (e.isIntersecting) {
 setTimeout(() => e.target.classList.add('visible'), i * 80);
 }
 });
 }, { threshold: 0.1 });
 document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));
</script>
</body>
</html>