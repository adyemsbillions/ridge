<?php
require_once '../includes/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$trackingId = strtoupper(trim((string) ($_GET['tracking_id'] ?? '')));
$token = trim((string) ($_GET['t'] ?? ''));
$phone = ridge_normalize_phone((string) ($_GET['phone'] ?? ''));

if ($trackingId === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Tracking ID is required.']);
    exit;
}

$stmt = $conn->prepare("SELECT d.*, p.company_name, r.rider_name FROM deliveries d LEFT JOIN partners p ON p.id=d.partner_id LEFT JOIN riders r ON r.id=d.rider_id WHERE UPPER(d.tracking_id)=? LIMIT 1");
$stmt->bind_param('s', $trackingId);
$stmt->execute();
$delivery = $stmt->get_result()->fetch_assoc();

if (!$delivery) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'message' => 'No delivery matches that tracking ID.']);
    exit;
}

$verified = false;
if ($token !== '' && !empty($delivery['public_token']) && hash_equals((string) $delivery['public_token'], $token)) {
    $verified = true;
} elseif ($phone !== '') {
    $verified = hash_equals(ridge_normalize_phone((string) $delivery['recipient_phone']), $phone)
        || hash_equals(ridge_normalize_phone((string) $delivery['sender_phone']), $phone);
}

$events = ridge_delivery_events($conn, (int) $delivery['id']);
if (!$events) {
    $events[] = [
        'status' => 'pending',
        'title' => 'Delivery request received',
        'description' => 'The delivery has been entered into RIDGE.',
        'created_at' => $delivery['created_at'],
    ];
}

$payload = [
    'ok' => true,
    'verified' => $verified,
    'tracking_id' => $delivery['tracking_id'],
    'status' => $delivery['status'],
    'status_label' => ridge_delivery_status_label($delivery['status']),
    'status_rank' => ridge_status_rank($delivery['status']),
    'partner' => $delivery['company_name'] ?: 'RIDGE delivery partner',
    'delivery_date' => $delivery['delivery_date'],
    'updated_at' => $delivery['updated_at'] ?: $delivery['created_at'],
    'events' => $events,
];

if ($verified) {
    $payload['recipient_name'] = $delivery['recipient_name'];
    $payload['recipient_address'] = $delivery['recipient_address'];
    $payload['package_description'] = $delivery['package_description'];
    $payload['rider_name'] = $delivery['rider_name'];
    $payload['recipient_lat'] = $delivery['recipient_lat'];
    $payload['recipient_lng'] = $delivery['recipient_lng'];
    $payload['last_rider_lat'] = $delivery['last_rider_lat'];
    $payload['last_rider_lng'] = $delivery['last_rider_lng'];
    $payload['last_location_at'] = $delivery['last_location_at'];
    $payload['return_reason'] = $delivery['status'] === 'returned' ? ridge_return_reason_label((string) ($delivery['return_reason'] ?? '')) : null;
    $payload['return_notes'] = $delivery['status'] === 'returned' ? (string) ($delivery['return_notes'] ?? '') : null;
    $payload['returned_at'] = $delivery['status'] === 'returned' ? $delivery['returned_at'] : null;
}

echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
