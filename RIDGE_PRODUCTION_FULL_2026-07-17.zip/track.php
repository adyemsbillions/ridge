<?php
require_once 'includes/bootstrap.php';

$trackingId = strtoupper(trim((string) ($_GET['tracking_id'] ?? '')));
$token = trim((string) ($_GET['t'] ?? ''));
$phoneInput = trim((string) ($_GET['phone'] ?? ''));
$delivery = null;
$verified = false;
$error = '';
$events = [];

if ($trackingId !== '') {
    $stmt = $conn->prepare("SELECT d.*,p.company_name,p.phone partner_phone,r.rider_name,r.phone rider_phone FROM deliveries d LEFT JOIN partners p ON p.id=d.partner_id LEFT JOIN riders r ON r.id=d.rider_id WHERE UPPER(d.tracking_id)=? LIMIT 1");
    $stmt->bind_param('s', $trackingId);
    $stmt->execute();
    $delivery = $stmt->get_result()->fetch_assoc();
    if (!$delivery) {
        $error = 'No delivery matches that tracking ID. Check the code and try again.';
    } else {
        $phone = ridge_normalize_phone($phoneInput);
        if ($token !== '' && !empty($delivery['public_token']) && hash_equals((string) $delivery['public_token'], $token)) {
            $verified = true;
        } elseif ($phone !== '') {
            $verified = hash_equals(ridge_normalize_phone((string) $delivery['recipient_phone']), $phone)
                || hash_equals(ridge_normalize_phone((string) $delivery['sender_phone']), $phone);
            if (!$verified) {
                $error = 'The phone number does not match this delivery. A limited status view is shown below.';
            }
        }
        $events = ridge_delivery_events($conn, (int) $delivery['id']);
        if (!$events) {
            $events[] = ['status'=>'pending','title'=>'Delivery request received','description'=>'The delivery has been entered into RIDGE.','created_at'=>$delivery['created_at']];
        }
    }
}

$statusRank = $delivery ? ridge_status_rank($delivery['status']) : 0;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Track a Delivery - RIDGE</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/portal.css">
<?php if($verified && $delivery && $delivery['recipient_lat'] && $delivery['recipient_lng']):?><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><?php endif;?>
<style>
.track-hero{padding:4.5rem 5vw 2.5rem;background:radial-gradient(circle at 80% 10%,rgba(232,80,10,.18),transparent 32%);border-bottom:1px solid var(--border)}
.track-inner{max-width:980px;margin:auto}.track-form{display:grid;grid-template-columns:1.25fr 1fr auto;gap:.7rem;background:var(--card);padding:.7rem;border:1px solid var(--border);border-radius:14px;margin-top:1.3rem}.track-form input{border:0;background:rgba(245,242,235,.045);color:var(--off);border-radius:9px;padding:.9rem 1rem;font:inherit;outline:none}.track-form button{white-space:nowrap}.progress{display:grid;grid-template-columns:repeat(4,1fr);gap:.45rem;margin:1.2rem 0 1.6rem}.progress-step{position:relative;text-align:center}.progress-step:not(:last-child)::after{content:'';position:absolute;left:55%;right:-45%;top:15px;height:2px;background:var(--border)}.progress-step.done:not(:last-child)::after{background:var(--green)}.progress-dot{width:30px;height:30px;border-radius:50%;margin:0 auto .5rem;display:grid;place-items:center;background:var(--mid);border:1px solid var(--border);font:600 .68rem var(--mono);position:relative;z-index:2}.progress-step.done .progress-dot{background:var(--green);border-color:var(--green);color:#fff}.progress-step.current .progress-dot{background:var(--accent);border-color:var(--accent);color:#fff;box-shadow:0 0 0 5px rgba(232,80,10,.12)}.progress-step span{font-size:.73rem;color:var(--muted)}.progress-step.done span,.progress-step.current span{color:var(--off)}.track-layout{display:grid;grid-template-columns:1.08fr .92fr;gap:1rem;align-items:start}.status-hero{padding:1.4rem;border-radius:14px;background:linear-gradient(145deg,rgba(232,80,10,.14),rgba(29,158,117,.07));border:1px solid var(--border);margin-bottom:1rem}.status-hero small{font:500 .64rem var(--mono);text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}.status-hero strong{display:block;font-family:'Bebas Neue';font-size:2.5rem;font-weight:400;margin:.35rem 0}.status-hero p{color:var(--muted);margin:0;line-height:1.55}.privacy{padding:1rem;border:1px dashed var(--border);border-radius:10px;color:var(--muted);font-size:.84rem;line-height:1.6}.privacy form{display:flex;gap:.6rem;margin-top:.8rem}.privacy input{flex:1;background:rgba(245,242,235,.05);border:1px solid var(--border);border-radius:8px;padding:.7rem;color:var(--off)}#track-map{height:280px;border-radius:12px;overflow:hidden;border:1px solid var(--border);margin-top:1rem}.refresh{font:500 .62rem var(--mono);color:var(--muted)}
@media(max-width:780px){.track-form{grid-template-columns:1fr}.track-layout{grid-template-columns:1fr}.track-hero{padding:3rem 1rem 2rem}.progress-step span{font-size:.62rem}.page{padding-top:1rem}.privacy form{flex-direction:column}}
</style>
</head>
<body>
<header class="topbar"><a class="brand" href="index.php">RIDGE<span>.</span></a><nav class="topnav"><a class="active" href="track.php">Track delivery</a><a href="senders/index.php">Sender portal</a><a class="keep" href="patners/index.php">Partner login</a></nav></header>
<section class="track-hero"><div class="track-inner"><div class="eyebrow">Live delivery status</div><h1 style="font-family:'Bebas Neue';font-size:clamp(2.7rem,7vw,5.4rem);font-weight:400;line-height:.95;margin:.2rem 0">KNOW WHERE<br>YOUR PACKAGE IS.</h1><p class="lead">Enter the tracking ID from your SMS or receipt. Add the sender or recipient phone number to unlock full delivery details.</p>
<form class="track-form" method="get"><input name="tracking_id" placeholder="Tracking ID, e.g. RD-12AB34CD" value="<?=h($trackingId)?>" required><input name="phone" type="tel" placeholder="Sender or recipient phone (optional)" value="<?=h($phoneInput)?>"><button class="btn btn-primary">Track delivery</button></form></div></section>
<main class="page" style="max-width:980px">
<?php if($error):?><div class="alert <?= $delivery ? 'alert-error':'alert-error' ?>"><?=h($error)?></div><?php endif;?>
<?php if($delivery):?>
<div class="status-hero"><small><?=h($delivery['tracking_id'])?> · <?=h($delivery['company_name']?:'RIDGE partner')?></small><strong id="status-label"><?=h(ridge_delivery_status_label($delivery['status']))?></strong><p id="status-copy"><?php echo match($delivery['status']){'pending'=>'The request is waiting for rider assignment.','assigned'=>'A rider has been assigned and is preparing for the trip.','enroute'=>'The rider is travelling to the delivery address.','returned'=>'The delivery attempt was unsuccessful and the item is back at the last-mile hub for reassignment.','delivered'=>'The package has been delivered successfully.','cancelled'=>'This delivery has been cancelled.',default=>'Status is being updated.'};?></p><div class="refresh" style="margin-top:.7rem">Auto-refreshes every 20 seconds · Last checked <span id="last-check"><?=date('h:i:s A')?></span></div></div>
<div class="progress" id="progress">
<?php foreach([1=>'Request received',2=>'Rider assigned',3=>'En route',4=>'Delivered'] as $rank=>$label): $class=$statusRank>$rank?'done':($statusRank===$rank?'current':'');?><div class="progress-step <?=$class?>" data-rank="<?=$rank?>"><div class="progress-dot"><?=$rank?></div><span><?=$label?></span></div><?php endforeach;?>
</div>
<div class="track-layout">
<section class="card"><div class="card-head"><h2>Delivery timeline</h2></div><div class="card-body"><div class="timeline" id="timeline"><?php foreach($events as $event):?><div class="timeline-item"><div class="timeline-dot"></div><div class="timeline-copy"><strong><?=h($event['title'])?></strong><?php if($event['description']):?><small><?=h($event['description'])?></small><?php endif;?><small><?=h(date('d M Y, h:i A',strtotime($event['created_at'])))?></small></div></div><?php endforeach;?></div></div></section>
<section class="card"><div class="card-head"><h2>Delivery information</h2></div><div class="card-body">
<?php if($verified):?><div class="detail-grid"><div class="detail"><small>Recipient</small><strong><?=h($delivery['recipient_name'])?></strong></div><div class="detail"><small>Delivery date</small><strong><?=h(date('d M Y',strtotime($delivery['delivery_date'])))?></strong></div><div class="detail" style="grid-column:1/-1"><small>Destination</small><strong><?=h($delivery['recipient_address'])?></strong></div><div class="detail" style="grid-column:1/-1"><small>Package</small><strong><?=h($delivery['package_description'])?></strong></div><?php if($delivery['status']==='returned'):?><div class="detail" style="grid-column:1/-1;border-color:rgba(212,85,85,.35)"><small>Return reason</small><strong><?=h(ridge_return_reason_label((string)$delivery['return_reason']))?></strong><?php if(!empty($delivery['return_notes'])):?><div style="color:var(--muted);font-size:.78rem;margin-top:.35rem"><?=h($delivery['return_notes'])?></div><?php endif;?></div><?php endif;?><?php if($delivery['rider_name']):?><div class="detail"><small>Assigned rider</small><strong><?=h($delivery['rider_name'])?></strong></div><?php endif;?></div>
<?php if($delivery['recipient_lat'] && $delivery['recipient_lng']):?><div id="track-map"></div><?php endif;?>
<?php else:?><div class="privacy"><strong style="color:var(--off)">Details are protected</strong><br>Enter the sender or recipient phone number to view the recipient, address, package and rider information.<form method="get"><input type="hidden" name="tracking_id" value="<?=h($trackingId)?>"><input type="tel" name="phone" placeholder="Phone number" required><button class="btn btn-primary btn-sm">Unlock details</button></form></div><?php endif;?>
</div></section>
</div>
<?php elseif($trackingId===''):?><section class="card"><div class="empty"><h2 style="font-family:'Bebas Neue';font-size:2rem;font-weight:400;margin:0 0 .5rem">Ready when you are</h2><p>Your tracking ID usually begins with <strong>RD-</strong> and appears in the delivery SMS.</p></div></section><?php endif;?>
</main>
<?php if($delivery):?><script>
const TRACKING_ID=<?=json_encode($trackingId)?>,TOKEN=<?=json_encode($token)?>,PHONE=<?=json_encode(ridge_normalize_phone($phoneInput))?>;
function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
async function refreshStatus(){try{const q=new URLSearchParams({tracking_id:TRACKING_ID});if(TOKEN)q.set('t',TOKEN);if(PHONE)q.set('phone',PHONE);const r=await fetch('api/track.php?'+q,{cache:'no-store'});const d=await r.json();if(!d.ok)return;document.getElementById('status-label').textContent=d.status_label;const copy={pending:'The request is waiting for rider assignment.',assigned:'A rider has been assigned and is preparing for the trip.',enroute:'The rider is travelling to the delivery address.',returned:'The delivery attempt was unsuccessful and the item is back at the last-mile hub for reassignment.',delivered:'The package has been delivered successfully.',cancelled:'This delivery has been cancelled.'};document.getElementById('status-copy').textContent=copy[d.status]||'Status is being updated.';document.getElementById('last-check').textContent=new Date().toLocaleTimeString();document.querySelectorAll('.progress-step').forEach(el=>{const rank=Number(el.dataset.rank);el.classList.toggle('done',d.status_rank>rank);el.classList.toggle('current',d.status_rank===rank);});document.getElementById('timeline').innerHTML=d.events.map(e=>`<div class="timeline-item"><div class="timeline-dot"></div><div class="timeline-copy"><strong>${esc(e.title)}</strong>${e.description?`<small>${esc(e.description)}</small>`:''}<small>${new Date(e.created_at.replace(' ','T')).toLocaleString()}</small></div></div>`).join('');}catch(e){}}
setInterval(refreshStatus,20000);
</script><?php endif;?>
<?php if($verified && $delivery && $delivery['recipient_lat'] && $delivery['recipient_lng']):?><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>const map=L.map('track-map',{zoomControl:false}).setView([<?=json_encode((float)$delivery['recipient_lat'])?>,<?=json_encode((float)$delivery['recipient_lng'])?>],14);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(map);L.marker([<?=json_encode((float)$delivery['recipient_lat'])?>,<?=json_encode((float)$delivery['recipient_lng'])?>]).addTo(map).bindPopup('Delivery destination');<?php if($delivery['last_rider_lat']&&$delivery['last_rider_lng']):?>L.circleMarker([<?=json_encode((float)$delivery['last_rider_lat'])?>,<?=json_encode((float)$delivery['last_rider_lng'])?>],{radius:8}).addTo(map).bindPopup('Latest rider location');<?php endif;?></script><?php endif;?>
</body></html>
