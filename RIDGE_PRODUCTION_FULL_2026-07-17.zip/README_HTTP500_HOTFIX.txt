RIDGE HTTP 500 HOTFIX

1. In cPanel MultiPHP Manager, set ridge.cravii.ng to PHP 8.1, 8.2 or 8.3.
2. Upload db.php to the website root and overwrite the current file.
3. Upload includes/bootstrap.php and overwrite the current file.
4. Create config.local.php in the website root. Copy config.local.example.php and fill in the real database values from the original working db.php or cPanel MySQL Databases.
5. Upload ridge_diagnostic.php to the website root and open:
   https://ridge.cravii.ng/ridge_diagnostic.php
6. Fix every failed item shown on the diagnostic page.
7. Delete ridge_diagnostic.php immediately after testing.
8. Check ridge-errors.log in the website root if a 500 error remains. The root .htaccess blocks public access to .log files.
