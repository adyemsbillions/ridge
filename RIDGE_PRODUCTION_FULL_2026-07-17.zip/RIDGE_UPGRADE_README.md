# RIDGE Feature Completion Upgrade

**Completion date:** 16 July 2026

This package completes the unfinished items listed in the RIDGE Sprint Status Report dated 14 July 2026 and strengthens the existing delivery workflow.

## Completed modules

### Partner performance reports

`patners/reports.php` now includes:

- Date-range reporting
- Total, pending, active, delivered and cancelled orders
- On-time delivery rate
- Average completion time
- Recorded route distance
- Estimated fuel savings with clearly stated assumptions
- Delivery trend and status charts
- Rider completion, on-time and distance performance
- CSV export

### Live partner tracking

- The rider navigation page stores the rider's latest location while an active delivery is open.
- `patners/enroute.php` displays all assigned and enroute deliveries on an auto-refreshing Leaflet map.
- The partner dashboard includes a live map summary.

### Rider mobile application

The rider web application is now an **installable Progressive Web App (PWA)**:

- Standalone mobile-app display
- Install-to-home-screen support
- Rider app icon and manifest
- Offline fallback screen
- Mobile dashboard and bottom navigation
- Secure rider logout
- Location sharing for active deliveries

This is an installable web app, not a compiled Google Play or Apple App Store binary.

### Sender portal

`senders/` now provides:

- Sender account registration and login
- Sender dashboard and delivery statistics
- Delivery request creation
- Active partner selection
- Address search and map-coordinate capture
- Delivery details and timeline
- Shareable tracking links
- Secure logout

### Public recipient tracking

`track.php` and `api/track.php` provide:

- Tracking-ID search
- Privacy-protected delivery details
- Token or phone-number verification
- Auto-refreshing delivery status
- Status progress and event timeline
- Destination map and latest rider location when available

### Recipient and sender notifications

SMS notifications are now processed for:

- Delivery request creation
- Rider assignment
- Rider departure/enroute status
- Delivery OTP
- Successful delivery
- Cancellation

Duplicate status notifications are prevented through the notification log.

### Delivery security and audit trail

- Delivery events are recorded in `delivery_events`.
- OTP confirmation is required before rider delivery completion.
- OTP expiry, resend cooldown and failed-attempt limits are included.
- Database, SMS and SMTP settings were centralised in `config.local.php`.
- Sensitive configuration and migration files are protected through `.htaccess`.
- The unsafe one-time admin-creation script was removed because admins can be created from the admin panel.

## Deployment

1. Back up the live website files and database.
2. Upload the contents of this package over the existing RIDGE installation.
3. Copy `config.local.example.php` to `config.local.php` when the local file is not already present, then enter the production database, SMS, SMTP and domain values.
4. Keep HTTPS enabled. Rider location and PWA installation require HTTPS.
5. Open the website once. RIDGE will create the new tables and columns automatically when the database user has `CREATE` and `ALTER` privileges.
6. Where automatic schema changes are restricted, import `database/migrations/2026_07_16_complete_features.sql` through phpMyAdmin.
7. Test the workflow in this order:
   - Create or sign in to a sender account.
   - Create a delivery and choose a partner.
   - Assign the delivery to a rider.
   - Open the rider app and begin navigation.
   - Confirm that the partner live map receives a location.
   - Send and verify the delivery OTP.
   - Confirm the sender portal, public tracking page and performance report update.

## Configuration notes

- Set `base_url` to the final production domain.
- SMS messages use eBulkSMS through the credentials in `config.local.php`.
- Rider welcome emails use the SMTP values in `config.local.php`.
- Estimated fuel savings use the configured route baseline multiplier and motorcycle fuel efficiency. They are operational estimates rather than audited fuel expenses.
- Rotate database, SMS and SMTP credentials after deployment because the earlier project archive contained credentials directly in source files.

## Validation completed

- All 35 non-vendor PHP files passed PHP syntax checks.
- The rider PWA script and service worker passed JavaScript syntax checks.
- 150 resolvable local links, scripts, styles and form actions were checked with no missing static target.
- Hard-coded database, SMS and SMTP credential assignments were removed from application source.
- A live database, SMTP and SMS-provider end-to-end test must still be completed on the target server.

## Secure handover note

The downloadable source package intentionally excludes `config.local.php` because it contains deployment secrets. Preserve the live server copy or create it from `config.local.example.php`. Rotate the old database, SMS and SMTP credentials because the earlier project archive contained credentials directly in source files.

## Main new files

- `track.php`
- `api/track.php`
- `senders/`
- `includes/bootstrap.php`
- `includes/notifications.php`
- `patners/reports.php`
- `patners/enroute.php`
- `patners/live_data.php`
- `riders/manifest.webmanifest`
- `riders/sw.js`
- `riders/pwa.js`
- `riders/rider_logout.php`
- `database/migrations/2026_07_16_complete_features.sql`

## Return-to-last-mile workflow added on 16 July 2026

- Riders can return an unsuccessful delivery with a required reason and optional notes.
- The sender is notified with the return reason and tracking link.
- Returned packages enter the partner's last-mile return queue.
- Partners can reassign returned packages to active riders for another attempt.
- Return counts, assignment attempts, audit events and partner reporting are retained.

Run `database/migrations/2026_07_16_return_to_last_mile.sql` before testing this workflow.
