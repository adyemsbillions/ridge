-- RIDGE production database migration
-- Compatible with older MySQL/MariaDB versions that do not support ADD COLUMN IF NOT EXISTS.
-- Select the RIDGE database in phpMyAdmin, then run this file once.

CREATE TABLE IF NOT EXISTS senders (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT, full_name VARCHAR(120) NOT NULL, phone VARCHAR(30) NOT NULL,
 email VARCHAR(160) NOT NULL, address TEXT NULL, password VARCHAR(255) NOT NULL,
 status ENUM('active','inactive') NOT NULL DEFAULT 'active', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY(id), UNIQUE KEY uq_senders_email(email), UNIQUE KEY uq_senders_phone(phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS delivery_events (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, delivery_id INT NOT NULL, status VARCHAR(30) NOT NULL,
 title VARCHAR(160) NOT NULL, description TEXT NULL, actor_type VARCHAR(30) NULL, actor_id INT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(id),
 KEY idx_delivery_events_delivery(delivery_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notification_logs (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, delivery_id INT NULL, channel VARCHAR(20) NOT NULL DEFAULT 'sms',
 recipient VARCHAR(40) NOT NULL, event_key VARCHAR(120) NOT NULL, message TEXT NOT NULL,
 status VARCHAR(20) NOT NULL, provider_response TEXT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(id), UNIQUE KEY uq_notification_once(delivery_id,event_key,recipient),
 KEY idx_notification_delivery(delivery_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='partners' AND COLUMN_NAME='fuel_price_per_litre'),
 'SELECT 1',
 'ALTER TABLE partners ADD COLUMN fuel_price_per_litre DECIMAL(10,2) NOT NULL DEFAULT 0'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='partners' AND COLUMN_NAME='fuel_efficiency_km_per_litre'),
 'SELECT 1',
 'ALTER TABLE partners ADD COLUMN fuel_efficiency_km_per_litre DECIMAL(8,2) NOT NULL DEFAULT 35'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='riders' AND COLUMN_NAME='last_lat'),
 'SELECT 1',
 'ALTER TABLE riders ADD COLUMN last_lat DECIMAL(10,7) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='riders' AND COLUMN_NAME='last_lng'),
 'SELECT 1',
 'ALTER TABLE riders ADD COLUMN last_lng DECIMAL(10,7) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='riders' AND COLUMN_NAME='last_location_at'),
 'SELECT 1',
 'ALTER TABLE riders ADD COLUMN last_location_at DATETIME NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='riders' AND COLUMN_NAME='last_accuracy_m'),
 'SELECT 1',
 'ALTER TABLE riders ADD COLUMN last_accuracy_m DECIMAL(8,2) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='riders' AND COLUMN_NAME='last_heading'),
 'SELECT 1',
 'ALTER TABLE riders ADD COLUMN last_heading DECIMAL(8,2) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='riders' AND COLUMN_NAME='last_speed_kmh'),
 'SELECT 1',
 'ALTER TABLE riders ADD COLUMN last_speed_kmh DECIMAL(8,2) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='riders' AND COLUMN_NAME='location_delivery_id'),
 'SELECT 1',
 'ALTER TABLE riders ADD COLUMN location_delivery_id INT NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='sender_id'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN sender_id INT NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='public_token'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN public_token VARCHAR(64) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='accepted_at'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN accepted_at DATETIME NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='enroute_at'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN enroute_at DATETIME NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='delivered_at'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN delivered_at DATETIME NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='cancelled_at'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN cancelled_at DATETIME NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='route_distance_km'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN route_distance_km DECIMAL(10,2) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='route_baseline_km'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN route_baseline_km DECIMAL(10,2) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='route_duration_min'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN route_duration_min DECIMAL(10,2) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='route_baseline_duration_min'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN route_baseline_duration_min DECIMAL(10,2) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='route_updated_at'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN route_updated_at DATETIME NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='last_rider_lat'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN last_rider_lat DECIMAL(10,7) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='last_rider_lng'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN last_rider_lng DECIMAL(10,7) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='last_location_at'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN last_location_at DATETIME NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='delivery_otp'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN delivery_otp VARCHAR(6) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='otp_expires_at'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN otp_expires_at DATETIME NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='return_reason'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN return_reason VARCHAR(80) NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='return_notes'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN return_notes TEXT NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='returned_at'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN returned_at DATETIME NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='returned_by_rider_id'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN returned_by_rider_id INT NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='return_count'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN return_count INT NOT NULL DEFAULT 0'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='assignment_count'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN assignment_count INT NOT NULL DEFAULT 0'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='last_reassigned_at'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN last_reassigned_at DATETIME NULL'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='updated_at'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD COLUMN updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='riders' AND INDEX_NAME='idx_riders_partner_location'),
 'SELECT 1',
 'ALTER TABLE riders ADD INDEX idx_riders_partner_location (partner_id, last_location_at)'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND INDEX_NAME='idx_deliveries_public_token'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD INDEX idx_deliveries_public_token (public_token)'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND INDEX_NAME='idx_deliveries_sender'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD INDEX idx_deliveries_sender (sender_id)'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(
 EXISTS(SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND INDEX_NAME='idx_deliveries_return_queue'),
 'SELECT 1',
 'ALTER TABLE deliveries ADD INDEX idx_deliveries_return_queue (partner_id, status, returned_at)'
);
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

ALTER TABLE deliveries MODIFY status ENUM('pending','assigned','enroute','returned','delivered','cancelled') NOT NULL DEFAULT 'pending';
UPDATE deliveries SET assignment_count=1 WHERE assignment_count=0 AND status IN ('assigned','enroute','delivered');
UPDATE deliveries SET public_token=LOWER(SHA2(CONCAT(UUID(),'-',id,'-',RAND()),256)) WHERE public_token IS NULL OR public_token='';
SELECT 'RIDGE production migration completed' AS result;
