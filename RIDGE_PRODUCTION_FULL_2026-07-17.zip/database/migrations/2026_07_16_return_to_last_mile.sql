-- RIDGE return-to-last-mile migration (older MySQL/MariaDB compatible)
ALTER TABLE deliveries MODIFY status ENUM('pending','assigned','enroute','returned','delivered','cancelled') NOT NULL DEFAULT 'pending';

SET @ridge_sql = IF(EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='return_reason'),'SELECT 1','ALTER TABLE deliveries ADD COLUMN return_reason VARCHAR(80) NULL');
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='return_notes'),'SELECT 1','ALTER TABLE deliveries ADD COLUMN return_notes TEXT NULL');
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='returned_at'),'SELECT 1','ALTER TABLE deliveries ADD COLUMN returned_at DATETIME NULL');
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='returned_by_rider_id'),'SELECT 1','ALTER TABLE deliveries ADD COLUMN returned_by_rider_id INT NULL');
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='return_count'),'SELECT 1','ALTER TABLE deliveries ADD COLUMN return_count INT NOT NULL DEFAULT 0');
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='assignment_count'),'SELECT 1','ALTER TABLE deliveries ADD COLUMN assignment_count INT NOT NULL DEFAULT 0');
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

SET @ridge_sql = IF(EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND COLUMN_NAME='last_reassigned_at'),'SELECT 1','ALTER TABLE deliveries ADD COLUMN last_reassigned_at DATETIME NULL');
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;

UPDATE deliveries SET assignment_count=1 WHERE assignment_count=0 AND status IN ('assigned','enroute','delivered');
SET @ridge_sql = IF(EXISTS(SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='deliveries' AND INDEX_NAME='idx_deliveries_return_queue'),'SELECT 1','ALTER TABLE deliveries ADD INDEX idx_deliveries_return_queue (partner_id,status,returned_at)');
PREPARE ridge_stmt FROM @ridge_sql; EXECUTE ridge_stmt; DEALLOCATE PREPARE ridge_stmt;
SELECT 'RIDGE return migration completed' AS result;
